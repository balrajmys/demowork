import { TestBed } from '@angular/core/testing';

import { SumServiceService } from './sum-service.service';

describe('SumServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SumServiceService = TestBed.get(SumServiceService);
    expect(service).toBeTruthy();
  });
});
