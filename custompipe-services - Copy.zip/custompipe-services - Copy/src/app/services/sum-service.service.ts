import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SumServiceService {

employee=[
  {
    id: "1",
    name: "Steve"
  },
  {
    id: "2",
    name: "John"
  },
  {
    id: "3",
    name: "Stephen"
  }
];

constructor() { }

  welcome(){
    return "Hello  World";
  }

  loginValidate(lid:string,pwd:string):string{
    if(lid===pwd)
    {
      return "Success Login";
    }
    else
    return "Invalid login";
  }

  loadJunkData():any{
    return this.employee;
  }
}
