import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'parenthesispipe'
})  
export class ParenthesispipePipe implements PipeTransform {

  transform(value: string, flag: boolean = true): string {
    if (value === '') {
      return '';
    }
    if (flag) {
      return '（' + value.toLowerCase() + '）';
    }
    return ' (' + value.toUpperCase() + ')';
  }

}
