import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'multiplierpipe'
})
export class MultiplierpipePipe implements PipeTransform {

  transform(value: number, multiply: string): number { 
    let mul = parseFloat(multiply); 
    return mul * value 
} 

}
