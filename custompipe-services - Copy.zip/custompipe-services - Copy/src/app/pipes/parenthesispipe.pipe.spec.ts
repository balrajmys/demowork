import { ParenthesispipePipe } from './parenthesispipe.pipe';

describe('ParenthesispipePipe', () => {
  it('create an instance', () => {
    const pipe = new ParenthesispipePipe();
    expect(pipe).toBeTruthy();
  });
});
