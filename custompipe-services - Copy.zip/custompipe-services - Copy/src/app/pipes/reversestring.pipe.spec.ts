import { ReversestringPipe } from './reversestring.pipe';

describe('ReversestringPipe', () => {
  it('create an instance', () => {
    const pipe = new ReversestringPipe();
    expect(pipe).toBeTruthy();
  });
});
