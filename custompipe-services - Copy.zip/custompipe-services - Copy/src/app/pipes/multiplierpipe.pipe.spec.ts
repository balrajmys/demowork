import { MultiplierpipePipe } from './multiplierpipe.pipe';

describe('MultiplierpipePipe', () => {
  it('create an instance', () => {
    const pipe = new MultiplierpipePipe();
    expect(pipe).toBeTruthy();
  });
});
