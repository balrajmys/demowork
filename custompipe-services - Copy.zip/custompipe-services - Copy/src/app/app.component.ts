import { Component } from '@angular/core';
import {SumServiceService} from './services/sum-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'world';
  status="";
  emp=[];
  constructor(private _sumservice: SumServiceService){
   this.title=_sumservice.welcome();

   this.status=_sumservice.loginValidate("balraj","BALRAJ");
    this.emp=_sumservice.loadJunkData();

  }
}
