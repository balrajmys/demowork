package com.arisglobal.validation.validator.impl;

import java.util.Date;
import java.util.List;

import javax.xml.xpath.XPathConstants;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.NullFlavor;
import com.arisglobal.validation.entities.RepeatableElement;
import com.arisglobal.validation.entities.XmlRule;
import com.arisglobal.validation.utils.DBConsts;
import com.arisglobal.validation.utils.DateFormatHelper;
import com.arisglobal.validation.validator.IValidator;

public class BasicRuleCriteriaValidator implements IValidator {

	//Process nullFlavor, attribute/element value required check, element value allowed empty check
	@Override
	public boolean validate(Document doc, Node currentNode, XmlRule rule, String value, boolean valueIsEmpty, DateFormatHelper dateFormatHelper,
			List<DateFormat> dateFormatList, Date dateNow, Node repeatableNode, RepeatableElement repeatableElement) throws Exception {
		boolean result = true;	
		
		boolean attributeBasedRule = rule.getAttribute() != null;			
		boolean required = rule.getRequired();	
		String prefix = attributeBasedRule ? "" : rule.getNode().getNodeIdentifier();
		
    	if (rule.getNullFlavorBehavior() != null){			            		
    		String nfXPath = attributeBasedRule ? prefix + XPATH_ATTRIBUTE_SYMBOL + NULL_FLAVOR_ATTRIBUTE :
    			prefix + XPATH_NODE_SEPARATOR + XPATH_ATTRIBUTE_SYMBOL + NULL_FLAVOR_ATTRIBUTE;
    		
				String nullFlavorValue = (String) xpath.evaluate(nfXPath, currentNode, XPathConstants.STRING);
			switch (rule.getNullFlavorBehavior().getRecordId().intValue()){
				case DBConsts.NULL_FLAVOR_REQUIRED_ID :
					if ((valueIsEmpty && !checkNullFlavorForRule(rule, nullFlavorValue)) ||
							(!valueIsEmpty && StringUtils.isNotEmpty(nullFlavorValue)))	{
						result = false;			        						
					}
					break;				        				
				case DBConsts.NULL_FLAVOR_NOT_ALLOWED_ID :
					if (StringUtils.isNotEmpty(nullFlavorValue)) result = false;
					break; 					        				
			}
		} else {			
        	if (valueIsEmpty && required) {				            		
        		result = false;
        	}	
		}
    	return result;
	}
	
	private boolean checkNullFlavorForRule(XmlRule rule, String nullFlavorValue) {
		if (rule != null && CollectionUtils.isNotEmpty(rule.getNulllFlavors())) {
			for (NullFlavor nf : rule.getNulllFlavors()) {
				if (nf.getValue().equals(nullFlavorValue)) return true;
			}
		}
		return false;
	}
}
