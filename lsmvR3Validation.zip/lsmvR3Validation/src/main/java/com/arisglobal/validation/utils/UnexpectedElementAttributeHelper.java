package com.arisglobal.validation.utils;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;

import org.apache.commons.collections4.CollectionUtils;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.arisglobal.validation.entities.ValidationError;
import com.arisglobal.validation.entities.XmlNode;
import com.arisglobal.validation.entities.XmlRule;

public class UnexpectedElementAttributeHelper implements XpathConsts{
	
	private static final String ROOT_ELEMENT = "MCCI_IN200100UV01";
	
	public void checkForUnnecessaryNodesAttributes(NodeList nodes, XPath xpath, String context, List<XmlRule> rules, List<ValidationError> validationResults) throws Exception {		
		//skip check for root context
		if (!context.equals(XPATH_NODE_SEPARATOR + "*")) {
			Set<String> allowedAttributes = extractAllowedAttributes(rules);			
			Set<XmlNode> allowedNodes = extractAllowedNodes(rules);
			//traversing through repeatable nodes
			for (int elementIndex = 1; elementIndex<=nodes.getLength(); elementIndex++) {         		
        		Node currentNode = nodes.item(elementIndex - 1);	
        		Integer lineNumber = Integer.parseInt((String)((Element) currentNode).getUserData(PositionalXmlReader.LINE_NUMBER_KEY_NAME)); 	
        		        		
    			//checking attributes
        		//skip check for root element
        		if (!context.equals(XPATH_NODE_SEPARATOR + ROOT_ELEMENT)) {
        			NamedNodeMap attributesMap = currentNode.getAttributes();
        			for (int i = 0; i < attributesMap.getLength(); i++) {
        				Node attribute = attributesMap.item(i);
        				String attributeName = attribute.getNodeName();
        				if (attributeName.contains(":")) {
        					attributeName = attributeName.substring(attributeName.indexOf(":") + 1, attributeName.length());
        				}
        				if (!allowedAttributes.contains(attributeName)) {
        					validationResults.add(new ValidationError(lineNumber, "Following attribute is not allowed: " + attributeName, DBConsts.ERROR_LEVEL_ERROR_ID));
        				}
        			}
        		}    			
    			
    			//preparing list of child elements
    			List<Element> childElements = new LinkedList<>();
    			for (int i = 0 ; i < currentNode.getChildNodes().getLength(); i++) {
    				Node childNode =  currentNode.getChildNodes().item(i);
    				if (childNode.getNodeType() == Node.ELEMENT_NODE) {
    					childElements.add((Element) childNode);
    				}
    			}
    			
    			//checking elements
    			for (Element childElement : childElements) {				
    				String nodeName = childElement.getNodeName();
    				if (nodeName.contains(":")) {
    					nodeName = nodeName.substring(nodeName.indexOf(":") + 1, nodeName.length());
    				}
    				boolean nodeIsAllowed = false;
    				for (XmlNode allowedNode : allowedNodes ) {
    					//check if node name simple
    					if (allowedNode.getNodeIdentifier().equals(allowedNode.getSimpleNodeIdentifier())) {
    						if (nodeName.equals(allowedNode.getNodeIdentifier())) {
    							nodeIsAllowed = true;
    							allowedNode.setElementCount(allowedNode.getElementCount() + 1);
    							break;
    						}
    					} else {
    						//check if node name contains xpath
    						if (nodeName.equals(allowedNode.getSimpleNodeIdentifier())) {
    							Boolean evaluationResult = (Boolean) xpath.evaluate(allowedNode.getContextXpathIdentifier(), childElement, XPathConstants.BOOLEAN);
    							if (evaluationResult!= null && evaluationResult) {
    								nodeIsAllowed = true;
    								allowedNode.setElementCount(allowedNode.getElementCount() + 1);
    								break;
    							}
    						}
    					}
    				}
    				if (!nodeIsAllowed) {
    					validationResults.add(new ValidationError(Integer.parseInt((String) childElement.getUserData(PositionalXmlReader.LINE_NUMBER_KEY_NAME)), "Following node is not allowed: " + nodeName, DBConsts.ERROR_LEVEL_ERROR_ID));
    				}
    			}
    			//checking matching nodes count for single elements
    			for (XmlNode allowedNode : allowedNodes) {
    				if ((allowedNode.getRepeatable() == null || !allowedNode.getRepeatable()) && allowedNode.getElementCount() > 1) {
    					validationResults.add(new ValidationError(lineNumber, "Following nodes are not allowed to be repeatable : " + allowedNode.getNodeIdentifier(), DBConsts.ERROR_LEVEL_ERROR_ID));
    				}
    			}
    			clearAllowedNodesCount(allowedNodes);
			}			
		}
	}

	//Clear repeatable nodes count for repeatable elements
	private void clearAllowedNodesCount(Set<XmlNode> allowedNodes) {
		for (XmlNode node : allowedNodes) {
			node.setElementCount(0);
		}
	}

	//Get allowed attributes for particular context
	private Set<String> extractAllowedAttributes(List<XmlRule> rules) {
		Set<String> attributes = new HashSet<>();
		for (XmlRule rule : rules) {			
			if (rule.getAttribute() != null) {
				attributes.add(rule.getAttribute().getAttributeIdentifier());
				if (rule.getOID() != null) {
					attributes.add("root");
					attributes.add("codeSystem");
				}
				if (CollectionUtils.isNotEmpty(rule.getNulllFlavors())) {
					attributes.add("nullFlavor");
				}
			} 		
		}
		return attributes;
	}
	
	//Get allowed nodes for particular context
	private Set<XmlNode> extractAllowedNodes(List<XmlRule> rules) {
		Set<XmlNode> nodes = new HashSet<>();
		for (XmlRule rule : rules) {
			if (rule.getNode() != null && rule.getNode().getParent() != null) {
				for (XmlNode node : rule.getNode().getParent().getChildNodes()) {
					node.setElementCount(0);
					nodes.add(node);
				}				
				return nodes;				
			}
		}
		return nodes;
	}
}
