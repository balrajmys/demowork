package com.arisglobal.validation.validator;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.RepeatableElement;
import com.arisglobal.validation.entities.XmlRule;
import com.arisglobal.validation.utils.DBConsts;
import com.arisglobal.validation.utils.DateFormatHelper;
import com.arisglobal.validation.utils.XpathConsts;

public interface IValidator extends XpathConsts {	
	
	public static XPathFactory xPathfactory = XPathFactory.newInstance();
	public XPath xpath = xPathfactory.newXPath();
	
	public boolean validate(Document doc, Node currentNode, XmlRule rule, String value, boolean valueIsEmpty, DateFormatHelper dateFormatHelper,
			List<DateFormat> dateFormatList, Date dateNow, Node repeatableNode, RepeatableElement repeatableElement) throws Exception;
	
	//This Method implement comparing values logic depending on compare operator
	public default boolean compareValues(int matchOperatorId, String value, List<String> valuesToCompare) {
		boolean result = true;
		switch (matchOperatorId) {
		case DBConsts.MATCH_OPERATOR_EQUALS_ID :
			if (!valuesToCompare.get(0).equals(value)) {
				result = false;
			}
			break;		
		case DBConsts.MATCH_OPERATOR_NOT_EQUALS_ID :
			if (valuesToCompare.get(0).equals(value)) {
				result = false;
			}
			break;		
		case DBConsts.MATCH_OPERATOR_IN_ID :
		case DBConsts.MATCH_OPERATOR_NOT_IN_ID:		
				boolean customValueCheckResult = false;
				for (String customValue : valuesToCompare) {
					if (value.equals(customValue)) {
						customValueCheckResult = true;
						break;
					}
				}
				if (matchOperatorId == DBConsts.MATCH_OPERATOR_IN_ID && !customValueCheckResult
						|| matchOperatorId == DBConsts.MATCH_OPERATOR_NOT_IN_ID && customValueCheckResult) {
					result = false;
				} 
			break;			
		case DBConsts.MATCH_OPERATOR_LESSER_THAN_ID :
		case DBConsts.MATCH_OPERATOR_LESSER_THAN_OR_EQUALS_ID :
		case DBConsts.MATCH_OPERATOR_GREATER_THAN_OR_EQUALS_ID :
		case DBConsts.MATCH_OPERATOR_GREATER_THAN_ID :
				BigDecimal bdValue = null;
				BigDecimal bdCustomValue = null;
				try {
					bdValue = new BigDecimal(value);
    				bdCustomValue = new BigDecimal(valuesToCompare.get(0));
				} catch (RuntimeException ex) {
					result = false;
					break;
				}
				if (matchOperatorId == DBConsts.MATCH_OPERATOR_LESSER_THAN_ID && bdValue.compareTo(bdCustomValue) >= 0
						|| matchOperatorId == DBConsts.MATCH_OPERATOR_LESSER_THAN_OR_EQUALS_ID && bdValue.compareTo(bdCustomValue) > 0
						|| matchOperatorId == DBConsts.MATCH_OPERATOR_GREATER_THAN_OR_EQUALS_ID && bdValue.compareTo(bdCustomValue) < 0
						|| matchOperatorId == DBConsts.MATCH_OPERATOR_GREATER_THAN_ID && bdValue.compareTo(bdCustomValue) <= 0) 
					result = false;
			break;          		 
	}
		return result;
	}
}
