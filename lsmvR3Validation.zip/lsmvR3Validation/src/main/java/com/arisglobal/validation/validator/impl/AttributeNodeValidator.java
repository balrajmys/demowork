package com.arisglobal.validation.validator.impl;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.xml.xpath.XPathConstants;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.RepeatableElement;
import com.arisglobal.validation.entities.XmlAttribute;
import com.arisglobal.validation.entities.XmlNode;
import com.arisglobal.validation.entities.XmlRule;
import com.arisglobal.validation.utils.DBConsts;
import com.arisglobal.validation.utils.DateFormatHelper;
import com.arisglobal.validation.validator.IValidator;

public class AttributeNodeValidator implements IValidator {
	//Attribute/Node Value Check
	@Override
	public boolean validate(Document doc, Node currentNode, XmlRule rule, String value, boolean valueIsEmpty, DateFormatHelper dateFormatHelper,
			List<DateFormat> dateFormatList, Date dateNow, Node repeatableNode, RepeatableElement repeatableElement) throws Exception {		
		boolean result = true;
		boolean nodeExistsCheck = rule.getNodeExistsCheck() != null ? rule.getNodeExistsCheck() : false;
		if (!nodeExistsCheck) {
			if ((CollectionUtils.isNotEmpty(rule.getMatchingAttributes()) || CollectionUtils.isNotEmpty(rule.getMatchingNodes()))
					&& rule.getMatchOperator()!= null
					&& rule.getMatchType().getRecordId() == DBConsts.MATCH_TYPE_ATTRIBUTE_NODE_ID) {
				List<XmlAttribute> matchingAttributes = rule.getMatchingAttributes();
				List<XmlNode> matchingNodes = rule.getMatchingNodes();
				List<String> matchingStrings = new LinkedList<>();
				
				for (XmlAttribute matchingAttribute : matchingAttributes) {
					String context = matchingAttribute.getNode().getXpath() + XPATH_NODE_SEPARATOR + matchingAttribute.getNode().getNodeIdentifier() ;				
					Object contextObject;
					if (repeatableElement != null && context.contains(repeatableElement.getxPath())) {
						context = context.replace(repeatableElement.getxPath() + XPATH_NODE_SEPARATOR, "");
						contextObject = repeatableNode;
					} else {
						contextObject = doc;
					}			
					String matchingValueXPath = context + XPATH_NODE_SEPARATOR + XPATH_ATTRIBUTE_SYMBOL + matchingAttribute.getAttributeIdentifier();
					String matchingValue = (String) xpath.evaluate(matchingValueXPath, contextObject, XPathConstants.STRING);
					if (StringUtils.isNotEmpty(matchingValue)) {
						matchingStrings.add(matchingValue);
					}
				}
				
				for (XmlNode matchingNode : matchingNodes) {
					String context =  matchingNode.getXpath() + XPATH_NODE_SEPARATOR + matchingNode.getNodeIdentifier();
					Object contextObject;
					if (repeatableElement != null && context.contains(repeatableElement.getxPath())) {
						context = context.replace(repeatableElement.getxPath() + XPATH_NODE_SEPARATOR, "");
						contextObject = repeatableNode;
					} else {
						contextObject = doc;
					}		
					String matchingValueXPath = context + XPATH_NODE_SEPARATOR + XPATH_NODE_VALUE;	
					String matchingValue = (String) xpath.evaluate(matchingValueXPath, contextObject, XPathConstants.STRING);
					if (StringUtils.isNotEmpty(matchingValue)) {
						matchingStrings.add(matchingValue);
					}
				}			
				
				boolean matchingValuesIsEmpty = CollectionUtils.isEmpty(matchingStrings);									
				if (((valueIsEmpty || matchingValuesIsEmpty) && rule.getRequired()) ||
						!compareValues(rule.getMatchOperator().getRecordId().intValue(), value, matchingStrings)) {
					result = false;
				} 
			}
		}		
		return result;		
	}
}
