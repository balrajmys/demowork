package com.arisglobal.validation.handler;

import java.util.Map;

import org.w3c.dom.Node;

public interface ICustomHandler {
	public boolean performValidation(Node currentNode, Map<String, String> parameters) throws Exception;
}
