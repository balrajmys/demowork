package com.arisglobal.validation.validator.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.RepeatableElement;
import com.arisglobal.validation.entities.XmlRule;
import com.arisglobal.validation.utils.DBConsts;
import com.arisglobal.validation.utils.DateFormatHelper;
import com.arisglobal.validation.validator.IValidator;

public class RegexpValidator implements IValidator {
	
	//Regexp value validation
	@Override
	public boolean validate(Document doc, Node currentNode, XmlRule rule, String value, boolean valueIsEmpty, DateFormatHelper dateFormatHelper,
			List<DateFormat> dateFormatList, Date dateNow, Node repeatableNode, RepeatableElement repeatableElement) throws Exception {
		boolean result = true;	
		String matcher = null;		
		if (StringUtils.isNotEmpty(rule.getCustomRegExp()))
			matcher = rule.getCustomRegExp(); 
		else matcher = rule.getRegExp() != null ? rule.getRegExp().getRegexp() : null;	
		boolean nodeExistsCheck = rule.getNodeExistsCheck() != null ? rule.getNodeExistsCheck() : false;
		if (!nodeExistsCheck) {
			if (rule.getMatchType() != null && rule.getMatchType().getRecordId() == DBConsts.MATCH_TYPE_REG_EXP_ID
	    			&& StringUtils.isNotEmpty(matcher) 
	    			&& StringUtils.isNotEmpty(value) 
	    			&& !value.matches(matcher)) {
				result = false;
	    	}
		}		
		return result;
	}
}
