package com.arisglobal.validation.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.DateFormatJavaRepresentation;

public class DateFormatHelper {

	public List<String> getAllowedFormats(DateFormat format, Long matcherId, List<DateFormat> dateFormatList) {
		List<DateFormatJavaRepresentation> dfJavaRepresentations = new ArrayList<>();
		if (matcherId == DBConsts.DATE_FORMAT_MATCHER_EXACT_MATCH_ID) {
			dfJavaRepresentations.addAll(format.getJavaRepresentations());
		} else {
			for (DateFormat df : dateFormatList) {
				if (format.getPrecedence() <= df.getPrecedence()) {
					dfJavaRepresentations.addAll(df.getJavaRepresentations());
				}
			}
		}
		
		return dfJavaRepresentations
		.stream()
        .sorted((o1, o2) -> o2.getPrecedence()
                .compareTo(o1.getPrecedence()))
        .map((o) -> o.getFormat())
        .collect(Collectors.toList());		
	}
	
}
