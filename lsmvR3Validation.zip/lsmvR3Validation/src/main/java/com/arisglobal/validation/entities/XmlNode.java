package com.arisglobal.validation.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_XML_NODE")
public class XmlNode extends AbstractEntity {
	
	@Column(name="NAME")
	private String name;
	
	@ManyToOne
	@JoinColumn(name = "FK_N_ID")
	private XmlNode parent;	
	
	@Column(name="XPATH")
	private String xpath;
	
	@Column(name="NODE_IDENTIFIER")
	private String nodeIdentifier;
	
	@Column(name="REPEATABLE")
	private Boolean repeatable;
	
	@OneToMany(mappedBy="parent", cascade=CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)	
	private List<XmlNode> childNodes;
	
	@Transient
	private int elementCount = 0;

	public List<XmlNode> getChildNodes() {
		return childNodes;
	}

	public void setChildNodes(List<XmlNode> childNodes) {
		this.childNodes = childNodes;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public XmlNode getParent() {
		return parent;
	}

	public void setParent(XmlNode parent) {
		this.parent = parent;
	}

	public String getXpath() {
		return xpath;
	}

	public void setXpath(String xpath) {
		this.xpath = xpath;
	}

	public String getNodeIdentifier() {
		return nodeIdentifier;
	}

	public void setNodeIdentifier(String nodeIdentifier) {
		this.nodeIdentifier = nodeIdentifier;
	}

	public Boolean getRepeatable() {
		return repeatable;
	}

	public void setRepeatable(Boolean repeatable) {
		this.repeatable = repeatable;
	}	
	
	@Transient
	public String getSimpleNodeIdentifier() {
		if (nodeIdentifier.contains("[")) {
			return nodeIdentifier.substring(0, nodeIdentifier.indexOf("["));
		} else return nodeIdentifier;
	}
	
	@Transient
	public String getContextXpathIdentifier() {
		if (nodeIdentifier.contains("[")) {
			return nodeIdentifier
					.substring(nodeIdentifier.indexOf("[") + 1, nodeIdentifier.indexOf("]"))
					.replace("./", "");
		} else return null;
	}
	
	@Transient
	public int getElementCount() {
		return this.elementCount;
	}
	
	@Transient
	public void setElementCount(int elementCount) {
		this.elementCount = elementCount;
	}
}
