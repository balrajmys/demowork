package com.arisglobal.validation.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_H_PARAM")
public class HandlerParameter extends AbstractEntity {
	
	@Column(name="PARAM_NAME")
	private String parameterName;
	
	@Column(name="PARAM_VALUE")
	private String parameterValue;
	
	@ManyToOne
	@JoinColumn(name = "FK_H_ID")
	private CustomHandler customHandler;

	public String getParameterName() {
		return parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public String getParameterValue() {
		return parameterValue;
	}

	public void setParameterValue(String parameterValue) {
		this.parameterValue = parameterValue;
	}

	public CustomHandler getCustomHandler() {
		return customHandler;
	}

	public void setCustomHandler(CustomHandler customHandler) {
		this.customHandler = customHandler;
	}
}
