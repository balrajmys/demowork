package com.arisglobal.validation.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import com.arisglobal.e2b.util.E2BXmlProcessHelper;
import com.arisglobal.e2b.util.XMLCaseInfo;
import com.arisglobal.validation.entities.ValidationError;
import com.arisglobal.validation.utils.XpathConsts;

public interface IR3ValidationService extends XpathConsts {	
	public List<ValidationError> validate(InputStream inputStream) throws Exception;

	public XMLCaseInfo parseXMLtoXMLR3CaseInfoForValidation(File e2bXmldocument, String e2bFileName, String messageType, E2BXmlProcessHelper e2bXmlProcessHelper,
															Boolean xsdValidationReq, Map<String, Integer> lineNoMapByTagId) throws IOException;
}
