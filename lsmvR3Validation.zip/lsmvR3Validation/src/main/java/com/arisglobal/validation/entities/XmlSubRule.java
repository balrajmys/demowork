package com.arisglobal.validation.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_SUB_RULE")
public class XmlSubRule extends AbstractEntity {
	
	@ManyToOne
	@JoinColumn(name = "FK_A_ID")
	private XmlAttribute attribute;
	
	@ManyToOne
	@JoinColumn(name = "FK_N_ID")
	private XmlNode node;
	
	@ManyToOne
	@JoinColumn(name = "FK_MO_ID")
	private MatchOperator matchOperator;
	
	@ManyToOne
	@JoinColumn(name = "FK_MT_ID")
	private MatchType matchType;
	
	@ManyToOne
	@JoinColumn(name = "FK_DIC_ID")
	private Dictionary dictionary;	
		
	@ManyToOne
	@JoinColumn(name = "FK_R_ID")
	private XmlRule rule;
	
	@OneToMany(mappedBy="subRule", cascade=CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)	
	private List<CustomValue> customValues;
	
	@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name="AGX_R3_VALIDATION_SR_M_NA", joinColumns= @JoinColumn(name="FK_SR_ID", referencedColumnName="RECORD_ID"), inverseJoinColumns=@JoinColumn(name="FK_N_ID", referencedColumnName="RECORD_ID"))
	private List<XmlNode> matchingNodes;
	
	@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name="AGX_R3_VALIDATION_SR_M_NA", joinColumns= @JoinColumn(name="FK_SR_ID", referencedColumnName="RECORD_ID"), inverseJoinColumns=@JoinColumn(name="FK_A_ID", referencedColumnName="RECORD_ID"))
	private List<XmlAttribute> matchingAttributes;

	public XmlAttribute getAttribute() {
		return attribute;
	}

	public void setAttribute(XmlAttribute attribute) {
		this.attribute = attribute;
	}

	public XmlNode getNode() {
		return node;
	}

	public void setNode(XmlNode node) {
		this.node = node;
	}

	public MatchOperator getMatchOperator() {
		return matchOperator;
	}

	public void setMatchOperator(MatchOperator matchOperator) {
		this.matchOperator = matchOperator;
	}

	public MatchType getMatchType() {
		return matchType;
	}

	public void setMatchType(MatchType matchType) {
		this.matchType = matchType;
	}

	public Dictionary getDictionary() {
		return dictionary;
	}

	public void setDictionary(Dictionary dictionary) {
		this.dictionary = dictionary;
	}	

	public List<XmlNode> getMatchingNodes() {
		return matchingNodes;
	}

	public void setMatchingNodes(List<XmlNode> matchingNodes) {
		this.matchingNodes = matchingNodes;
	}

	public List<XmlAttribute> getMatchingAttributes() {
		return matchingAttributes;
	}

	public void setMatchingAttributes(List<XmlAttribute> matchingAttributes) {
		this.matchingAttributes = matchingAttributes;
	}

	public XmlRule getRule() {
		return rule;
	}

	public void setRule(XmlRule rule) {
		this.rule = rule;
	}

	public List<CustomValue> getCustomValues() {
		return customValues;
	}

	public void setCustomValues(List<CustomValue> customValues) {
		this.customValues = customValues;
	}
}
