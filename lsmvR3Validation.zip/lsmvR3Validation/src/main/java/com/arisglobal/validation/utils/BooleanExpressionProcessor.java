package com.arisglobal.validation.utils;

import java.text.ParseException;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.lang3.StringUtils;

public class BooleanExpressionProcessor {
		// list of available operators
		private final String OPERATORS = "|&";				
		
		private boolean isNumber(String token) {
			try {
				Integer.parseInt(token);
			} catch (Exception e) {			
				return false;
			}
			return true;
		}

		private boolean isOpenBracket(String token) {
			return token.equals("(");
		}

		private boolean isCloseBracket(String token) {
			return token.equals(")");
		}

		private boolean isOperator(String token) {
			return OPERATORS.contains(token);
		}

		private byte getPrecedence(String token) {
			if (token.equals("|") ) {
				return 1;
			} else {
				return 2;
			}
		}
		
		public Stack<String> parse(String expression) throws ParseException {
			// temporary stack that holds operators, functions and brackets
			Stack<String> stackOperations = new Stack<String>();
			// stack for holding expression converted to reversed polish notation
			Stack<String> stackRPN = new Stack<String>();
			if (StringUtils.isNotEmpty(expression)) {
				// make some preparations
				expression = expression.replace(" ", "");
				// splitting input string into tokens
				StringTokenizer stringTokenizer = new StringTokenizer(expression,
						OPERATORS + "()", true);
				// loop for handling each token - shunting-yard algorithm
				while (stringTokenizer.hasMoreTokens()) {
					String token = stringTokenizer.nextToken();
					if (isOpenBracket(token)) {
						stackOperations.push(token);
					} else if (isCloseBracket(token)) {
						while (!stackOperations.empty()
								&& !isOpenBracket(stackOperations.lastElement())) {
							stackRPN.push(stackOperations.pop());
						}
						stackOperations.pop();					
					} else if (isNumber(token)) {
							stackRPN.push(token);					
					} else if (isOperator(token)) {
						while (!stackOperations.empty()
								&& isOperator(stackOperations.lastElement())
								&& getPrecedence(token) <= getPrecedence(stackOperations
										.lastElement())) {
							stackRPN.push(stackOperations.pop());
						}
						stackOperations.push(token);
					}
				}
				while (!stackOperations.empty()) {
					stackRPN.push(stackOperations.pop());
				}
			}		
			return stackRPN;
		}

		public boolean result(String input, Map<Integer, Boolean> sourceMap) throws ParseException {
            Stack<String> stack = new Stack<String>();
            Queue<String> queue = new LinkedBlockingQueue<String>(parse(input));
            if (queue.size() == 0) {
            	return false;
            } else if (queue.size() == 1) {
            	String value = queue.poll();
            	return sourceMap.get(Integer.parseInt(value)).booleanValue();            			
            } else {
            	String str = queue.poll();
                while (!queue.isEmpty()) {
                    if (!OPERATORS.contains(str) && !str.equalsIgnoreCase("(") && !str.equalsIgnoreCase(")")) {
                        stack.push(str);
                        str = queue.poll();
                    } else {
                        boolean result = false;                                             
                        switch (str) {
                            case "|":
                                {
                                	boolean a = handleValue(stack.pop(), sourceMap);                                
                                    boolean b = handleValue(stack.pop(), sourceMap);
                                    result = a || b;
                                    break;
                                }
                            case "&":
                                {
                                	boolean a = handleValue(stack.pop(), sourceMap);
                                	boolean b = handleValue(stack.pop(), sourceMap);
                                    result = a && b;
                                    break;
                                }                            
                        }                       
                        stack.push(String.valueOf(result));
                        if (queue.size() > 0)
                            str = queue.poll();
                        else
                            break;
                    }                
                }
                return Boolean.parseBoolean(stack.pop());
            }           
        }
		
		private boolean handleValue(String value, Map<Integer, Boolean> sourceMap) {
			boolean a;
			try {                                		
        		int idx = Integer.parseInt(value);
        		a = sourceMap.get(idx).booleanValue();
        	} catch (Exception ex) {
        		a = Boolean.parseBoolean(value);
        	} 
			return a;
		}	
}
