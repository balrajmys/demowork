package com.arisglobal.validation.validator.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.RepeatableElement;
import com.arisglobal.validation.entities.XmlAttribute;
import com.arisglobal.validation.entities.XmlNode;
import com.arisglobal.validation.entities.XmlRule;
import com.arisglobal.validation.entities.XmlSubRule;
import com.arisglobal.validation.utils.BooleanExpressionProcessor;
import com.arisglobal.validation.utils.DBConsts;
import com.arisglobal.validation.utils.DateFormatHelper;
import com.arisglobal.validation.validator.IValidator;

public class SubRulesValidator implements IValidator{
	
	private BooleanExpressionProcessor booleanExpressionProcessor = new BooleanExpressionProcessor();

	@Override
	public boolean validate(Document doc, Node currentNode, XmlRule rule, String value, boolean valueIsEmpty,
			DateFormatHelper dateFormatHelper, List<DateFormat> dateFormatList, Date dateNow, Node repeatableNode,
			RepeatableElement repeatableElement) throws Exception {
		Map<Integer, Boolean> subRuleResultMap = new HashMap<>();			            		
		for (XmlSubRule xmlSubRule : rule.getSubRules()) {
			subRuleResultMap.put(new Integer(xmlSubRule.getRecordId().intValue()), processXmlSubRule(doc, xmlSubRule, repeatableElement, repeatableNode));			            			
		}		            		
		return booleanExpressionProcessor.result(rule.getComplexRuleExpression(), subRuleResultMap);	
	}
	
	//This method process XML Sub Rule as part of the Complex Rule and returns SubRule result
	private boolean processXmlSubRule(Document doc, XmlSubRule xmlSubRule, RepeatableElement repeatableElement, Node repeatableNode) throws XPathExpressionException {		
		boolean result = false;
		XmlAttribute attribute = xmlSubRule.getAttribute();
		XmlNode node =  xmlSubRule.getNode();		
		boolean attributeBasedRule = attribute != null;	
		
		String context = attributeBasedRule ? attribute.getNode().getXpath() + XPATH_NODE_SEPARATOR + attribute.getNode().getNodeIdentifier() : node.getXpath() + XPATH_NODE_SEPARATOR + node.getNodeIdentifier();
		
		Object contextObject;
		if (repeatableElement != null && context.contains(repeatableElement.getxPath())) {
			context = context.replace(repeatableElement.getxPath() + XPATH_NODE_SEPARATOR, "");
			contextObject = repeatableNode;
		} else {
			contextObject = doc;
		}
		
		boolean valueIsEmpty;
		String value = null;
		
		int matchOperatorId = xmlSubRule.getMatchOperator().getRecordId().intValue();		
		
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();		
		
		if (attributeBasedRule) {
			String valueXPath = context + XPATH_NODE_SEPARATOR + XPATH_ATTRIBUTE_SYMBOL + attribute.getAttributeIdentifier();				            		
			value = (String) xpath.evaluate(valueXPath, contextObject, XPathConstants.STRING);
			valueIsEmpty = StringUtils.isEmpty(value);
		} else if (matchOperatorId == DBConsts.MATCH_OPERATOR_EXISTS_ID 
				|| matchOperatorId == DBConsts.MATCH_OPERATOR_NOT_EXISTS_ID) {
			String valueXPath = context;					            		
			NodeList nodesForCheck = (NodeList) xpath.evaluate(valueXPath, contextObject, XPathConstants.NODESET);			            			
			valueIsEmpty = (nodesForCheck == null || nodesForCheck.getLength() == 0);
		} else {
			String valueXPath = context + XPATH_NODE_SEPARATOR + XPATH_NODE_VALUE;			        		
			value = (String) xpath.evaluate(valueXPath, contextObject, XPathConstants.STRING);			            			
			valueIsEmpty = StringUtils.isEmpty(value);
		}
		
		switch (matchOperatorId) {
		case DBConsts.MATCH_OPERATOR_EXISTS_ID:
		case DBConsts.MATCH_OPERATOR_NOT_EXISTS_ID:	
		case DBConsts.MATCH_OPERATOR_NOT_EMPTY:
			if (matchOperatorId == DBConsts.MATCH_OPERATOR_EXISTS_ID) 
				result = !valueIsEmpty;
			else
				result = valueIsEmpty; 			
			break;
		default:
			switch (xmlSubRule.getMatchType().getRecordId().intValue()) {
			case DBConsts.MATCH_TYPE_DICTIONARY_ID:
				if (!valueIsEmpty && xmlSubRule.getDictionary() != null && CollectionUtils.isNotEmpty(xmlSubRule.getDictionary().getDictionaryValues())) {
        			List<String> valuesToCompare = xmlSubRule.getDictionary().getDictionaryValues().stream().map((o) -> o.getValue())
        	        .collect(Collectors.toList());	
        			result = compareValues(xmlSubRule.getMatchOperator().getRecordId().intValue(), value, valuesToCompare);        			
        		}	
				break;
			case DBConsts.MATCH_TYPE_CUSTOM_VALUE_ID:
				if (!valueIsEmpty && xmlSubRule.getCustomValues() != null && CollectionUtils.isNotEmpty(xmlSubRule.getCustomValues())) {
        			List<String> valuesToCompare = xmlSubRule.getCustomValues().stream().map((o) -> o.getValue())
        	        .collect(Collectors.toList());	
        			result = compareValues(xmlSubRule.getMatchOperator().getRecordId().intValue(), value, valuesToCompare);        			
        		}
				break;
			case DBConsts.MATCH_TYPE_ATTRIBUTE_NODE_ID:
				if (CollectionUtils.isNotEmpty(xmlSubRule.getMatchingAttributes()) || CollectionUtils.isNotEmpty(xmlSubRule.getMatchingNodes())) {
					List<XmlAttribute> matchingAttributes = xmlSubRule.getMatchingAttributes();
					List<XmlNode> matchingNodes = xmlSubRule.getMatchingNodes();
					List<String> matchingStrings = new LinkedList<>();
					
					for (XmlAttribute matchingAttribute : matchingAttributes) {
						String contextMa = matchingAttribute.getNode().getXpath() + XPATH_NODE_SEPARATOR + matchingAttribute.getNode().getNodeIdentifier() ;				
						Object contextMaObject;
						if (repeatableElement != null && contextMa.contains(repeatableElement.getxPath())) {
							contextMa = context.replace(repeatableElement.getxPath() + XPATH_NODE_SEPARATOR, "");
							contextMaObject = repeatableNode;
						} else {
							contextMaObject = doc;
						}			
						String matchingValueXPath = contextMa + XPATH_NODE_SEPARATOR + XPATH_ATTRIBUTE_SYMBOL + matchingAttribute.getAttributeIdentifier();
						String matchingValue = (String) xpath.evaluate(matchingValueXPath, contextMaObject, XPathConstants.STRING);
						if (StringUtils.isNotEmpty(matchingValue)) {
							matchingStrings.add(matchingValue);
						}
					}
					
					for (XmlNode matchingNode : matchingNodes) {
						String contextMa =  matchingNode.getXpath() + XPATH_NODE_SEPARATOR + matchingNode.getNodeIdentifier();
						Object contextMaObject;
						if (repeatableElement != null && contextMa.contains(repeatableElement.getxPath())) {
							contextMa = contextMa.replace(repeatableElement.getxPath() + XPATH_NODE_SEPARATOR, "");
							contextMaObject = repeatableNode;
						} else {
							contextMaObject = doc;
						}		
						String matchingValueXPath = contextMa + XPATH_NODE_SEPARATOR + XPATH_NODE_VALUE;	
						String matchingValue = (String) xpath.evaluate(matchingValueXPath, contextMaObject, XPathConstants.STRING);
						if (StringUtils.isNotEmpty(matchingValue)) {
							matchingStrings.add(matchingValue);
						}
					}
					
					boolean matchingValuesIsEmpty = CollectionUtils.isEmpty(matchingStrings);									
					if (!valueIsEmpty && !matchingValuesIsEmpty &&
							compareValues(xmlSubRule.getMatchOperator().getRecordId().intValue(), value, matchingStrings)) {
						result = true;
					} 					
				} 
				break;
			}
			break;
		}			
		return result;
	}
}
