package com.arisglobal.validation.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_M_OPERATOR")
public class MatchOperator extends AbstractEntity {

	@Column(name="NAME")
	private String name;
	
	@Column(name="RULE_ALLOWED")
	private Boolean ruleAllowed;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getRuleAllowed() {
		return ruleAllowed;
	}

	public void setRuleAllowed(Boolean ruleAllowed) {
		this.ruleAllowed = ruleAllowed;
	}	
}
