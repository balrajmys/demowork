package com.arisglobal.validation.utils;

public class XmlLineObject {
	private int xmlLineNo;
	private String message;
	private int errorNo;
	private boolean error;
	private int line;

	public int getXmlLineNo() {
		return xmlLineNo;
	}

	public void setXmlLineNo(int xmlLineNo) {
		this.xmlLineNo = xmlLineNo;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getErrorNo() {
		return errorNo;
	}

	public void setErrorNo(int errorNo) {
		this.errorNo = errorNo;
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public int getLine() {
		return line;
	}

	public void setLine(int line) {
		this.line = line;
	}

}
