package com.arisglobal.validation.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_HANDLER")
public class CustomHandler extends AbstractEntity {
	
	@Column(name="HANDLER_NAME")
	private String handlerName;
	
	@Column(name="HANDLER_CLASS")
	private String handlerClass;
	
	@Column(name="JAR_PATH")
	private String jarPath;
	
	@OneToMany(mappedBy="customHandler", cascade=CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)	
	private List<HandlerParameter> handlerParameters;

	public String getHandlerName() {
		return handlerName;
	}

	public void setHandlerName(String handlerName) {
		this.handlerName = handlerName;
	}

	public String getHandlerClass() {
		return handlerClass;
	}

	public void setHandlerClass(String handlerClass) {
		this.handlerClass = handlerClass;
	}

	public String getJarPath() {
		return jarPath;
	}

	public void setJarPath(String jarPath) {
		this.jarPath = jarPath;
	}

	public List<HandlerParameter> getHandlerParameters() {
		return handlerParameters;
	}

	public void setHandlerParameters(List<HandlerParameter> handlerParameters) {
		this.handlerParameters = handlerParameters;
	}
}
