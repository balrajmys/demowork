package com.arisglobal.validation.utils;

public class DBConsts {
	//Match operators
	public static final int MATCH_OPERATOR_EXISTS_ID = 1;
	public static final int MATCH_OPERATOR_NOT_EXISTS_ID = 2;
	public static final int MATCH_OPERATOR_EQUALS_ID = 3;
	public static final int MATCH_OPERATOR_NOT_EQUALS_ID = 4;	
	public static final int MATCH_OPERATOR_IN_ID = 5;
	public static final int MATCH_OPERATOR_NOT_IN_ID = 6;
	public static final int MATCH_OPERATOR_LESSER_THAN_ID = 7;
	public static final int MATCH_OPERATOR_LESSER_THAN_OR_EQUALS_ID = 8;
	public static final int MATCH_OPERATOR_GREATER_THAN_ID = 9;
	public static final int MATCH_OPERATOR_GREATER_THAN_OR_EQUALS_ID = 10;
	public static final int MATCH_OPERATOR_NOT_EMPTY = 11;
	
	//Match Types
	public static final int MATCH_TYPE_DICTIONARY_ID = 1;
	public static final int MATCH_TYPE_CUSTOM_VALUE_ID = 2;
	public static final int MATCH_TYPE_REG_EXP_ID = 3;
	public static final int MATCH_TYPE_ATTRIBUTE_NODE_ID = 4;
	
	//Error levels
	public static final int ERROR_LEVEL_ERROR_ID = 1;
	public static final int ERROR_LEVEL_WARNING_ID = 2;
	
	//Null Flavor Behaviors
	public static final int NULL_FLAVOR_REQUIRED_ID = 1;
	public static final int NULL_FLAVOR_NOT_ALLOWED_ID = 2;
	
	//Date Format Matcher Types
	public static final int DATE_FORMAT_MATCHER_EXACT_MATCH_ID = 1;
	public static final int DATE_FORMAT_MATCHER_MINIMAL_PRESIZE_ID = 2;
}
