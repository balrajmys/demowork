package com.arisglobal.validation.validator.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.RepeatableElement;
import com.arisglobal.validation.entities.XmlRule;
import com.arisglobal.validation.utils.DateFormatHelper;
import com.arisglobal.validation.validator.IValidator;

public class DateTimeValidator implements IValidator {
	//DateTime value validation
	@Override
	public boolean validate(Document doc, Node currentNode, XmlRule rule, String value, boolean valueIsEmpty, DateFormatHelper dateFormatHelper,
			List<DateFormat> dateFormatList, Date dateNow, Node repeatableNode, RepeatableElement repeatableElement)
			throws Exception {		
		boolean result = true;
		boolean nodeExistsCheck = rule.getNodeExistsCheck() != null ? rule.getNodeExistsCheck() : false;
		if (!nodeExistsCheck) {
			if (rule.getDateFormat() != null && rule.getDfMatcherType() != null && ! valueIsEmpty) {
	    		List<String> allowedDateFormats = dateFormatHelper.getAllowedFormats(rule.getDateFormat(), rule.getDfMatcherType().getRecordId(), dateFormatList);
	    		Date date = null;
	    		for (String dateFormat : allowedDateFormats) {
	    			SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);					            			
	    			try {
	    				date = sdf.parse(value);
	    				break;
	    			} catch (Exception e) { }
	    		}
	    		if (date == null || date.getTime() > dateNow.getTime()) {
	    			result = false;
	    		}
	    	}
		}		
		return result;		
	}
}
