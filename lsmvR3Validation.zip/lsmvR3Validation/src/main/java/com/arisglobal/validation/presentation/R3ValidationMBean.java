package com.arisglobal.validation.presentation;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import com.arisglobal.adverseeventcore.entity.E2BMessageInfo;
import com.arisglobal.adverseeventcore.entity.InboundMessage;
import com.arisglobal.agx.common.bus.entity.customform.CustomForm;
import com.arisglobal.agx.common.bus.entity.icsr.AerInfo;
import com.arisglobal.agx.common.bus.entity.icsr.SafetyReport;
import com.arisglobal.e2b.entity.XMLTagInfo;
import com.arisglobal.e2b.service.E2BR3XMLImportService;
import com.arisglobal.e2b.service.E2BXMLImportService;
import com.arisglobal.e2b.service.E2BXMLInboundDaoService;
import com.arisglobal.e2b.service.impl.E2BR3XMLImportServiceImpl;
import com.arisglobal.e2b.service.impl.E2BXMLImportServiceImpl;
import com.arisglobal.e2b.util.*;
import com.arisglobal.qnccore.common.E2BSettings;
import com.arisglobal.qnccore.common.LSMVDtdDocDetails;
import com.arisglobal.qnccore.entity.AbstractEntity;
import com.arisglobal.qncwebcore.mbean.MandatoryBean;
import com.arisglobal.validation.utils.DBConsts;
import org.apache.commons.io.IOUtils;
import org.jdom2.input.DOMBuilder;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.EncoderConstants;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.arisglobal.agx.admin.bus.entity.User;
import com.arisglobal.agx.common.AgxConstants;
import com.arisglobal.agx.common.AgxUserBean;
import com.arisglobal.agx.common.bus.entity.icsr.E2BCaseValidations;
import com.arisglobal.agx.common.service.CommonService;
import com.arisglobal.qnccore.multidatasource.DbContextUtil;
import com.arisglobal.qnccore.util.AgUtilHelper;
import com.arisglobal.qncwebcore.mbean.AbstractMbean;
import com.arisglobal.qncwebcore.mbean.MandatoryManageBean;
import com.arisglobal.qncwebcore.utils.AgHelpFileMap;
import com.arisglobal.utils.StripXssValidator;
import com.arisglobal.validation.entities.ValidationError;
import com.arisglobal.validation.service.IR3ValidationService;
import com.arisglobal.validation.utils.XmlLineObject;

@Component
@Scope("session")
public class R3ValidationMBean extends AbstractMbean {

	private static Logger agLogger = LoggerFactory.getLogger(R3ValidationMBean.class);

	@Autowired
	MandatoryManageBean mandatoryManageBean;

	@Autowired
	private IR3ValidationService r3ValidationService;
	@Autowired
	private CommonService commonService;

	@Autowired
	private E2BXMLInboundDaoService e2BXMLInboundDaoService;

	@Autowired
	private E2BXMLImportService e2BXMLImportService;


	private List<XmlLineObject> xmlAllLines;
	private List<XmlLineObject> xmlErrorLines;
	private String xmlText;
	private String xmlOutPutText;
	private String responseMessage;
	private StreamedContent convertedXmlFile;
	private boolean isText = false;
	private boolean validXML = true;
	private String importedType;
	private String convertedType;
	private String fileName;
	private byte[] uploadedXmlBytes;
	private boolean xmlError;

	private boolean enableXsdValidation = true;
	private boolean enableRuleBuilderValidation = false;
	private Long dtdType;
	private List<LSMVDtdDocDetails> e2bDtdDetailsCollection;

	public boolean isEnableRuleBuilderValidation() {
		return enableRuleBuilderValidation;
	}

	public void setEnableRuleBuilderValidation(boolean enableRuleBuilderValidation) {
		this.enableRuleBuilderValidation = enableRuleBuilderValidation;
	}

	public boolean isEnableXsdValidation() {
		return enableXsdValidation;
	}

	public void setEnableXsdValidation(boolean enableXsdValidation) {
		this.enableXsdValidation = enableXsdValidation;
	}

	public String getImportedType() {
		return importedType;
	}

	public void setImportedType(String importedType) {
		this.importedType = importedType;
	}

	public String getConvertedType() {
		return convertedType;
	}

	public void setConvertedType(String convertedType) {
		this.convertedType = convertedType;
	}

	public byte[] getUploadedXmlBytes() {
		return uploadedXmlBytes;
	}

	public void setUploadedXmlBytes(byte[] uploadedXmlBytes) {
		this.uploadedXmlBytes = uploadedXmlBytes;
	}

	public boolean isXmlError() {
		return xmlError;
	}

	public void setXmlError(boolean xmlError) {
		this.xmlError = xmlError;
	}

	public String getXmlOutPutText() {
		return xmlOutPutText;
	}

	public void setXmlOutPutText(String xmlOutPutText) {
		this.xmlOutPutText = xmlOutPutText;
	}

	public boolean isValidXML() {
		return validXML;
	}

	public void setValidXML(boolean isValidXML) {
		this.validXML = isValidXML;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public StreamedContent getConvertedXmlFile() {
		if (null != xmlConverted) {
			InputStream stream = new ByteArrayInputStream(this.xmlConverted);
			convertedXmlFile = new DefaultStreamedContent(stream, "xml", "transformed-BFC.xml");
		}
		return convertedXmlFile;
	}

	public void setConvertedXmlFile(StreamedContent convertedXmlFile) {
		this.convertedXmlFile = convertedXmlFile;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public List<XmlLineObject> getXmlAllLines() {
		if (null == xmlAllLines) {
			xmlAllLines = new ArrayList<>();
		}
		return xmlAllLines;
	}

	public void setXmlAllLines(List<XmlLineObject> xmlAllLines) {
		this.xmlAllLines = xmlAllLines;
	}

	public List<XmlLineObject> getXmlErrorLines() {
		if (null == xmlErrorLines) {
			xmlErrorLines = new ArrayList<>();
		}
		return xmlErrorLines;
	}

	public void setXmlErrorLines(List<XmlLineObject> xmlErrorLines) {
		this.xmlErrorLines = xmlErrorLines;
	}

	public String getXmlText() {
		return xmlText;
	}

	public void setXmlText(String xmlText) {
		this.xmlText = xmlText;
	}
	
	public List<LSMVDtdDocDetails> getE2bDtdDetailsCollection() {
		return e2bDtdDetailsCollection;
	}

	public void setE2bDtdDetailsCollection(List<LSMVDtdDocDetails> e2bDtdDetailsCollection) {
		this.e2bDtdDetailsCollection = e2bDtdDetailsCollection;
	}
	
	public Long getDtdType() {
		return dtdType;
	}

	public void setDtdType(Long dtdType) {
		this.dtdType = dtdType;
	}

	
	public void loadXmlValidatorLink(){
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext()
				.getRequest();
		String dbName=request.getParameter("Dbid");
		if(StripXssValidator.stripXSS(dbName)) {
		String dbid=commonService.getDataSourceIdfromName(dbName);
		
		if(null!=dbid){
			AgxUserBean agxUser = new AgxUserBean();
			User user = new User();
			user.setUserId("ANONYMOUSUSER");
			agxUser.setUser(user);
			agxUser.setDisplayDateFormatWithTimeStamp("dd-MMM-yyyy HH:mm:ss");
		    agxUser.setDisplayDateFormat("dd-MMM-yyyy");
//		    agxUser.setDateFormat(ApplicationPreferences.getPreferenceValue(agxUser.getAgxPersistenceUnitName(), "COMM_DATEFORMAT",genericCrudService));
//		    user.setDateFormat(ApplicationPreferences.getPreferenceValue(agxUser.getAgxPersistenceUnitName(), "COMM_DATEFORMAT",genericCrudService));
		    agxUser.setDateFormat("4");
		    user.setDateFormat("4");
			
	
					
			DbContextUtil.getDbInstance().setDbId(dbid);
			agxUser.setAgxPersistenceUnitName(dbid);
			agxUser.setUserName("SYSTEM");
			agxUser.setAgxPersistenceUnitName(dbid);
			agxUser.setCsrfToken(ESAPI.randomizer().getRandomString(16, EncoderConstants.CHAR_ALPHANUMERICS));
			RequestContextHolder.currentRequestAttributes().setAttribute("agxUser", agxUser,
					RequestAttributes.SCOPE_SESSION);
			loadXmlValidator();
		}
		}
	}

	public void loadXmlValidator() {
		setEnableXsdValidation(true);
		setEnableRuleBuilderValidation(false);
		setE2bDtdDetailsCollection(getDtdDocDetails());
		AgHelpFileMap.agFindHelpFileName("e2bValidator");

		//in future code  will be changed
		setResponseMessage(null);
		setFileName(null);
		setDtdType(null);
		setXmlText(null);
		setXmlOutPutText(null);
		setImportedType(null);
		setConvertedType(null);
		setXmlErrorLines(null);
		setXmlAllLines(null);
		setXmlError(false);
		AgHelpFileMap.agFindHelpFileName("e2bValidator");
	}

	public void checkForValidUpload() {
		if(isValidateError()) {
			return;
		}
		else {
			setResponseMessage(null);
			setConvertedXmlFile(null);
			setXmlConverted(null);
			setXmlErrorLines(null);
			setXmlAllLines(null);
			setValidXML(true);
			setXmlError(false);
			setConvertedType(null);
			setXmlOutPutText(null);
			validateUploadedXml();
			if (getXmlErrorLines().size() > 0) {
				RequestContext.getCurrentInstance().execute("PF('xmlUploadPanel').collapse();");
			}
		}
	}

	public void handleFileUpload(FileUploadEvent event) {
		UploadedFile file = null;
		try {
			setXmlText(null);
			setXmlOutPutText(null);
			setXmlErrorLines(null);
			setXmlAllLines(null);
			setResponseMessage(null);
			setXmlError(false);
			setValidXML(true);
			setDtdType(null);
			setConvertedType(null);
			file = event.getFile();
			setUploadedXmlBytes(event.getFile().getContents());
			setFileName(event.getFile().getFileName());
			if (null != file && null!=file.getFileName()) {
				if(!(file.getFileName().toUpperCase().endsWith(".XML"))) {
					setResponseMessage("Please Upload XML File");
				} else {
				InputStream inputstream = file.getInputstream();	
				checkIfContentisValid(inputstream);
				InputStream inputstreamTemp = file.getInputstream();
				setXmlText(IOUtils.toString(inputstreamTemp, StandardCharsets.UTF_8.name()));
				}	
			}
		} catch (IOException | ParserConfigurationException | SAXException e) {
			setResponseMessage("Uploaded XML is Invalid");
			agLogger.error(e.getMessage(), e);
			e.printStackTrace();
		}

	}

	public void convertXml() {
		if (isValidateError()){
			return;
		} else {
			clearAllXmlData();
			validateUploadedXml();
			agLogger.error("validXML = " + validXML);
			if (validXML &&  !xmlError) {
				transformXml();
			}
		}
	}

	private void clearAllXmlData() {
		setResponseMessage(null);
		setConvertedXmlFile(null);
		setXmlConverted(null);
		setXmlOutPutText(null);
		setImportedType(null);
		setConvertedType(null);
		setXmlErrorLines(null);
		setXmlAllLines(null);
		setXmlError(false);
		setValidXML(true);
	}

	private void transformXml() {
		DocumentBuilder dBuilder;
		try {
			setResponseMessage(null);
			xmlOutPutText = null;
			xmlText = xmlText.trim();
			String fileName = (AgUtilHelper.isNotNullAndNotEmpty(getFileName())) ? getFileName() : "";
			InputStream inputstream = null;

			DocumentBuilderFactory docbFactory = DocumentBuilderFactory.newInstance();
			dBuilder = docbFactory.newDocumentBuilder();

			// source XML
			boolean res = false;

			if (isText) {
				String xmlCharSet = null;
				try {
					xmlCharSet = E2BXmlProcessor.findXMLEncodingFormat(xmlText);
				} catch (Exception e) {
					xmlCharSet = "UTF-8";
				}
				byte[] xmlBytes = null;
				if (xmlCharSet.contains("UTF-16")) {
					xmlBytes = xmlText.getBytes(StandardCharsets.UTF_16);
				} else {
					xmlBytes = xmlText.getBytes(StandardCharsets.UTF_8);
				}

				// xmlText
				inputstream = new ByteArrayInputStream(xmlBytes);
				dBuilder.setEntityResolver(new EntityResolver() {
					@Override
					public InputSource resolveEntity(String publicId, String systemId)
							throws SAXException, IOException {
						return new InputSource(
								new ByteArrayInputStream("<?xml version='1.0' encoding='UTF-16'?>".getBytes()));
					}
				});
			} else {

				inputstream = new ByteArrayInputStream(uploadedXmlBytes);
				dBuilder.setEntityResolver(new EntityResolver() {

	@Override
	public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
		return new InputSource(new ByteArrayInputStream("<?xml version='1.0' encoding='UTF-16'?>".getBytes()));
	}});}

	Document sourceDoc = dBuilder.parse(inputstream);
	String xmlType = getXmlType(sourceDoc);
	StreamSource stylesource = null;if("MCCI_IN200100UV01".equalsIgnoreCase(xmlType))
	{
		URL resource = R3ValidationMBean.class.getClassLoader().getResource("/BFC_conversion_v1_0/downgrade-icsr.xsl");
		stylesource = new StreamSource(resource.toURI().toString());
		res = convertXMLToR2(stylesource, sourceDoc, fileName);
		setResponseMessage("Conversion of XML from E2B R3 to E2B R2 is complete");
	}else 
	{
		URL resource = R3ValidationMBean.class.getClassLoader().getResource("/BFC_conversion_v1_0/upgrade-icsr.xsl");
		stylesource = new StreamSource(resource.toURI().toString());
		res = convertXMLToR3(stylesource, sourceDoc, fileName);
		setResponseMessage("Conversion of XML from E2B R2 to E2B R3 is complete");
	}


		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
			setResponseMessage("Invalid import file");
		}

	}

	private boolean convertXMLToR2(StreamSource stylesource, Document uploadedfile, String fileName) {

		try {
			Random random = new Random();
			String randomVal = String.valueOf(random.nextInt(100));
			InputStream inputstream = null;
			// XML Text
			String xmlCharSet = E2BXmlProcessor.findXMLEncodingFormat(xmlText);
			byte[] xmlBytes = null;
			if (xmlCharSet.contains("UTF-16")) {
				xmlBytes = xmlText.getBytes(StandardCharsets.UTF_16);
			} else {
				xmlBytes = xmlText.getBytes(StandardCharsets.UTF_8);
			}

			// byte[] xmlBytes = xmlText.getBytes(StandardCharsets.UTF_8);
			inputstream = new ByteArrayInputStream(xmlBytes);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			StreamSource source = new StreamSource(inputstream);
			Transformer transformer = transformerFactory.newTransformer(stylesource);

			StringWriter outWriter = new StringWriter();
			StreamResult outWriterResult = new StreamResult(outWriter);
			transformer.transform(source, outWriterResult);

			StringBuffer sb = outWriter.getBuffer();
			String finalstring = sb.toString();
			setXmlOutPutText(finalstring);
			xmlCharSet = E2BXmlProcessor.findXMLEncodingFormat(finalstring);
			byte[] resultBytes = null;
			if (xmlCharSet.contains("UTF-16")) {
				resultBytes = finalstring.getBytes(StandardCharsets.UTF_16);
			} else {
				resultBytes = finalstring.getBytes(StandardCharsets.UTF_8);

			}

			// byte[] resultBytes = finalstring.getBytes(StandardCharsets.UTF_8);
			setXmlConverted(resultBytes);
			InputStream stream = new ByteArrayInputStream(resultBytes);
			convertedXmlFile = new DefaultStreamedContent(stream, "xml", randomVal + ".xml");
			setConvertedType("Conveted : E2B R2 XML");

			// setXmlText(null);
			return true;

		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
			return false;
		}
	}

	private byte[] xmlConverted;

	public byte[] getXmlConverted() {
		return xmlConverted;
	}

	public void setXmlConverted(byte[] xmlConverted) {
		this.xmlConverted = xmlConverted;
	}

	private boolean convertXMLToR3(StreamSource stylesource, Document sourceDoc, String fileName) {
		try {
			Random random = new Random();
			String randomVal = String.valueOf(random.nextInt(100));
			fileName = fileName.replace(".", "_" + randomVal + ".");
			String xmlCharSet = "";

			if (isText) {
				// XML Text
				xmlCharSet = E2BXmlProcessor.findXMLEncodingFormat(xmlText);
				byte[] xmlBytes = null;
				if (xmlCharSet.contains("UTF-16")) {
					xmlBytes = xmlText.getBytes(StandardCharsets.UTF_16);
				} else {
					xmlBytes = xmlText.getBytes(StandardCharsets.UTF_8);

				}

				// byte[] xmlBytes = xmlText.getBytes(StandardCharsets.UTF_8);
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				factory.setNamespaceAware(true);
				DocumentBuilder builder = factory.newDocumentBuilder();
				builder.setEntityResolver(new EntityResolver() {
					@Override
					public InputSource resolveEntity(String publicId, String systemId)
							throws SAXException, IOException {
						return new InputSource(
								new ByteArrayInputStream("<?xml version='1.0' encoding='UTF-16'?>".getBytes()));
					}
				});

				sourceDoc = builder.parse(new ByteArrayInputStream(xmlBytes));
			}
			/*
			 * else{ String stringDoc = uploadedfile.getContents().toString();
			 * 
			 * xmlCharSet = E2BXmlProcessor.findXMLEncodingFormat(stringDoc); }
			 */

			DOMSource source = new DOMSource(sourceDoc);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer(stylesource);

			StringWriter outWriter = new StringWriter();
			StreamResult outWriterResult = new StreamResult(outWriter);
			transformer.transform(source, outWriterResult);

			StringBuffer sb = outWriter.getBuffer();
			String finalstring = sb.toString();
			setXmlOutPutText(finalstring);
			xmlCharSet = E2BXmlProcessor.findXMLEncodingFormat(finalstring);

			byte[] resultBytes = null;
			if (xmlCharSet.contains("UTF-16")) {
				resultBytes = finalstring.getBytes(StandardCharsets.UTF_16);
			} else {
				resultBytes = finalstring.getBytes(StandardCharsets.UTF_8);

			}

			// byte[] resultBytes = finalstring.getBytes(StandardCharsets.UTF_8);
			setXmlConverted(resultBytes);
			InputStream stream = new ByteArrayInputStream(resultBytes);
			setConvertedType("E2B R3 XML");
			convertedXmlFile = new DefaultStreamedContent(stream, "xml", randomVal + ".xml");
			//setConvertedType("Converted : E2B R3 XML");

			return true;
		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
			return false;
		}
	}

	private String getXmlType(Document sourceDoc) {
		try {
			Element documentElement = sourceDoc.getDocumentElement();
			String nodeName = documentElement.getNodeName();

			return nodeName;
		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
			return "Error";
		}

	}

	private void handleValidations(final List<SAXParseException> exceptions, final List<ValidationError> validations) {
		BufferedReader reader = null;
		InputStream is = null;
		byte[] xmlBytes = null;
		try {
			String xmlCharSet = E2BXmlProcessor.findXMLEncodingFormat(xmlText);
			if (xmlCharSet.contains("UTF-16")) {
				xmlBytes = xmlText.getBytes(StandardCharsets.UTF_16);
			} else {
				xmlBytes = xmlText.getBytes(StandardCharsets.UTF_8);

			}     
			is = new ByteArrayInputStream(xmlBytes);
			reader = new BufferedReader(new InputStreamReader(is));
			int lineNo = 0;
			String line = reader.readLine();
			while (line != null) {
				XmlLineObject xmlLine = new XmlLineObject();
				xmlLine.setMessage(line);
				xmlLine.setXmlLineNo(++lineNo);
				getXmlAllLines().add(xmlLine);
				line = reader.readLine();
			}
		} catch (IOException  | SAXException | ParserConfigurationException ex ) {
			agLogger.error(ex.getMessage(), ex);
		} finally {
			try {
				if (is != null)
					is.close();
				if (reader != null)
					reader.close();
			} catch (IOException ex) {
				agLogger.error(ex.getMessage(), ex);
			}
		}

		int errorNo = 0;
		for (SAXParseException ex : exceptions) {
			errorNo = errorNo + 1;
			addErrorLine(errorNo, ex.getLineNumber(), ex.getMessage());
		}
		for (ValidationError error : validations) {
			errorNo = errorNo + 1;
			addErrorLine(errorNo, error.getLineNumber(), error.getErrorMessage());
		}
		
		// Loop and update the line numbers to list-req. for hyperLink.
		int line=0;
		for (XmlLineObject lineObj : getXmlAllLines()) {
			line++;
			lineObj.setLine(line);			
			if(lineObj.isError()) {
				XmlLineObject xmlErrorLine = new XmlLineObject();
				xmlErrorLine.setMessage(lineObj.getMessage());
				xmlErrorLine.setErrorNo(lineObj.getErrorNo());
				xmlErrorLine.setLine(line);
				// inclue error message below invalid xml line.
				getXmlErrorLines().add(xmlErrorLine);
			}			
		}
		Collections.sort(getXmlErrorLines(),new ErrorLineCompare());
	}

	private void addErrorLine(int errorNo, int xmlLineNo, String message) {
		XmlLineObject xmlErrorLine = new XmlLineObject();
		xmlErrorLine.setMessage(message);
		xmlErrorLine.setError(true);
		xmlErrorLine.setErrorNo(errorNo);
		// inclue error message below invalid xml line.
		getXmlAllLines().add(xmlLineNo, xmlErrorLine);
	}


	public void validateUploadedXml() {
		try {
			InputStream inputstream = null;
			DocumentBuilderFactory docbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = docbFactory.newDocumentBuilder();
			byte[] xmlBytes = null;
			if (isText) {
				String xmlCharSet = E2BXmlProcessor.findXMLEncodingFormat(xmlText);
				if (xmlCharSet.contains("UTF-16")) {
					xmlBytes = xmlText.getBytes(StandardCharsets.UTF_16);
				} else {
					xmlBytes = xmlText.getBytes(StandardCharsets.UTF_8);

				}
				inputstream = new ByteArrayInputStream(xmlBytes);
				dBuilder.setEntityResolver(new EntityResolver() {
					@Override
					public InputSource resolveEntity(String publicId, String systemId)
							throws SAXException, IOException {
						return new InputSource(
								new ByteArrayInputStream("<?xml version='1.0' encoding='UTF-16'?>".getBytes()));
					}
				});
			} else {
				inputstream = new ByteArrayInputStream(uploadedXmlBytes);
				dBuilder.setEntityResolver(new EntityResolver() {

					@Override
					public InputSource resolveEntity(String publicId, String systemId)
							throws SAXException, IOException {
						return new InputSource(
								new ByteArrayInputStream("<?xml version='1.0' encoding='UTF-16'?>".getBytes()));
					}
				});
			}


			// source XML
			Document sourceDoc = dBuilder.parse(inputstream);
			String xmlType = getXmlType(sourceDoc);
			LSMVDtdDocDetails lsmvDtdDoc = getDtdDoc();

			if ("ICHICSR_R3".equalsIgnoreCase(lsmvDtdDoc.getDtdType())) {
				List<SAXParseException> exceptions = validateR3XMLUsingXsd();
				List<ValidationError> validations = new ArrayList<>(); 
				validations = validateR3XML();

				File file = new File("validateXML");
		        try(FileOutputStream fileOutPutStream = new FileOutputStream(file)){		
				fileOutPutStream.write(xmlBytes);
				if (null!=validations && null != lsmvDtdDoc && lsmvDtdDoc.getLsmvImportConfigurationCollection().size() > 0) {
					validations.addAll(parseAndvalidateXMLUsingDTDRules(file, lsmvDtdDoc.getDtdType(), xmlType,lsmvDtdDoc));
				}
				Collections.sort(validations, new ValidationCompare());
				if (xmlError) {
					setResponseMessage("Invalid xml file");
				} else if ((exceptions!=null && validations!=null) && (!exceptions.isEmpty() || !validations.isEmpty())) {
					setValidXML(false);
					setXmlError(true);
					handleValidations(exceptions, validations);
				} else {
					setValidXML(true);
					setXmlError(false);
					setResponseMessage("Uploaded XML is Valid");
					setImportedType("E2B R3 XML");
				}

				} catch (Exception e) {
					agLogger.error(e.getMessage(), e);
				}
			}
			else
			{
				File file = new File("validateXML");
				FileOutputStream fileOutPutStream = new FileOutputStream(file);
				fileOutPutStream.write(xmlBytes);
				List<ValidationError> validations = new ArrayList<>();
				String validationStatus = validateR2XMLUsingDTD(lsmvDtdDoc.getDtdType());
				if (null != lsmvDtdDoc && lsmvDtdDoc.getLsmvImportConfigurationCollection().size() > 0) {
					validations = parseAndvalidateXMLUsingDTDRules(file, lsmvDtdDoc.getDtdType(), xmlType,lsmvDtdDoc);
				}			
				
				if (xmlError) {
					if(null!= validationStatus) {
						setResponseMessage(validationStatus);
					}else {
						setResponseMessage("Invalid xml file");
					}
				} else if ( !validations.isEmpty()) {
					Collections.sort(validations, new ValidationCompare());
					if(!isValidXML()) {
						setResponseMessage(validationStatus);
					}
					setValidXML(false);
					setXmlError(true);
					handleValidations(new ArrayList<>(), validations);
				}else if(!isValidXML()){ 
					setValidXML(false);
					setXmlError(true);
					setResponseMessage(validationStatus);
				}else {
					setValidXML(true);
					setXmlError(false);
					setResponseMessage(validationStatus);
					setImportedType("E2B R2 XML");
				}
			} 


			// Converting uploaded xml file to string to displaty in UI
			if (xmlBytes != null) {
				InputStream inputstreamTemp = new ByteArrayInputStream(xmlBytes);
				setXmlText(IOUtils.toString(inputstreamTemp, StandardCharsets.UTF_8.name()));
			}
		} catch (Exception e) {
			String error = (null != e.getMessage()) ? e.getMessage() : "Data is Empty";
			setResponseMessage("Error Occured while validating XML : " + error);
			setXmlError(true);
			setValidXML(false);
			agLogger.error(e.getMessage(), e);
		}

	}

    private List<ValidationError> parseAndvalidateXMLUsingDTDRules(File file, String dtdType, String rootElement,LSMVDtdDocDetails lsmvDtdDocDetails) {
  		Map<String, Integer> lineNoMapByTagIdMap = new LinkedHashMap<>();
  		try {
              E2BXmlProcessHelper e2BXmlProcessHelper = new E2BXmlProcessHelper();
              AgxUserBean agxUserBean = (AgxUserBean) RequestContextHolder.currentRequestAttributes().getAttribute("agxUser", RequestAttributes.SCOPE_SESSION);
              e2BXmlProcessHelper.setAgxUser(agxUserBean);
              e2BXmlProcessHelper.setAgxPersistenceUnitName(agxUserBean.getAgxPersistenceUnitName());
              dtdType = lsmvDtdDocDetails.getDtdType();
  			XMLCaseInfo xmlCaseInfo = null;
              if("ICHICSR_R3".equalsIgnoreCase(dtdType)){
              	e2BXmlProcessHelper.setParentObjectType("InboundMessage");
  				xmlCaseInfo = r3ValidationService.parseXMLtoXMLR3CaseInfoForValidation(file, file.getName(), dtdType, e2BXmlProcessHelper, false, lineNoMapByTagIdMap);
  			}else {
  				E2BXmlProcessor e2bXmlProcessor = E2BXmlProcessor.getInstance(e2BXmlProcessHelper, genericCrudService);
  				org.jdom2.Document e2bXmldocument = e2bXmlProcessor.buildByOverridingDtdDeclaration(file);
  				E2BSettings e2bSettings = genericCrudService.findByNamedQuery("E2BSettings.findAllByModuleName", "App_pref");
  				e2BXmlProcessHelper.setE2bSettings(e2bSettings);
  				e2BXmlProcessHelper.setImportConfiguration(lsmvDtdDocDetails.getLsmvImportConfigurationCollection().get(0));
  				xmlCaseInfo = e2BXMLImportService.parseXMLtoXMLCaseInfo(e2bXmldocument.getRootElement(), file.getName(), dtdType, e2BXmlProcessHelper);
  			}

  			List<MandatoryBean> mandatoryBeanList = new ArrayList<>();
  			List<ValidationError> validations = new ArrayList<>();
  			if(null != lsmvDtdDocDetails && lsmvDtdDocDetails.getLsmvImportConfigurationCollection().size() > 0){
  				Long importCustomFormId = lsmvDtdDocDetails.getLsmvImportConfigurationCollection().get(0).getImportForm();
  				e2BXmlProcessHelper.setDtdDetails(lsmvDtdDocDetails);
  				e2BXmlProcessHelper.setMessageType(lsmvDtdDocDetails.getDtdType());
  				e2BXmlProcessHelper.setAgxPersistenceUnitName(agxUserBean.getAgxPersistenceUnitName());
  				e2BXmlProcessHelper.setImportConfiguration(lsmvDtdDocDetails.getLsmvImportConfigurationCollection().get(0));
  				XMLTagLibraryMetaData xmlTagLibraryMetaData = XMLTagLibraryMetaDataHandler
  						.getXMLTagLibraryMetaData(e2BXmlProcessHelper.getAgxPersistenceUnitName());
  				e2BXmlProcessHelper.setXmlTagLibraryMetaData(xmlTagLibraryMetaData);
  				if(null != importCustomFormId) {
  					CustomForm customForm = (CustomForm)genericCrudService.findByPk(CustomForm.class, importCustomFormId);
  					for (SafetyReport safetyReport : xmlCaseInfo.getSafetyReportsCollection()) {
  						InboundMessage tempInboundMessage = new InboundMessage();
  						AerInfo aerInfo = new AerInfo();
  						aerInfo.setCustomForm(customForm);
  						aerInfo.setSafetyReport(safetyReport);
  						tempInboundMessage.setAerInfo(aerInfo);
  						if (!"ICHICSR_R3".equalsIgnoreCase(dtdType)) {
							tempInboundMessage.getAerInfo().getSafetyReport().setValidationsLists(null);
						}
						e2BXMLInboundDaoService.getValidationRules(tempInboundMessage, mandatoryBeanList, agxUserBean, e2BXmlProcessHelper);
  						for (E2BCaseValidations e2BCaseValidations :tempInboundMessage.getAerInfo().getSafetyReport().getValidationsLists()) {
  							int line = (lineNoMapByTagIdMap.get(e2BCaseValidations.getE2bTagId()) == null) ? 0 : lineNoMapByTagIdMap.get(e2BCaseValidations.getE2bTagId());
  							validations.add( new ValidationError(line, e2BCaseValidations.getValidationKey(), DBConsts.ERROR_LEVEL_ERROR_ID));
  						}

  					}
  				}
  			}
              return  validations;
          }catch (Exception e){
  	        e.printStackTrace();
              agLogger.error(e.getMessage(), e);
              return new ArrayList<>();
          }
      }

	private List<SAXParseException> validateR3XMLUsingXsd() {
		SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		try {
			URL schemaFile = R3ValidationMBean.class.getClassLoader()
					.getResource("/ICH_ICSR_Schema_Files/multicacheschemas/MCCI_IN200100UV01.xsd");
			InputStream inputstream = null;
			if (isText) {
				byte[] xmlBytes = xmlText.getBytes(StandardCharsets.UTF_8);
				inputstream = new ByteArrayInputStream(xmlBytes);
			} else {
				inputstream = new ByteArrayInputStream(uploadedXmlBytes);
			}
			// source XML
			StreamSource source = new StreamSource(inputstream);

			Schema schema = schemaFactory.newSchema(schemaFile);
			Validator validator = schema.newValidator();

			// Custom error handler for XML aganist XSD
			final List<SAXParseException> exceptions = new LinkedList<SAXParseException>();
			validator.setErrorHandler(new ErrorHandler() {
				@Override
				public void warning(SAXParseException exception) throws SAXException {
					exceptions.add(exception);
				}

				@Override
				public void fatalError(SAXParseException exception) throws SAXException {
					exceptions.add(exception);
				}

				@Override
				public void error(SAXParseException exception) throws SAXException {
					exceptions.add(exception);
				}
			});
			validator.validate(source);
			return exceptions;

		} catch (Exception e) {
			setXmlError(true);
		}
		return null;
	}

	private String validateR2XMLUsingDTD(String dtd) {
		InputStream inputstream = null;
		try {
			DocumentBuilderFactory docbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = docbFactory.newDocumentBuilder();
			if (isText) {
				String xmlCharSet = E2BXmlProcessor.findXMLEncodingFormat(xmlText);
				byte[] xmlBytes = xmlText.getBytes(StandardCharsets.UTF_8);
				inputstream = new ByteArrayInputStream(xmlBytes);
				dBuilder.setEntityResolver(new EntityResolver() {
					@Override
					public InputSource resolveEntity(String publicId, String systemId)
							throws SAXException, IOException {
						return new InputSource(
								new ByteArrayInputStream("<?xml version='1.0' encoding='UTF-16'?>".getBytes()));
					}
				});
			} else {
				inputstream = new ByteArrayInputStream(uploadedXmlBytes);
				dBuilder.setEntityResolver(new EntityResolver() {

	@Override
	public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
		return new InputSource(new ByteArrayInputStream("<?xml version='1.0' encoding='UTF-16'?>".getBytes()));
	}});}

	Document sourceDoc = dBuilder.parse(inputstream);

	// Convert to JDOM2
	DOMBuilder builder = new DOMBuilder();
	org.jdom2.Document document = builder.build(sourceDoc);

	String validationMsg = validateWithMetadataForE2BR2(document,dtd);

	return validationMsg;
	}
		catch (Exception e) {
			agLogger.error(e.getMessage(), e);
			setValidXML(false);
			String errorMessage = "Invalid XML";
			return errorMessage;
		}
	}

	private String validateWithMetadataForE2BR2(org.jdom2.Document document,String dtd) {
		AgxUserBean agxUserBean = (AgxUserBean) RequestContextHolder.currentRequestAttributes().getAttribute("agxUser",
				RequestAttributes.SCOPE_SESSION);
		E2BXmlProcessHelper e2bXmlProcessHelper = new E2BXmlProcessHelper();
		e2bXmlProcessHelper.setAgxPersistenceUnitName(agxUserBean.getAgxPersistenceUnitName());
		e2bXmlProcessHelper.setMessageType(dtd);
		E2BXmlProcessor e2bXmlProcessor = E2BXmlProcessor.getInstance(e2bXmlProcessHelper, genericCrudService);
		org.jdom2.Element rootElement = document.getRootElement();
		StringBuilder validationStatusMessage = new StringBuilder();
		boolean validationError = false;
		if(!validateRootTag(rootElement.getName(),e2bXmlProcessor,dtd)) {
			validationStatusMessage.append(
					"Uploaded XML root tag doesn't match.");
			validationStatusMessage.append("\n");
			setXmlError(true);
			return validationStatusMessage.toString();
		}
		List<E2BCaseValidations> e2BCaseValidationList = e2bXmlProcessor.validateByContextElement(rootElement,
				e2bXmlProcessHelper.getMessageType(), "");
		ResourceBundle commonMsgBundle = ResourceBundle.getBundle("e2bMessages",
				new Locale(agxUserBean.getLanguageCode()));
		for (E2BCaseValidations e2bCaseValidations : e2BCaseValidationList) {
			String msgKeyString = null;
			try {
				try {
					msgKeyString = commonMsgBundle.getString(e2bCaseValidations.getValidationKey());
				} catch (MissingResourceException e) {
					msgKeyString = e2bCaseValidations.getValidationKey();
				}
				String validationData = e2bCaseValidations.getValidationData();
				String[] validationFieldsArray = new String[0];
				if (null != validationData && validationData.length() > 0) {
					validationFieldsArray = validationData.split(AgxConstants.DATA_FIELDS_SEPERATOR);
				}
				for (int i = 0; i < validationFieldsArray.length; i++) {
					msgKeyString = msgKeyString.replace("'{" + i + "}'", validationFieldsArray[i]);
				}
			} catch (Exception e) {
				msgKeyString = "";
				e.printStackTrace();
				agLogger.error("Error Occurred in 'validateWithMetadataForE2BR2' "+e.getMessage());
			}
			e2bCaseValidations.setValidationDetailMsg(msgKeyString);
		}

		if (!isText || e2BCaseValidationList.size() > 0) {
			validationStatusMessage.append(
					"Uploaded XML has " + e2BCaseValidationList.size() + " error/s");
			validationStatusMessage.append("\n");
		} else {
			validationStatusMessage.append("Uploaded XML is Valid");
		}

		for (E2BCaseValidations e2bCaseValidations : e2BCaseValidationList) {
			validationStatusMessage.append(e2bCaseValidations.getRootElementName());
			validationStatusMessage.append(" | ");
			validationStatusMessage.append(e2bCaseValidations.getElementName());
			validationStatusMessage.append(" | ");
			validationStatusMessage.append(e2bCaseValidations.getValidationDetailMsg());
			validationStatusMessage.append("\n");
			// validationStatusMessage = validationStatusMessage+" , "
			// +e2bCaseValidations.getValidationData();
			validationError = true;
		}
		if (!validationError) {
			setValidXML(true);
			return validationStatusMessage.toString();
		} else {
			setValidXML(false);
			return validationStatusMessage.toString();
		}
	}

	private List<ValidationError> validateR3XML() throws IOException {
		InputStream inputstream = null;
		try {
			if (isText) {
				byte[] xmlBytes = xmlText.getBytes(StandardCharsets.UTF_8);
				inputstream = new ByteArrayInputStream(xmlBytes);
			} else {
				inputstream = new ByteArrayInputStream(uploadedXmlBytes);
			}
			List<ValidationError> validations = r3ValidationService.validate(inputstream);
			return validations;
		} catch (Exception e) {
			setXmlError(true);
		}
		return null;
	}

	public void clearImportDetails() {
		setXmlText(null);
		setConvertedXmlFile(null);
		setXmlConverted(null);
		setResponseMessage(null);
		setXmlError(false);
	}
	
	class ErrorLineCompare implements Comparator<XmlLineObject> {
		public int compare(XmlLineObject line1, XmlLineObject line2) {
			if (line1.getErrorNo() == line2.getErrorNo())
				return 0;
			else if (line1.getErrorNo() > line2.getErrorNo())
				return 1;
			else
				return -1;
		}
	}
	
	class ValidationCompare implements Comparator<ValidationError> {
		public int compare(ValidationError val1, ValidationError val2) {
			if (val1.getLineNumber() == val2.getLineNumber())
				return 0;
			else if (val1.getLineNumber() > val2.getLineNumber())
				return 1;
			else
				return -1;
		}
	}

	public void loadImportValidations() {


		RequestContext.getCurrentInstance().execute(
				"PF('ConversionE2BCaseValidation').show();");


	}


	public void updateXSDValidationCondition(){
		/*if(enableXsdValidation){
			setEnableXsdValidation(false);
		}else{
			setEnableXsdValidation(true);
		}*/
	}

	public void updateRuleBuilderValidationCondition(){
		/*if(enableRuleBuilderValidation){
			setEnableRuleBuilderValidation(false);
		}else{
			setEnableRuleBuilderValidation(true);
		}*/
	}
	
	private List<LSMVDtdDocDetails> getDtdDocDetails(){
		List<LSMVDtdDocDetails> lsmvDtdDocDetails = null ;
		try {
			lsmvDtdDocDetails = genericCrudService.findAllByNamedQuery("LSMVDtdDocDetails.findByDtdSchema",null);
		} catch (Exception e) {
			e.printStackTrace();
			agLogger.error("Error While fetching DTDocDetails"+e.getMessage());
		}
		
		return lsmvDtdDocDetails;
	}
	
	private LSMVDtdDocDetails getDtdDoc() {
		LSMVDtdDocDetails lsmvDtdDocDetails = new LSMVDtdDocDetails();
		try {
			if (null != dtdType) {
				lsmvDtdDocDetails = genericCrudService.findByNamedQuery("LSMVDtdDocDetails.findDtdByRecId", dtdType);
			} /*
				 * else { lsmvDtdDocDetails =
				 * genericCrudService.findByNamedQuery("LSMVDtdDocDetails.findByDtdType", dtd);
				 * }
				 */
		} catch (Exception e) {
			e.printStackTrace();
			agLogger.error("Error While fetching DTDoc" + e.getMessage());
		}

		return lsmvDtdDocDetails;

	}

	private boolean validateRootTag(String rootElement, E2BXmlProcessor e2bXmlProcessor, String dtd) {

		String rootTag = e2bXmlProcessor.getRootTag().get(dtd);
		if (rootElement.equals(rootTag)) {
			return true;
		}
		return false;
	}
	
	private String getKey(String value) {
		String key = null;
		try {
			Map<String, String> rootTagMap = getE2bXmlProcessor().getRootTag();
			key = rootTagMap.entrySet().stream().filter(entry -> value.equals(entry.getValue())).map(Map.Entry::getKey)
					.findFirst().orElse(null);
		} catch (Exception e) {
			agLogger.error("Error Occurred While getting Key"+e.getMessage());
		}
		return key;
	}

	private E2BXmlProcessor getE2bXmlProcessor() {
		AgxUserBean agxUserBean = (AgxUserBean) RequestContextHolder.currentRequestAttributes().getAttribute("agxUser",
				RequestAttributes.SCOPE_SESSION);
		E2BXmlProcessHelper e2bXmlProcessHelper = new E2BXmlProcessHelper();
		e2bXmlProcessHelper.setAgxPersistenceUnitName(agxUserBean.getAgxPersistenceUnitName());
		return E2BXmlProcessor.getInstance(e2bXmlProcessHelper, genericCrudService);
	}
	
	private void clearAllOnValidationError()  {
		/*setXmlText(null);
		setUploadedXmlBytes(null);*/
		setFileName(null);
		setImportedType(null);
	}
	
	private boolean isValidateError() {
		boolean isInvalid = false;
		if(null == xmlText || "".equals(xmlText)) {
			setResponseMessage("Invalid File,Please Upload XML File");
			clearAllOnValidationError();
			isInvalid = true;
		} else if (!(null == xmlText || "".equals(xmlText))) {
			 try {
			       checkIfContentisValid(new ByteArrayInputStream(xmlText.getBytes()));
			    }catch (Exception e) {
			        setResponseMessage("Content is Invalid");
			        clearAllOnValidationError();
			        isInvalid = true;
			    }

		}else if (null == dtdType) {
			setResponseMessage("Please Select DTD Configuration for XML Validation");
			isInvalid = true;
		}
		
		return isInvalid;
	}
	
	private void checkIfContentisValid(InputStream in) throws SAXException, IOException, ParserConfigurationException {
		DocumentBuilderFactory docbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = docbFactory.newDocumentBuilder();
		dBuilder.setEntityResolver(new EntityResolver() {
			@Override
			public InputSource resolveEntity(String publicId, String systemId)
					throws SAXException, IOException {
				return new InputSource(
						new ByteArrayInputStream("<?xml version='1.0' encoding='UTF-16'?>".getBytes()));
			}
		});
		Document sourceDoc = dBuilder.parse(in);
		String xmlType = getXmlType(sourceDoc);

		if ("MCCI_IN200100UV01".equalsIgnoreCase(xmlType)) {
			setImportedType("E2B R3 XML");
		} else {
			String keyValue = getKey(xmlType);
			if (null != keyValue) {
				setImportedType("E2B R2 XML");
			} else {
				setImportedType(null);
			}
		}
		isText = true;
	}

}
