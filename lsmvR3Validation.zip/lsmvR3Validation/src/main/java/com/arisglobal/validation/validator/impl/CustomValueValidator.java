package com.arisglobal.validation.validator.impl;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.RepeatableElement;
import com.arisglobal.validation.entities.XmlRule;
import com.arisglobal.validation.utils.DBConsts;
import com.arisglobal.validation.utils.DateFormatHelper;
import com.arisglobal.validation.validator.IValidator;

public class CustomValueValidator implements IValidator {
	//Custom Value(s) validation
	@Override
	public boolean validate(Document doc, Node currentNode, XmlRule rule, String value, boolean valueIsEmpty, DateFormatHelper dateFormatHelper,
			List<DateFormat> dateFormatList, Date dateNow, Node repeatableNode, RepeatableElement repeatableElement) throws Exception {		
		boolean result = true;
		boolean nodeExistsCheck = rule.getNodeExistsCheck() != null ? rule.getNodeExistsCheck() : false;
		if (!nodeExistsCheck) {
			if (rule.getMatchType() != null
	    			&& rule.getMatchOperator() != null
	    			&& rule.getMatchType().getRecordId() == DBConsts.MATCH_TYPE_CUSTOM_VALUE_ID) {
	    		if (valueIsEmpty || CollectionUtils.isEmpty(rule.getCustomValues())) {
	    			result = false;
	    		} else {
	    			List<String> valuesToCompare = rule.getCustomValues().stream().map((o) -> o.getValue())
	    	        .collect(Collectors.toList());	
	    			boolean compareResult = compareValues(rule.getMatchOperator().getRecordId().intValue(), value, valuesToCompare);
	    			if (!compareResult) result = false;
	    		}					            		
	    	}
		}		
		return result;		
	}
}
