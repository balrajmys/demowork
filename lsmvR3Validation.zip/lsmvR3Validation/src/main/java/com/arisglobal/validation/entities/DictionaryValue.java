package com.arisglobal.validation.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_DIC_VALUE")
public class DictionaryValue extends AbstractEntity {	
		
	@Column(name = "DICTIONARY_VALUE")
	private String value;
	
	@ManyToOne
	@JoinColumn(name = "FK_DIC_ID")
	private Dictionary dictionary;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Dictionary getDictionary() {
		return dictionary;
	}

	public void setDictionary(Dictionary dictionary) {
		this.dictionary = dictionary;
	}	
}
