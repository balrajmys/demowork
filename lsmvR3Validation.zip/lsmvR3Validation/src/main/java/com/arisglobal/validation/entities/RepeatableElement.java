package com.arisglobal.validation.entities;

public class RepeatableElement {		
		private String xPath;
		private int level;
				
		public String getxPath() {
			return xPath;
		}
		public void setxPath(String xPath) {
			this.xPath = xPath;
		}
		public int getLevel() {
			return level;
		}
		public void setLevel(int level) {
			this.level = level;
		}
		public RepeatableElement(String xPath, int level) {
			super();
			this.xPath = xPath;
			this.level = level;
		}	
}
