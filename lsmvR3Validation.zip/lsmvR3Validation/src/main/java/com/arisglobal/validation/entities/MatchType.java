package com.arisglobal.validation.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_MATCH_TYPE")
public class MatchType extends AbstractEntity {

	@Column(name="NAME")
	private String name;
	
	@Column(name="SUB_RULE_ALLOWED")
	private Boolean subRuleAllowed;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getSubRuleAllowed() {
		return subRuleAllowed;
	}

	public void setSubRuleAllowed(Boolean subRuleAllowed) {
		this.subRuleAllowed = subRuleAllowed;
	}	
}
