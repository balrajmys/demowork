package com.arisglobal.validation.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_CUSTOM_VALUE")
public class CustomValue extends AbstractEntity {
	
	@ManyToOne
	@JoinColumn(name = "FK_SR_ID")
	private XmlSubRule subRule;	

	@ManyToOne
	@JoinColumn(name = "FK_R_ID")
	private XmlRule rule;
	
	@Column(name="VALUE")
	String value;
	
	public XmlSubRule getSubRule() {
		return subRule;
	}

	public void setSubRule(XmlSubRule subRule) {
		this.subRule = subRule;
	}

	public XmlRule getRule() {
		return rule;
	}

	public void setRule(XmlRule rule) {
		this.rule = rule;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}	
}
