package com.arisglobal.validation.service.impl;

import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.zip.DataFormatException;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import com.arisglobal.adverseeventcore.entity.E2BMessageInfo;
import com.arisglobal.adverseeventcore.entity.InboundSupportDocument;
import com.arisglobal.agx.common.AgxConstants;
import com.arisglobal.agx.common.AgxUserBean;
import com.arisglobal.agx.common.bus.entity.customform.CustomForm;
import com.arisglobal.agx.common.bus.entity.customform.CustomFormField;
import com.arisglobal.agx.common.bus.entity.icsr.*;
import com.arisglobal.agx.jsscript.util.ScriptSession;
import com.arisglobal.agx.jsscript.util.ScriptingFacadeUtil;
import com.arisglobal.e2b.entity.XMLTableInfo;
import com.arisglobal.e2b.entity.XMLTagInfo;
import com.arisglobal.e2b.service.impl.E2BR3XMLImportServiceImpl;
import com.arisglobal.e2b.util.*;
import com.arisglobal.formdesign.util.FormDesignMBean;
import com.arisglobal.qnccore.multidatasource.DbContextUtil;
import com.arisglobal.qnccore.service.AppContext;
import com.arisglobal.qnccore.service.CodeListService;
import com.arisglobal.qnccore.util.AgUtilHelper;
import com.arisglobal.qnccore.util.CodeList;
import com.arisglobal.qnccore.util.Constants;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.xerces.dom.AttrImpl;
import org.apache.xerces.dom.NodeImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.arisglobal.qnccore.service.GenericCrudService;
import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.RepeatableElement;
import com.arisglobal.validation.entities.ValidationError;
import com.arisglobal.validation.entities.XmlAttribute;
import com.arisglobal.validation.entities.XmlNode;
import com.arisglobal.validation.entities.XmlRule;
import com.arisglobal.validation.service.IR3ValidationService;
import com.arisglobal.validation.utils.DBConsts;
import com.arisglobal.validation.utils.DateFormatHelper;
import com.arisglobal.validation.utils.PositionalXmlReader;
import com.arisglobal.validation.utils.UnexpectedElementAttributeHelper;
import com.arisglobal.validation.validator.IValidator;
import com.arisglobal.validation.validator.impl.AttributeNodeValidator;
import com.arisglobal.validation.validator.impl.BasicRuleCriteriaValidator;
import com.arisglobal.validation.validator.impl.CustomImplementationValidator;
import com.arisglobal.validation.validator.impl.CustomValueValidator;
import com.arisglobal.validation.validator.impl.DateTimeValidator;
import com.arisglobal.validation.validator.impl.DictionaryValueValidator;
import com.arisglobal.validation.validator.impl.LengthValidator;
import com.arisglobal.validation.validator.impl.OIDValidator;
import com.arisglobal.validation.validator.impl.RegexpValidator;
import com.arisglobal.validation.validator.impl.SubRulesValidator;
import org.xml.sax.SAXException;

import static com.arisglobal.e2b.util.E2BXmlProcessor.getNewE2BCaseValidation;

@Service("r3ValidationService")
public class R3ValidationServiceImpl implements IR3ValidationService {
	
	@Autowired
	private GenericCrudService genericCrudService;

	@Autowired
	CodeListService codeListService;

	private static Logger agLogger = LoggerFactory.getLogger(IR3ValidationService.class);

	private Long customFormRecId;


	@Override
	public List<ValidationError> validate(InputStream inputStream) throws Exception {
		List<ValidationError> validationErrors = new LinkedList<>();	
		PositionalXmlReader positionalXmlReader = new PositionalXmlReader();
		//Read the document
		Document doc = null;
		try {
			doc = positionalXmlReader.readXML(inputStream);			
		} catch (Exception e) {			
			validationErrors.add(new ValidationError(1,
					"Could not read the document. Please check that document is an well-formed XML document",
					DBConsts.ERROR_LEVEL_ERROR_ID));
			e.printStackTrace();
			return validationErrors;
		}		
		List<XmlRule> xmlRules = genericCrudService.findAll(XmlRule.class);	
		//Group rules by context path			
		Map<String, List<XmlRule>> mapRuleContextToRules = groupRulesByContext(xmlRules);			
		//Processing rules with the same context in one scope just to increase validation performance
		for (Map.Entry<String, List<XmlRule>> entry : mapRuleContextToRules.entrySet()) {			
			String context = entry.getKey();			
			processXmlRules(doc, context, entry.getValue(), validationErrors);	
		}		
		return validationErrors;		
	}

	//Process Validation Rules within same context
	private void processXmlRules(Document doc, String context, List<XmlRule> rules, List<ValidationError> validationResults) throws Exception {		
		Date dateNow = Calendar.getInstance().getTime();	
		
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		List<DateFormat> dateFormatList  = genericCrudService.findAll(DateFormat.class);
		DateFormatHelper dateFormatHelper = new DateFormatHelper();
		List<IValidator> validatorList = initValidatorList();			
		IValidator subRulesValidator = new SubRulesValidator();
		IValidator customImplementationValidator = new CustomImplementationValidator();
		
		//Get Context Nodes
		NodeList nodes = null;
		try {			
			nodes = (NodeList) xpath.evaluate(context, doc, XPathConstants.NODESET);	
		} catch (XPathExpressionException e) {
			String ruleIds = rules
					.stream()
					.map(p -> p.getRecordId().toString())
					.collect(Collectors.joining(","));
			validationResults.add(new ValidationError(0, "Could not proceed Validation Rules. Ids = [" + ruleIds + "]. Please contact your system administrator to check rule parameters", DBConsts.ERROR_LEVEL_ERROR_ID));
			e.printStackTrace();
		} 				
		
		//Validating Rules If Context Found
		if (nodes != null && nodes.getLength() > 0) {	
			//TODO: uncomment and test it after all rules/nodes/attributes will be populated in DB
			//Validating for unexpected elements/attributes
			try {
				UnexpectedElementAttributeHelper unexpectedNodeHelper = new UnexpectedElementAttributeHelper();
				unexpectedNodeHelper.checkForUnnecessaryNodesAttributes(nodes, xpath, context, rules, validationResults);
			} catch (Exception e1) {				
				
			}
			for (XmlRule rule : rules) {							
				String errorText = rule.getErrorText();
				long errorLevel = rule.getErrorLevel().getRecordId();				
				try {
					//get repeatable element XPath and repeatable element depth level depending on Context XPath
					RepeatableElement repeatableElement = getRepeatableElement(rule);
					//processing repeatable elements
		        	for (int elementIndex = 1; elementIndex<=nodes.getLength(); elementIndex++) { 
		        		//Get Current Context Node and appropriate repeatable node
		        		Node currentNode = nodes.item(elementIndex - 1);		        		
		        		Node repeatableNode = getRepeatableNode(currentNode, repeatableElement, rule.getAttribute() != null);
		        				        		
		        		//Get line number of the context node
		        		Integer lineNumber = Integer.parseInt((String)((Element) currentNode).getUserData(PositionalXmlReader.LINE_NUMBER_KEY_NAME));	        		
		        		
		        		boolean validationResult = true;		            	
		            	boolean subRulesResults = true;
		            	
		            	//validating complex rules
		            	if (CollectionUtils.isNotEmpty(rule.getSubRules())) {	            		
	            			subRulesResults = subRulesValidator.validate(doc, currentNode, rule, null, false, dateFormatHelper, dateFormatList, dateNow, repeatableNode, repeatableElement);		            		
		            	}
		            	
		            	if (subRulesResults) {		            				            		
		            		//get value for check
		            		String value = getValue(rule, xpath, currentNode);		            		
		            		boolean valueIsEmpty = StringUtils.isEmpty(value);
		            		
							if (rule.getCustomHandler() != null){								
								//Process Custom Validation
								if (!customImplementationValidator.validate(doc, currentNode, rule, value, valueIsEmpty, dateFormatHelper, dateFormatList, dateNow, repeatableNode, repeatableElement)) validationResult = false;								
							} else {
								//Process Validations
								for (IValidator validator : validatorList) {
									if (!validator.validate(doc, currentNode, rule, value, valueIsEmpty, dateFormatHelper, dateFormatList, dateNow, repeatableNode, repeatableElement)) {
										validationResult = false;
										break;
									}
								}
							}		            																			            				      
		            	}             			            	
		            	if (!validationResult) {
		            		validationResults.add(new ValidationError(lineNumber, errorText, (int) errorLevel));
		            	}		        		
		          	}
				}
	        	catch (Exception e) {	        		
	    			validationResults.add(new ValidationError(0, "Could not proceed Validation Rule. Id = " + rule.getRecordId() + ". Please contact your system administrator to check rule parameters", (int) errorLevel));
	    			e.printStackTrace();
	        	}
			}			       					        		   
		}			
	}	
	
	

	//Get Attribute/Node value
	private String getValue(XmlRule rule, XPath xpath, Node currentNode) throws Exception {
		String value = null;
		if (rule.getNodeExistsCheck() != null && rule.getNodeExistsCheck()) {	            					            		
			NodeList nodesForCheck = (NodeList) xpath.evaluate(rule.getNode().getNodeIdentifier(), currentNode, XPathConstants.NODESET);			            			
			value = (nodesForCheck == null || nodesForCheck.getLength() == 0) ? null : "NODE";
		} else {
			String valueXPath;
			if (rule.getAttribute() != null) {
				String attributeIdentifier = rule.getAttribute().getAttributeIdentifier();
				if (attributeIdentifier.startsWith("count(")) {
					valueXPath = rule.getAttribute().getAttributeIdentifier();
				} else {
					valueXPath = XPATH_ATTRIBUTE_SYMBOL + rule.getAttribute().getAttributeIdentifier();
				}
			} else {
				valueXPath = rule.getNode().getNodeIdentifier() + XPATH_NODE_SEPARATOR + XPATH_NODE_VALUE;			
			}					
			value = (String) xpath.evaluate(valueXPath, currentNode, XPathConstants.STRING);			
		}	
		return value;
	}
	
	//initialize Validators
	private List initValidatorList() {	
		List validatorList = new LinkedList<>();
		validatorList.add(new BasicRuleCriteriaValidator());
		validatorList.add(new LengthValidator());
		validatorList.add(new RegexpValidator());
		validatorList.add(new DateTimeValidator());
		validatorList.add(new CustomValueValidator());
		validatorList.add(new DictionaryValueValidator());
		validatorList.add(new AttributeNodeValidator());
		validatorList.add(new OIDValidator());	
		return validatorList;
	}	

	//This method group validation Rules by Rule XPAth context
	private Map<String, List<XmlRule>> groupRulesByContext(List<XmlRule> xmlRules) {
		Map<String, List<XmlRule>> resultMap = new HashMap<>();
		for (XmlRule rule : xmlRules) {
			XmlAttribute attribute = rule.getAttribute();			
			boolean attributeBasedRule = attribute != null;
			XmlNode node =  rule.getNode();			
			String ruleContext = attributeBasedRule ? attribute.getNode().getXpath() + XPATH_NODE_SEPARATOR + attribute.getNode().getNodeIdentifier() : node.getXpath();	
			List<XmlRule> groupedRules;
			if (!resultMap.containsKey(ruleContext)) {
				groupedRules = new LinkedList<XmlRule>();
				resultMap.put(ruleContext, groupedRules);
			} else groupedRules = resultMap.get(ruleContext);
			groupedRules.add(rule);
		}
		return resultMap;
	}	
	
	//This method returns repeatable element XPath and repeatable element depth level depending on Rule Context XPath
	private RepeatableElement getRepeatableElement(XmlRule rule) throws XPathExpressionException {
		RepeatableElement repeatableElement = null;		
		XmlNode node = rule.getAttribute() == null ? rule.getNode() : rule.getAttribute().getNode();
		int level = 0;
		while (node != null && !node.getRepeatable()) {
			level ++;
			node = node.getParent();
		}
		if (node != null) {
			repeatableElement = new RepeatableElement(node.getXpath() + XPATH_NODE_SEPARATOR + node.getNodeIdentifier(), level);
		} 
		return repeatableElement;
	}	
	
	//This method returns repeatable Node
	private Node getRepeatableNode(Node currentNode, RepeatableElement repeatableElement, boolean attributeBasedRule) {
		Node repeatableNode = null;
		if (repeatableElement != null) {
			repeatableNode = currentNode;	
			int j = attributeBasedRule ? 1 : 2;
			for (;j <= repeatableElement.getLevel(); j++) {
				repeatableNode = repeatableNode.getParentNode();
			}	        				        			
		}
		return repeatableNode;
	}




	@Override
	public XMLCaseInfo parseXMLtoXMLR3CaseInfoForValidation(File e2bXmlFile, String e2bFileName, String messageType, E2BXmlProcessHelper e2bXmlProcessHelper,
															Boolean xsdValidationReq, Map<String, Integer> lineNoMapByTagId) throws IOException {
		XMLCaseInfo caseInfo = null;
		InputStream inputStream = null;
		String query = null;
		try {
			//Long formRecId = getCodeListByFieldId(e2bXmlProcessHelper);
			inputStream = getXMLInputStream(e2bXmlFile, e2bXmlProcessHelper);
			org.w3c.dom.Document e2bR3Xmldoc = null;

			PositionalXmlReader positionalXmlReader = new PositionalXmlReader();
			inputStream = getXMLInputStream(e2bXmlFile, e2bXmlProcessHelper);
			e2bR3Xmldoc = positionalXmlReader.readXML(inputStream);
			XMLTagLibraryMetaData xmlR3TagLibraryMetaData = XMLTagLibraryMetaDataHandler.getXMLR3TagLibraryMetaData(e2bXmlProcessHelper.getAgxPersistenceUnitName());
			boolean validationResult = true;
			if (xsdValidationReq) {
				validationResult = validateXmlUsingXsd(e2bXmlFile, e2bXmlProcessHelper);
			}

			if (validationResult) {
				caseInfo = loadDataFormXMLR3(e2bR3Xmldoc, e2bXmlProcessHelper, messageType, xmlR3TagLibraryMetaData, genericCrudService, xsdValidationReq, lineNoMapByTagId);
			}
			assert caseInfo != null;
			caseInfo.getE2bMessageInfo().setImportFileName(e2bFileName);
		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
		}

		return caseInfo;

	}

	private Long getCustomFormRecId(E2BXmlProcessHelper e2bXmlProcessHelper) {
		String query = null;
		Long formRecordId = null;
		if(null == customFormRecId){
			if ("NavaAer".equalsIgnoreCase(e2bXmlProcessHelper.getParentObjectType())) {
				query = "select customForm from CustomForm customForm where customForm.moduleType ='N' and" +
						" customForm.sourceFormType = '4' and customForm.formName = 'FULL DATA ENTRY FORM'";
			} else if ("InboundMessage".equalsIgnoreCase(e2bXmlProcessHelper.getParentObjectType())) {
				query = "select customForm from CustomForm customForm where customForm.moduleType ='I' and" +
						" customForm.sourceFormType = '4' and customForm.formName = 'FULL DATA ENTRY FORM'";

			}
			CustomForm customForm = null;
			try {
				customForm = (CustomForm) genericCrudService.findByQuery(query, null);
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (null != customForm) {
				formRecordId = customForm.getRecordId();
			}
		}
		return formRecordId;
	}

	private Map<String, Integer> getHeaderXpathCount(List<XMLTagInfo> xmlHeaderTagInfoList, org.w3c.dom.Document e2bR3Xmldoc, int rootIndex, XPath xPath, String oldXSD, String newXSD) {
		Map<String, Integer> headerTagMap = new LinkedHashMap<String, Integer>();
		try {
			for (XMLTagInfo xmlTagInfo : xmlHeaderTagInfoList) {
				String entityName = xmlTagInfo.getR3EntityName();
				String headerXpath = (Objects.isNull(xmlTagInfo.getR3Xpath()) ||
						xmlTagInfo.getR3Xpath().equalsIgnoreCase("")) ? xmlTagInfo.getEmaR3Xpath() : xmlTagInfo.getR3Xpath();

				if ("DrugReactRelatedness".equalsIgnoreCase(entityName) || "DrugCasualtyAssessment".equalsIgnoreCase(entityName)
						|| "PatientPastDrugSubstance".equalsIgnoreCase(entityName)) {
					continue;

				}

				if (null == headerXpath) {
					headerTagMap.put(entityName, 1);
					continue;
				} else {
					headerXpath = getXpath(headerXpath, rootIndex);
					//headerXpath = getWellConstructedXPathExpr(headerXpath, oldXSD, newXSD);
					headerXpath = removeInvalidXpathAttributeExpr(headerXpath);
					NodeList headerNodeList = (NodeList) xPath.compile(headerXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODESET);
					if (null != headerNodeList) {
						headerTagMap.put(entityName, headerNodeList.getLength());
					}
				}
			}
		} catch (XPathExpressionException e) {
			agLogger.error(e.getMessage(), e);
		}
		return headerTagMap;
	}

	private String getXpathForUUID(String headerXpath, String entityName, int count) {
		if ("Drug".equals(entityName)) {
			headerXpath = headerXpath + "[" + count + "]/substanceAdministration/id/@root";
		} else if ("Reaction".equals(entityName)) {
			headerXpath = headerXpath + "[" + count + "]/observation/id/@root";
		}
		return headerXpath;
	}

	private boolean validateXmlUsingXsd(File e2bXmlFile, E2BXmlProcessHelper e2bXmlProcessHelper) throws IOException {
		InputStream inputStream = getXMLInputStream(e2bXmlFile, e2bXmlProcessHelper);
		Source xmlFile = new StreamSource(inputStream);
		SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		try {
			URL schemaFile = R3ValidationServiceImpl.class.getClassLoader().getResource("/ICH_ICSR_Schema_Files/multicacheschemas/MCCI_IN200100UV01.xsd");

			Schema schema = schemaFactory.newSchema(schemaFile);
			Validator validator = schema.newValidator();
			validator.validate(xmlFile);
		} catch (SAXException | IOException e) {
			agLogger.error(e.getMessage(), e);
			return false;
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
		}
		return true;
	}

	private InputStream getXMLInputStream(File e2bXmlFile, E2BXmlProcessHelper e2bXmlProcessHelper) throws FileNotFoundException {
		InputStream inputStream = null;
		if (e2bXmlFile != null) {
			inputStream = new FileInputStream(e2bXmlFile);
		} else {
			inputStream = new ByteArrayInputStream(e2bXmlProcessHelper.getXmlString().getBytes());
		}
		return inputStream;
	}

	private XMLCaseInfo loadDataFormXMLR3(org.w3c.dom.Document e2bR3Xmldoc, E2BXmlProcessHelper e2bXmlProcessHelper,
										  String messageType, XMLTagLibraryMetaData xmlR3TagLibraryMetaData, GenericCrudService genericCrudService,
										  Boolean e2BValidatorFlag, Map<String, Integer> lineNoMapByTagId) {

		XPath xPath = javax.xml.xpath.XPathFactory.newInstance().newXPath();

		XMLCaseInfo xmlCaseInfo = null;
		List<E2BCaseValidations> caseValidations = new ArrayList<E2BCaseValidations>();

		try {
			Map<String, XMLTableInfo> tableInfoMap = xmlR3TagLibraryMetaData.getXmlImportTabInfoMapByMessageType().get(messageType);
			Set<Map.Entry<String, XMLTableInfo>> tableInfoEntrySet = tableInfoMap.entrySet();

			List<SafetyReport> safetyReportList = new ArrayList<>();
			Map<String, Object> objMap = new LinkedHashMap<String, Object>();

			String oldXSD = "@xsi:schemaLocation='urn:hl7-org:v3 MCCI_IN200100UV01.xsd'";
			String rootTag = "/MCCI_IN200100UV01[@ITSVersion='XML_1.0']";
			//String newXSD = null;
			/*if(e2BValidatorFlag){
				newXSD = xPath.compile(getWellConstructedXPathExpr(rootTag, null, null) + "/@xsi:schemaLocation").evaluate(e2bR3Xmldoc);
				newXSD = "@xsi:schemaLocation='" + newXSD + "'";
			}*/
			String newXSD = "@xsi:schemaLocation='urn:hl7-org:v3 MCCI_IN200100UV01.xsd'"; //urn:hl7-org:v3 MCCI_IN200100UV01.xsd
			String caseReportHeaderXpath = rootTag + "[" + oldXSD + "]/PORR_IN049016UV";
			caseReportHeaderXpath = removeInvalidXpathAttributeExpr(caseReportHeaderXpath);
			NodeList rootNodeList = (NodeList) xPath.compile(caseReportHeaderXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODESET);

			//To set source document to case
			Map<String, List<Object>> inboundDocmap = new LinkedHashMap<String, List<Object>>();

			List<XMLTagInfo> xmlHeaderTagInfoList = genericCrudService.findAllByNamedQuery("XMLTagInfo.findAllHeaderXpathByR3Repetable", messageType, "1");
			// Loop on number of Messages(PORR_IN049016UV)
			List<String> drugUIDList = new LinkedList<>();
			List<String> reactUIDList = new LinkedList<>();

			for (int rootIndex = 1; rootIndex <= rootNodeList.getLength(); rootIndex++) {

				List<Object> inboundSupportDocumentsList = new ArrayList<Object>();

				Map<String, Integer> xmlHeaderXpathList = getHeaderXpathCount(xmlHeaderTagInfoList, e2bR3Xmldoc, rootIndex, xPath, oldXSD, newXSD);
				SafetyReport safetyReportTemp = null;

				// XMl Table Info
				for (Map.Entry<String, XMLTableInfo> tableInfoEntry : tableInfoEntrySet) {
					XMLTableInfo xmlTableInfo = tableInfoEntry.getValue();
					String entityName = xmlTableInfo.getEntityName();

					if ("XMLCaseInfo".equals(entityName)) {
						Class<?> aeParentClass = Class.forName(xmlTableInfo.getEntityPkgName() + xmlTableInfo.getEntityName());
						Object aeParentObject = aeParentClass.newInstance();
						if (aeParentObject instanceof XMLCaseInfo) {
							xmlCaseInfo = (XMLCaseInfo) aeParentObject;
							continue;
						}
					} else if ("DrugCasualtyAssessment".equalsIgnoreCase(entityName) || "PatientPastDrugSubstance".equalsIgnoreCase(entityName)
							|| "ParentPastDrugSubstance".equalsIgnoreCase(entityName)) {
						continue;
					}
					//	Integer headerCountForCurrentEntitiy = xmlHeaderXpathList.get(entityName);
					if ("DrugReactRelatedness".equalsIgnoreCase(entityName)) {
						Map<String, Map<String, List<DrugReactRelatedness>>> reactRelatednessesMap = setNodeValueForDrugReactRelatedness(rootIndex, e2bR3Xmldoc, e2bXmlProcessHelper, messageType,
								xPath, xmlTableInfo, drugUIDList, reactUIDList, oldXSD, newXSD, e2BValidatorFlag, lineNoMapByTagId);
						objMap.put(entityName, reactRelatednessesMap);
					} else if (null != xmlHeaderXpathList.get(entityName)) {
						int count = xmlHeaderXpathList.get(entityName);
						List<Object> aeChildObj = setNodeValueForRepeatable(caseValidations, rootIndex, e2bR3Xmldoc, e2bXmlProcessHelper, messageType, xPath,
								xmlTableInfo, count, entityName, drugUIDList, reactUIDList, genericCrudService, inboundSupportDocumentsList, xmlHeaderTagInfoList,
								oldXSD, newXSD, e2BValidatorFlag, lineNoMapByTagId);
						objMap.put(entityName, aeChildObj);
    /*                        if ("Drug".equalsIgnoreCase(entityName)) {
                                for (Object object : aeChildObj) {
                                    Drug drug = (Drug) object;
                                    drugUIDList.add(drug.getDrugUUID());
                                }
                            } else if ("Reaction".equalsIgnoreCase(entityName)) {
                                for (Object object : aeChildObj) {
                                    Reaction reaction = (Reaction) object;
                                    reactUIDList.add(reaction.getReactionUUID());
                                }
                            }*/
					} else {
						Object obj = setNodeValueForNonRepetable(caseValidations, rootIndex, e2bR3Xmldoc, e2bXmlProcessHelper, messageType, xPath, xmlTableInfo,
								entityName, safetyReportTemp, inboundSupportDocumentsList, oldXSD, newXSD, e2BValidatorFlag, lineNoMapByTagId);
						objMap.put(entityName, obj);
					}

				}
				SafetyReport finalSafety = assignObjectToSafetyReportList(e2bXmlProcessHelper, messageType, safetyReportTemp, tableInfoEntrySet, objMap);
				setCaseNullificationDetails(finalSafety);
				String safetyReportId = finalSafety.getSafetyReportId();
				inboundDocmap.put(safetyReportId, inboundSupportDocumentsList);
				safetyReportList.add(finalSafety);
			}

			xmlCaseInfo = assignObjectToPartent(xmlCaseInfo, safetyReportList, objMap);
			e2bXmlProcessHelper.setAttachedDocumentIdsMap(inboundDocmap);

		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
		}


		return xmlCaseInfo;
	}

	private void setCaseNullificationDetails(SafetyReport safetyReport) {
		if (null != safetyReport.getCaseNullification() && safetyReport.getCaseNullification().trim().length() != 0 && "2".equals(safetyReport.getCaseNullification())) {
			safetyReport.setCaseAmendment("1");
			safetyReport.setCaseNullification(null);
		}
	}

	private int findLength(int allowedFieldLenght, XMLTagInfo currentTagValidations, String tagValue) {
		if ("N".equalsIgnoreCase(currentTagValidations.getE2bDataType())) {
			try {
				Long.parseLong(tagValue);
			} catch (Exception e) {
				try {
					Double.parseDouble(tagValue);
					allowedFieldLenght++;
				} catch (Exception e1) {
					// intentionally left blank
				}
			}

		}
		return allowedFieldLenght;
	}

	private boolean isValueAllowed(String tagValue, String allowedValues) {
		boolean isValueAllowed = false;
		if (null != allowedValues) {
			String[] allowedValuesList = allowedValues.split(",");
			for (String value : allowedValuesList) {
				if (tagValue.equals(value.trim())) {
					isValueAllowed = true;
					break;
				}
			}
		}
		return isValueAllowed;
	}

	private boolean checktNullAndNotEmptyWithoutTrim(String value) {
		if (null == value) {
			return false;
		}

		// Trim only if properties parameter is enabled
		if (AgUtilHelper.isTextDataTrimEnabled()) {
			value = value.trim();
		}

		if (value.length() < 1 || "null".equalsIgnoreCase(value)) {
			return false;
		} else {
			return true;
		}
	}

	private Map<String, Map<String, List<DrugReactRelatedness>>> setNodeValueForDrugReactRelatedness(int rootIndex,
																									 org.w3c.dom.Document e2bR3Xmldoc,
																									 E2BXmlProcessHelper e2bXmlProcessHelper, String messageType, XPath xPath,
																									 XMLTableInfo xmlTableInfo,
																									 List<String> drugUIDList, List<String> reactUIDList,
																									 String oldXSD, String newXSD, Boolean e2BValidatorFlag,
																									 Map<String, Integer> lineNoMapByTagId)
			throws XPathExpressionException, ClassNotFoundException, NoSuchFieldException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {

		Map<String, Map<String, List<DrugReactRelatedness>>> reactRelatednessesMap = new LinkedHashMap<String, Map<String, List<DrugReactRelatedness>>>();
		Map<String, List<DrugReactRelatedness>> drugReactMap = new LinkedHashMap<String, List<DrugReactRelatedness>>();
		String headerKey = null;
		Long formRecId = getCustomFormRecId(e2bXmlProcessHelper);
		String entityName = null;
		Map<String, XMLTagInfo> tagInfoMap = XMLTagLibraryMetaDataHandler.getXMLR3TagLibraryMetaData(e2bXmlProcessHelper.getAgxPersistenceUnitName())
				.getXmlImportTagInfoMapByMessageType().get(messageType).get(xmlTableInfo.getEntityName());
		Set<Map.Entry<String, XMLTagInfo>> entrySet = tagInfoMap.entrySet();
		for (Map.Entry<String, XMLTagInfo> entry : entrySet) {
			if ("1".equals(entry.getValue().getR3Header())) {
				headerKey = entry.getKey();
				break;
			}
		}

		XMLTagInfo xmlTagInfoHeader = tagInfoMap.get(headerKey);
		String metaDataXpath = xmlTagInfoHeader.getR3Xpath();
            /*String componentXpath = "/MCCI_IN200100UV01[@ITSVersion='XML_1.0']/PORR_IN049016UV["
                    + +rootIndex + "]/controlActProcess[@classCode='CACT'][@moodCode='EVN']/subject[@typeCode='SUBJ'][1]/"
                    + "investigationEvent[@classCode='INVSTG'][@moodCode='EVN']/component[@typeCode='COMP'][adverseEventAssessment][1]/adverseEventAssessment[@classCode='INVSTG']"
                    + "[@moodCode='EVN']/component[@typeCode='COMP'][causalityAssessment/code[@code='39'][@codeSystem='2.16.840.1.113883.3.989.2.1.1.19']]";

            componentXpath = getWellConstructedXPathExpr(componentXpath, oldXSD, newXSD);
            NodeList componentNodeList = (NodeList) xPath.compile(componentXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODESET);*/
		int drugCount = 0;
		//String[] causalityNodeNames = {"value", "originalText"};
		for (String drugUUId : drugUIDList) {
			drugCount++;
			for (String reactionUUId : reactUIDList) {
				Class<?> aeChildClass = Class.forName(xmlTableInfo.getEntityPkgName() + xmlTableInfo.getEntityName());
				Object aeChildObject = null;
				List<DrugReactRelatedness> drugReactList = new LinkedList<>();
				List<DrugCasualtyAssessment> casualtyAssessmentList = new LinkedList<>();
				try {
					// create class instance
					aeChildObject = aeChildClass.newInstance();

					for (Map.Entry<String, XMLTagInfo> xmlTagInfoEntry : tagInfoMap.entrySet()) {
						XMLTagInfo xmlTagInfo = xmlTagInfoEntry.getValue();
						entityName = xmlTagInfo.getR3EntityName();
						if ("1".equalsIgnoreCase(xmlTagInfo.getR3Header())) {
							continue;
						}
						String entityField = xmlTagInfo.getEntityField();
						String r3Xpath = (Objects.isNull(xmlTagInfo.getR3Xpath()) ||
								xmlTagInfo.getR3Xpath().equalsIgnoreCase("")) ? xmlTagInfo.getEmaR3Xpath() : xmlTagInfo.getR3Xpath();
						String splitCh = "\\[k]";
						r3Xpath = getChildXpath(r3Xpath, rootIndex, drugCount, splitCh);
						r3Xpath = getXpathForDrugReactRelatedness(reactionUUId, drugUUId, r3Xpath, rootIndex, drugCount, splitCh);

						r3Xpath = removeInvalidXpathAttributeExpr(r3Xpath);
						Node childNode = (Node) xPath.compile(r3Xpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);

						if (null != childNode) {
							if(r3Xpath.endsWith("()")){
								setLineNumberMap("TEXT", xmlTagInfo, childNode, lineNoMapByTagId);
							}else if(r3Xpath.endsWith("]")){
								setLineNumberMap("NODE", xmlTagInfo, childNode, lineNoMapByTagId);
							}else{
								setLineNumberMap("ATTRIBUTE", xmlTagInfo, childNode, lineNoMapByTagId);
							}
							String nodeValue = childNode.getNodeValue();
							setCausalityDataWithReflection(e2bXmlProcessHelper, formRecId, aeChildClass, aeChildObject, xmlTagInfo, entityField, nodeValue, 0);

						} else {
							r3Xpath = xmlTagInfo.getEmaR3Xpath();
							if (null == r3Xpath || r3Xpath.equalsIgnoreCase("")) {
								continue;
							}
							r3Xpath = getChildXpath(r3Xpath, rootIndex, drugCount, splitCh);
							r3Xpath = getXpathForDrugReactRelatedness(reactionUUId, drugUUId, r3Xpath, rootIndex, drugCount, splitCh);
							r3Xpath = removeInvalidXpathAttributeExpr(r3Xpath);
							childNode = (Node) xPath.compile(r3Xpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
							if (null == childNode) {
								continue;
							}
							if(r3Xpath.endsWith("()")){
								setLineNumberMap("TEXT", xmlTagInfo, childNode, lineNoMapByTagId);
							}else if(r3Xpath.endsWith("]")){
								setLineNumberMap("NODE", xmlTagInfo, childNode, lineNoMapByTagId);
							}else{
								setLineNumberMap("ATTRIBUTE", xmlTagInfo, childNode, lineNoMapByTagId);
							}
							String nodeValue = childNode.getNodeValue();
							setCausalityDataWithReflection(e2bXmlProcessHelper, formRecId, aeChildClass, aeChildObject, xmlTagInfo, entityField, nodeValue, 0);
						}

					}
					XMLTableInfo childXmlTableInfo = XMLTagLibraryMetaDataHandler.getXMLTagLibraryMetaData(e2bXmlProcessHelper.getAgxPersistenceUnitName()).
							getXmlImportTabInfoMapByMessageType().get(messageType).get("142");
					setNodeValueForDrugCasualtyAssessment(rootIndex, e2bR3Xmldoc, e2bXmlProcessHelper, messageType, xPath, childXmlTableInfo,
							drugUUId, reactionUUId, drugCount, oldXSD, newXSD, aeChildObject, casualtyAssessmentList, e2BValidatorFlag, lineNoMapByTagId);

					DrugReactRelatedness drugReactRelatedness = (DrugReactRelatedness) aeChildObject;
					((DrugReactRelatedness) aeChildObject).setReactionUUID(reactionUUId);

					if (null != drugReactRelatedness) {
						DrugReactRelatedness tempDrugReactRelatedness = (DrugReactRelatedness) aeChildObject;
						tempDrugReactRelatedness.setDrugCasualtyAssessmentCollection(casualtyAssessmentList);
						drugReactList.add(tempDrugReactRelatedness);
						List<DrugReactRelatedness> tmpList = null;
						tmpList = null != drugReactMap.get(drugUUId) ? drugReactMap.get(drugUUId) : new ArrayList<>();
						tmpList.addAll(drugReactList);
						drugReactMap.put(drugUUId, tmpList);
					}
				} catch (Exception e) {
					agLogger.error("Entity name : " + xmlTableInfo.getEntityName());
					agLogger.error(e.getMessage(), e);
				}
			}
		}
		reactRelatednessesMap.put(entityName, drugReactMap);
		return reactRelatednessesMap;
	}

	private void setLineNumberMap(String condition, XMLTagInfo xmlTagInfo, Node childNode, Map<String, Integer> lineNoMapByTagId) {
		try{
			//String keyTag = replaceRepetableTagId(xmlTagInfo.getTagID(), count);
			if("ATTRIBUTE".equalsIgnoreCase(condition)){
				AttrImpl attrNode = (AttrImpl) childNode;
				lineNoMapByTagId.put(xmlTagInfo.getTagID(), Integer.parseInt((String) ((org.w3c.dom.Element) attrNode.getOwnerElement()).getUserData(PositionalXmlReader.LINE_NUMBER_KEY_NAME)));
			}else if("NODE".equalsIgnoreCase(condition)){
				NodeImpl nodeImpl = (NodeImpl)childNode;
				lineNoMapByTagId.put(xmlTagInfo.getTagID(), Integer.parseInt((String)((org.w3c.dom.Element) nodeImpl.getParentNode()).getUserData(PositionalXmlReader.LINE_NUMBER_KEY_NAME)));
			}else if("TEXT".equalsIgnoreCase(condition)){
				lineNoMapByTagId.put(xmlTagInfo.getTagID(), Integer.parseInt((String)((org.w3c.dom.Element) childNode.getParentNode()).getUserData(PositionalXmlReader.LINE_NUMBER_KEY_NAME)));
			}
		}catch (Exception e){

		}
	}

	private String replaceRepetableTagId(String tagID, int count) {
		if(tagID.contains("k") && count != 0){
			return tagID.replace("k", String.valueOf(count));
		}else if(tagID.contains("r")){
			return tagID.replace("r", String.valueOf(count));
		}else if(tagID.contains("i")){
			return tagID.replace("i", String.valueOf(count));

		}

		return  tagID;
	}

	private void setNodeValueForDrugCasualtyAssessment(int rootIndex,
													   org.w3c.dom.Document e2bR3Xmldoc,
													   E2BXmlProcessHelper e2bXmlProcessHelper, String messageType, XPath xPath,
													   XMLTableInfo xmlTableInfo,
													   String drugUUId, String reactionUUId, int drugCount,
													   String oldXSD, String newXSD, Object aeParentObject, List<DrugCasualtyAssessment> casualtyAssessmentList,
													   Boolean e2BValidatorFlag, Map<String, Integer> lineNoMapByTagId)
			throws XPathExpressionException, ClassNotFoundException, NoSuchFieldException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {

		Map<String, Map<String, List<DrugCasualtyAssessment>>> casualtyAssessmentMap = new LinkedHashMap<String, Map<String, List<DrugCasualtyAssessment>>>();
		//List<DrugCasualtyAssessment> casualtyAssessmentList = new LinkedList<>();
		String headerKey = null;
		Long formRecId = getCustomFormRecId(e2bXmlProcessHelper);
		String entityName = null;
		Map<String, XMLTagInfo> tagInfoMap = XMLTagLibraryMetaDataHandler.getXMLR3TagLibraryMetaData(e2bXmlProcessHelper.getAgxPersistenceUnitName())
				.getXmlImportTagInfoMapByMessageType().get(messageType).get(xmlTableInfo.getEntityName());
		Set<Map.Entry<String, XMLTagInfo>> entrySet = tagInfoMap.entrySet();
		for (Map.Entry<String, XMLTagInfo> entry : entrySet) {
			if ("1".equals(entry.getValue().getR3Header())) {
				headerKey = entry.getKey();
				break;
			}
		}

		XMLTagInfo xmlTagInfoHeader = tagInfoMap.get(headerKey);
		String metaDataXpath = xmlTagInfoHeader.getR3Xpath();
            /*String componentXpath = "/MCCI_IN200100UV01[@ITSVersion='XML_1.0']/PORR_IN049016UV["
                    + +rootIndex + "]/controlActProcess[@classCode='CACT'][@moodCode='EVN']/subject[@typeCode='SUBJ'][1]/"
                    + "investigationEvent[@classCode='INVSTG'][@moodCode='EVN']/component[@typeCode='COMP'][adverseEventAssessment][1]/adverseEventAssessment[@classCode='INVSTG']"
                    + "[@moodCode='EVN']/component[@typeCode='COMP'][causalityAssessment/code[@code='39'][@codeSystem='2.16.840.1.113883.3.989.2.1.1.19']]";

            componentXpath = getWellConstructedXPathExpr(componentXpath, oldXSD, newXSD);
            NodeList componentNodeList = (NodeList) xPath.compile(componentXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODESET);*/
		//String[] causalityNodeNames = {"value", "originalText"};
		Class<?> aeChildClass = Class.forName(xmlTableInfo.getEntityPkgName() + xmlTableInfo.getEntityName());
		Object aeChildObject = null;
		try {
			String validXpath = getXpathForDrugReactRelatednessForcausalityAssessmentCount(reactionUUId, drugUUId, metaDataXpath, rootIndex);
			NodeList nodeList = checkForR3NodeList(e2bR3Xmldoc, xPath, validXpath, oldXSD, newXSD);
			String[] causalityNodeNames = {"value", "originalText", "code", "methodCode"};
			String[] emaCausalityNodeNames = {"code", "methodCode", "value"};
			List<DrugReactRelatedness> drugReactList = new LinkedList<>();
			if(null!=nodeList) {
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node causalityNode = nodeList.item(i);
				NodeList causalityNodeItems = ((NodeList) xPath.compile(".//*//*").evaluate(causalityNode, XPathConstants.NODESET));
				String causalitySource = null;
				String causalityMethod = null;
				String causalityResult = null;

				int causalitySourceCoded = 0;
				int causalityMethodCoded = 0;
				int causalityResultCoded = 0;

				for (int j = 0; j < causalityNodeItems.getLength(); j++) {
					Node item = causalityNodeItems.item(j);
					if (Arrays.asList(causalityNodeNames).contains(item.getNodeName())) {
						if ("value".equals(item.getNodeName())) {
							causalityResult = item.getTextContent();
							if (null == causalityResult || "".equalsIgnoreCase(causalityResult)) {
								causalityResult = (item.getAttributes().getLength() > 0) ? ((item.getAttributes().getNamedItem("code") != null) ?
										(item.getAttributes().getNamedItem("code").getNodeValue()) : null) : null;
								if (null != causalityResult) {
									causalityResultCoded = 1;
								}
							}
							causalityResult = (null != causalityResult && causalityResult.trim().length() != 0) ? causalityResult.trim() : null;
						} else if ("originalText".equals(item.getNodeName())) {
							String parentNodeName = item.getParentNode().getNodeName();
							if ("methodCode".equals(parentNodeName)) {
								causalityMethod = item.getTextContent();
								causalityMethod = (null != causalityMethod && causalityMethod.trim().length() != 0) ? causalityMethod.trim() : null;
							} else {
								parentNodeName = item.getParentNode().getNodeName();
								if ("code".equals(parentNodeName)) {
									parentNodeName = item.getParentNode().getParentNode().getNodeName();
									if ("assignedEntity".equals(parentNodeName)) {
										causalitySource = item.getTextContent();
										causalitySource = (null != causalitySource && causalitySource.trim().length() != 0) ? causalitySource.trim() : null;

									}
								}
							}
						}

						if ("code".equals(item.getNodeName())) {
							String parentNodeName = item.getParentNode().getNodeName();
							if ("assignedEntity".equals(parentNodeName)) {
								parentNodeName = item.getParentNode().getParentNode().getNodeName();
								if ("author".equals(parentNodeName)) {
									if (null == causalitySource) {
										causalitySource = (item.getAttributes().getLength() > 0) ? ((item.getAttributes().getNamedItem("code") != null) ?
												(item.getAttributes().getNamedItem("code").getNodeValue()) : null) : null;
										if (null != causalitySource) {
											causalitySourceCoded = 1;
										}
									}
								}
							}

						}
						if ("methodCode".equals(item.getNodeName())) {
							String parentNodeName = item.getParentNode().getNodeName();
							if ("causalityAssessment".equals(parentNodeName)) {
								parentNodeName = item.getParentNode().getParentNode().getNodeName();
								if ("component".equals(parentNodeName)) {
									if (null == causalityMethod) {
										causalityMethod = (item.getAttributes().getLength() > 0) ? ((item.getAttributes().getNamedItem("code") != null) ?
												(item.getAttributes().getNamedItem("code").getNodeValue()) : null) : null;
										if (null != causalityMethod) {
											causalityMethodCoded = 1;
										}
									}
								}
							}
						}
					}
				}

				// create class instance
				aeChildObject = aeChildClass.newInstance();
				String xpathForDrugReactRelatedness = "";
				for (Map.Entry<String, XMLTagInfo> xmlTagInfoEntry : tagInfoMap.entrySet()) {
					XMLTagInfo xmlTagInfo = xmlTagInfoEntry.getValue();
					entityName = xmlTagInfo.getR3EntityName();
					if ("1".equals(xmlTagInfo.getR3Header())) {
						continue;
					}
					String entityField = xmlTagInfo.getEntityField();
					if ("CausalitySource".equals(entityField)) {
						if (null != causalitySource && causalitySource.trim().length() != 0)
							setCausalityDataWithReflection(e2bXmlProcessHelper, formRecId, aeChildClass, aeChildObject, xmlTagInfo, entityField, causalitySource, causalitySourceCoded);
						causalitySourceCoded = 0;

					} else if ("Method".equals(entityField)) {
						if (null != causalityMethod && causalityMethod.trim().length() != 0)
							setCausalityDataWithReflection(e2bXmlProcessHelper, formRecId, aeChildClass, aeChildObject, xmlTagInfo, entityField, causalityMethod, causalityMethodCoded);
						causalityMethodCoded = 0;

					} else if ("DrugResult".equals(entityField)) {
						if (null != causalityResult && causalityResult.trim().length() != 0)
							setCausalityDataWithReflection(e2bXmlProcessHelper, formRecId, aeChildClass, aeChildObject, xmlTagInfo, entityField, causalityResult, causalityResultCoded);
						causalityResultCoded = 0;

					} else {
						String r3Xpath = (Objects.isNull(xmlTagInfo.getR3Xpath()) ||
								xmlTagInfo.getR3Xpath().equalsIgnoreCase("")) ? xmlTagInfo.getEmaR3Xpath() : xmlTagInfo.getR3Xpath();
						String splitCh = "\\[r]";
						xpathForDrugReactRelatedness = getXpathForDrugReactRelatedness(reactionUUId, drugUUId, r3Xpath, rootIndex, drugCount, splitCh);
						//xpathForDrugReactRelatedness = getWellConstructedXPathExpr(xpathForDrugReactRelatedness, oldXSD, newXSD);
						xpathForDrugReactRelatedness = removeInvalidXpathAttributeExpr(xpathForDrugReactRelatedness);

						Node childNode = (Node) xPath.compile(xpathForDrugReactRelatedness).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
						if (null != childNode) {
							if(r3Xpath.endsWith("()")){
								setLineNumberMap("TEXT", xmlTagInfo, childNode, lineNoMapByTagId);
							}else if(r3Xpath.endsWith("]")){
								setLineNumberMap("NODE", xmlTagInfo, childNode, lineNoMapByTagId);
							}else{
								setLineNumberMap("ATTRIBUTE", xmlTagInfo, childNode, lineNoMapByTagId);
							}
							String nodeValue = childNode.getNodeValue();
							setCausalityDataWithReflection(e2bXmlProcessHelper, formRecId, aeChildClass, aeChildObject, xmlTagInfo, entityField, nodeValue, 0);
						}
					}
				}

				DrugCasualtyAssessment drugCasualtyAssessment = (DrugCasualtyAssessment) aeChildObject;

				if (null != drugCasualtyAssessment) {
					boolean checkFlag = drugCasualtyAssessment.getMethod() != null ||
							drugCasualtyAssessment.getCausalitySource() != null || drugCasualtyAssessment.getDrugResult() != null
							|| drugCasualtyAssessment.getMethodSF() != null || drugCasualtyAssessment.getDrugResultSF() != null || drugCasualtyAssessment.getCausalitySourceSF() != null;
					if (checkFlag) {
						casualtyAssessmentList.add((DrugCasualtyAssessment) aeChildObject);
					}
				}

			}
		}




                /*for (int i = 1; i < nodeList.getLength()+1; i++) {
                    // create class instance
                    aeChildObject = aeChildClass.newInstance();

                    for (Entry<String, XMLTagInfo> xmlTagInfoEntry : tagInfoMap.entrySet()) {
                        XMLTagInfo xmlTagInfo = xmlTagInfoEntry.getValue();
                        if("1".equalsIgnoreCase(xmlTagInfo.getR3Header())){
                            continue;
                        }
                        String entityField = xmlTagInfo.getEntityField();
                        String r3Xpath = xmlTagInfo.getR3Xpath();
                        String splitCh = "\\[r]";
                        String xpathForDrugReactRelatedness = getXpathForDrugReactRelatedness(reactionUUId, drugUUId, r3Xpath, rootIndex, i, splitCh);
                        xpathForDrugReactRelatedness = getWellConstructedXPathExpr(xpathForDrugReactRelatedness, oldXSD, newXSD);
                        Node childNode = (Node) xPath.compile(xpathForDrugReactRelatedness).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
                        if (null != childNode && null != childNode.getNodeValue()) {
                            // String nodeValue = childNode.getNodeValue();
                            String causality = childNode.getTextContent();
                            causality = (null != causality && causality.trim().length() != 0) ? causality.trim() : null;
                            setCausalityDataWithReflection(e2bXmlProcessHelper, formRecId, aeChildClass, aeChildObject, xmlTagInfo, entityField, causality);

                        }
                    }

                    DrugCasualtyAssessment drugCasualtyAssessment = (DrugCasualtyAssessment) aeChildObject;

                    if (null != drugCasualtyAssessment) {
                        boolean checkFlag = drugCasualtyAssessment.getMethod() != null ||
                                drugCasualtyAssessment.getCausalitySource() != null || drugCasualtyAssessment.getDrugResult() != null
                                || drugCasualtyAssessment.getMethodSF() != null || drugCasualtyAssessment.getDrugResultSF() != null || drugCasualtyAssessment.getCausalitySourceSF() != null;
                        if (checkFlag) {
                            casualtyAssessmentList.add((DrugCasualtyAssessment) aeChildObject);
                        }
                    }

                }*/


		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
		}
		// DrugReactRelatedness drugReactRelatedness = (DrugReactRelatedness) aeParentObject;
		//drugReactRelatedness.setDrugCasualtyAssessmentCollection(casualtyAssessmentList);
		//casualtyAssessmentMap.put(entityName, casualtyAssessmentList);
		// return casualtyAssessmentList;
	}

	private void setCausalityDataWithReflection(E2BXmlProcessHelper e2bXmlProcessHelper, Long formRecId, Class<?> aeChildClass, Object aeChildObject,
												XMLTagInfo xmlTagInfo, String entityField, String nodeValue, int coded) throws Exception {
		String codeListId = null;
		String nodeValueFromCodelist = null;
		if (null != xmlTagInfo.getFieldId()) {

			codeListId = getCodeListByFieldId(xmlTagInfo.getFieldId(), formRecId, e2bXmlProcessHelper);
			if(null == codeListId){
				if("CausalitySource".equalsIgnoreCase(xmlTagInfo.getEntityField())){
					codeListId = "9055";
				}else if("Method".equalsIgnoreCase(xmlTagInfo.getEntityField())){
					codeListId = "9056";
				}else if("DrugResult".equalsIgnoreCase(xmlTagInfo.getEntityField())){
					codeListId = "9062";
				}
			}
		}
		boolean result = false;
		if (null != xmlTagInfo.getAllowedValues()) {
			String allowedValue[] = xmlTagInfo.getAllowedValues().split(",");
			List<String> allowedValuesList = Arrays.asList(allowedValue);
			result = allowedValuesList.contains(nodeValue);
		}
		if (null != codeListId && !"0".equals(codeListId) && !"null".equals(codeListId)) {
			if (!result) {
				nodeValueFromCodelist = getCodeFromCodeList(codeListId, nodeValue);
				if (coded == 1) {
					// String nodeDecodeValue = getEmaR3DecodedValueFromCode(codeListId, nodeValue);
					String codeFromEmaR3Code = getCodeFromEmaR3Code(codeListId, nodeValue);
					if (null != codeFromEmaR3Code || "".equals(codeFromEmaR3Code)) {
						String nodeDecodeValue = getDecodedValueFromCode(codeListId, codeFromEmaR3Code);
						if ((null != nodeDecodeValue || !"".equals(nodeDecodeValue)) && xmlTagInfo.getFreeText()) {
							nodeValue = nodeDecodeValue;
							nodeValueFromCodelist = "";
						}
					}
				}

				if (null != nodeValueFromCodelist && nodeValueFromCodelist.length() != 0) {
					nodeValue = nodeValueFromCodelist;
				}
			}
		}
		Field destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1));
		Method destMethod = aeChildClass.getMethod("set" + entityField, destField.getType());

		if (null != codeListId && !"0".equals(codeListId) && "".equals(nodeValueFromCodelist) && "True".equalsIgnoreCase(String.valueOf(xmlTagInfo.getFreeText()))) {
			destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1) + "SF");
			destMethod = aeChildClass.getMethod("set" + entityField + "SF", destField.getType());
		}
		// identify the field type in entity class
		Class<?> childElementTypeClass = Class.forName(destField.getType().getCanonicalName());
		Object convertedChildElementValue = convertToSpecificType(childElementTypeClass,
				nodeValue, aeChildObject, xmlTagInfo, aeChildClass);
		if (null != convertedChildElementValue
				&& convertedChildElementValue.toString().length() > 0) {
			destMethod.invoke(aeChildObject, convertedChildElementValue);
		}
	}

	private Map<String, Map<String, List<DrugReactRelatedness>>> setNodeValueForDrugReactRelatedness1(int rootIndex,
																									  org.w3c.dom.Document e2bR3Xmldoc,
																									  E2BXmlProcessHelper e2bXmlProcessHelper, String messageType, XPath xPath,
																									  XMLTableInfo xmlTableInfo,
																									  List<String> drugUIDList, List<String> reactUIDList,
																									  String oldXSD, String newXSD, Map<String, Integer> lineNoMapByTagId)
																										throws XPathExpressionException, ClassNotFoundException {

		Map<String, Map<String, List<DrugReactRelatedness>>> reactRelatednessesMap = new LinkedHashMap<String, Map<String, List<DrugReactRelatedness>>>();
		Map<String, List<DrugReactRelatedness>> drugReactMap = new LinkedHashMap<String, List<DrugReactRelatedness>>();
		String codeListId = null;
		String entityName = null;
		String headerKey = null;
		Method destMethod;
		Field destField;
		Long formRecId = null;

		//Getting FormRecordId
		formRecId = getCustomFormRecId(e2bXmlProcessHelper);

		Map<String, XMLTagInfo> tagInfoMap = XMLTagLibraryMetaDataHandler.getXMLR3TagLibraryMetaData(e2bXmlProcessHelper.getAgxPersistenceUnitName())
				.getXmlImportTagInfoMapByMessageType().get(messageType).get(xmlTableInfo.getEntityName());
            /*Set<String> keys = tagInfoMap.keySet();
            for(String key: keys) {
                if (key.contains("DrugReactRelatednessCollection")) {
                    headerKey = key.substring(0, key.lastIndexOf(":"));
                }
            }*/

		Set<Map.Entry<String, XMLTagInfo>> entrySet = tagInfoMap.entrySet();
		for (Map.Entry<String, XMLTagInfo> entry : entrySet) {
			if ("1".equals(entry.getValue().getR3Header())) {
				headerKey = entry.getKey();
				break;
			}
		}

		// XMLTagInfo xmlTagInfoHeader = tagInfoMap.get("DrugReactRelatednessCollection");
		XMLTagInfo xmlTagInfoHeader = tagInfoMap.get(headerKey);
		String metaDataXpath = xmlTagInfoHeader.getR3Xpath();
		String componentXpath = "/MCCI_IN200100UV01[@ITSVersion='XML_1.0']/PORR_IN049016UV["
				+ +rootIndex + "]/controlActProcess[@classCode='CACT'][@moodCode='EVN']/subject[@typeCode='SUBJ'][1]/"
				+ "investigationEvent[@classCode='INVSTG'][@moodCode='EVN']/component[@typeCode='COMP'][adverseEventAssessment][1]/adverseEventAssessment[@classCode='INVSTG']"
				+ "[@moodCode='EVN']/component[@typeCode='COMP'][causalityAssessment/code[@code='39'][@codeSystem='2.16.840.1.113883.3.989.2.1.1.19']]";

		NodeList componentNodeList = (NodeList) xPath.compile(componentXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODESET);

		for (String drugUUId : drugUIDList) {
			for (String reactionUUId : reactUIDList) {
				Class<?> aeChildClass = Class.forName(xmlTableInfo.getEntityPkgName() + xmlTableInfo.getEntityName());
				Object aeChildObject = null;
				List<DrugReactRelatedness> drugReactList = new LinkedList<>();
				try {
					String validXpath = getXpathForDrugReactRelatednessForcausalityAssessmentCount(reactionUUId, drugUUId, metaDataXpath, rootIndex);
					//int causalityAssessmentCount = checkForCausalityAssessment(e2bR3Xmldoc, xPath, validXpath, oldXSD, newXSD);

					for (int compId = 1; compId <= componentNodeList.getLength(); compId++) {

						if (true) {
							// create class instance
							aeChildObject = aeChildClass.newInstance();
							for (Map.Entry<String, XMLTagInfo> xmlTagInfoEntry : tagInfoMap.entrySet()) {
								XMLTagInfo xmlTagInfo = xmlTagInfoEntry.getValue();
								entityName = xmlTagInfo.getR3EntityName();
								if ("1".equals(xmlTagInfo.getR3Header())) {
									continue;
								}
								String entityField = xmlTagInfo.getEntityField();
								String r3Xpath = (Objects.isNull(xmlTagInfo.getR3Xpath()) ||
										xmlTagInfo.getR3Xpath().equalsIgnoreCase("")) ? xmlTagInfo.getEmaR3Xpath() : xmlTagInfo.getR3Xpath();
								String splitCh = "\\[r]";
								String xpathForDrugReactRelatedness = getXpathForDrugReactRelatedness(reactionUUId, drugUUId, r3Xpath, rootIndex, compId, splitCh);
								xpathForDrugReactRelatedness = removeInvalidXpathAttributeExpr(xpathForDrugReactRelatedness);

								Node childNode = (Node) xPath.compile(xpathForDrugReactRelatedness).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
								if (null != childNode) {
									if(r3Xpath.endsWith("()")){
										setLineNumberMap("TEXT", xmlTagInfo, childNode, lineNoMapByTagId);
									}else if(r3Xpath.endsWith("]")){
										setLineNumberMap("NODE", xmlTagInfo, childNode, lineNoMapByTagId);
									}else{
										setLineNumberMap("ATTRIBUTE", xmlTagInfo, childNode, lineNoMapByTagId);
									}

									if (null != xmlTagInfo.getFieldId()) {
										codeListId = getCodeListByFieldId(xmlTagInfo.getFieldId(), formRecId, e2bXmlProcessHelper);
									}
									String nodeValue = childNode.getNodeValue();
									Boolean result = false;
									if (null != xmlTagInfo.getAllowedValues()) {
										String allowedValue[] = xmlTagInfo.getAllowedValues().split(",");
										List<String> allowedValuesList = Arrays.asList(allowedValue);
										result = allowedValuesList.contains(childNode.getNodeValue());
									}
									if (null != codeListId && !"0".equals(codeListId) && !"null".equals(codeListId)) {
										if (!result) {
											nodeValue = getCodeFromCodeList(codeListId, childNode.getNodeValue());
										}
									}
									destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1));
									destMethod = aeChildClass.getMethod("set" + entityField, destField.getType());

									if (null != codeListId && !"0".equals(codeListId) && "".equals(nodeValue) && "True".equalsIgnoreCase(String.valueOf(xmlTagInfo.getFreeText()))) {
										nodeValue = childNode.getNodeValue();
										destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1) + "_FT");
										destMethod = aeChildClass.getMethod("set" + entityField + "_FT", destField.getType());

									}
									// identify the field type in entity class
									Class<?> childElementTypeClass = Class.forName(destField.getType().getCanonicalName());
									Object convertedChildElementValue = convertToSpecificType(childElementTypeClass,
											nodeValue, aeChildObject, xmlTagInfo, aeChildClass);
									if (null != convertedChildElementValue
											&& convertedChildElementValue.toString().length() > 0) {
										destMethod.invoke(aeChildObject, convertedChildElementValue);
									}
								}
							}
						}
						DrugReactRelatedness drugReactRelatedness = (DrugReactRelatedness) aeChildObject;
						if (null != drugReactRelatedness) {
							boolean checkFlag = drugReactRelatedness.getMethod() != null ||
									drugReactRelatedness.getCausalitySource() != null || drugReactRelatedness.getDrugResult() != null
									|| drugReactRelatedness.getMethodSF() != null || drugReactRelatedness.getDrugResultSF() != null || drugReactRelatedness.getCausalitySourceSF() != null;
							if (checkFlag) {
								drugReactList.add((DrugReactRelatedness) aeChildObject);
							}
						}
					}
                        /*if (causalityAssessmentCount > 0) {
                            drugReactMap.put(drugUUId, drugReactList);
                        }*/
				} catch (Exception e) {
					agLogger.error(e.getMessage(), e);
				}
			}
		}
		reactRelatednessesMap.put(entityName, drugReactMap);
		//}
		return reactRelatednessesMap;
	}

	private String getNullFlavorXpath(String r3NullFlavorXpath) {
		String nullFlavourXpath = r3NullFlavorXpath.substring(0, r3NullFlavorXpath.lastIndexOf("/"));
		nullFlavourXpath = nullFlavourXpath + "/@nullFlavor";
		return nullFlavourXpath;
	}

	/*private int checkForCausalityAssessment(org.w3c.dom.Document e2bR3Xmldoc, XPath xPath, String validXpath, String oldXSD, String newXSD) {
        int causalityAssessmentCount = 0;
        try {
            validXpath = getWellConstructedXPathExpr(validXpath, oldXSD, newXSD);
            NodeList nodeList = (NodeList) xPath.compile(validXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODESET);
            if (null != nodeList) {
                causalityAssessmentCount = nodeList.getLength();
            }
        } catch (Exception e) {
            agLogger.error(e.getMessage(), e);
        }

        return causalityAssessmentCount;
    }*/
	private NodeList checkForR3NodeList(org.w3c.dom.Document e2bR3Xmldoc, XPath xPath, String validXpath, String oldXSD, String newXSD) {
		int causalityAssessmentCount = 0;
		NodeList nodeList = null;
		try {
			validXpath = removeInvalidXpathAttributeExpr(validXpath);
			nodeList = (NodeList) xPath.compile(validXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODESET);
                /*if (null != nodeList) {
                    causalityAssessmentCount = nodeList.getLength();
                }*/
		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
		}

		return nodeList;
	}

	private String getXpathForDrugReactRelatedness(String reactionUUId, String drugUUId, String currentR3Xpath, int rootIndex, int compId, String splitCh) {
		//String splitCh = "\\[r]";
		String tempXpath = getChildXpath(currentR3Xpath, rootIndex, compId, splitCh);

		String drugReactRelatednessXPath = tempXpath.replaceFirst("UUID of i-th reaction", reactionUUId);
		drugReactRelatednessXPath = drugReactRelatednessXPath.replaceFirst("UUID of k-th drug", drugUUId);
		drugReactRelatednessXPath = getChildXpath(drugReactRelatednessXPath, rootIndex, compId, "\\[k]");
		return drugReactRelatednessXPath;
	}

	private String getXpathForDrugReactRelatednessForcausalityAssessmentCount(String reactionUUId, String drugUUId, String metaDataXpath, int rootIndex) {

		String msgHeaderXpath = getXpath(metaDataXpath, rootIndex);
		String drugReactRelatednessCountXPath = msgHeaderXpath.replaceFirst("UUID of i-th reaction", reactionUUId);
		drugReactRelatednessCountXPath = drugReactRelatednessCountXPath.replaceFirst("UUID of k-th drug", drugUUId);

		return drugReactRelatednessCountXPath;
	}

	private String getUUIDForDrugs(List<XMLTagInfo> xmlHeaderTagInfoList,
								   org.w3c.dom.Document e2bR3Xmldoc, int rootIndex, XPath xPath, String oldXSD, String newXSD, int index) {
		String UUID = null;
		try {
			for (XMLTagInfo xmlTagInfo : xmlHeaderTagInfoList) {
				if ("Drug".equals(xmlTagInfo.getR3EntityName())) {
					String newXpath = getXpath((Objects.isNull(xmlTagInfo.getR3Xpath()) ||
							xmlTagInfo.getR3Xpath().equalsIgnoreCase("")) ? xmlTagInfo.getEmaR3Xpath() : xmlTagInfo.getR3Xpath(), rootIndex);
					String uuIdXpath = getXpathForUUID(newXpath, xmlTagInfo.getR3EntityName(), index);
					uuIdXpath = removeInvalidXpathAttributeExpr(uuIdXpath);
					Node nodeTemp = (Node) xPath.compile(uuIdXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
					if (null != nodeTemp) {
						if ("root".equals(nodeTemp.getNodeName())) {
							UUID = nodeTemp.getNodeValue();
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
		}
		return UUID;
	}

	private String getXpathForKeyNameForUUID(String headerXpath, String r3EntityName, int count) {
		if ("Drug".equals(r3EntityName)) {
			headerXpath = headerXpath + "[" + count + "]/substanceAdministration/consumable/instanceOfKind/kindOfProduct/name/text()";
		} else if ("Reaction".equals(r3EntityName)) {
			headerXpath = headerXpath + "[" + count + "]/observation/value/originalText/text()";
		}

		return headerXpath;
	}

	private String getUUIDForReactions(List<XMLTagInfo> xmlHeaderTagInfoList,
									   org.w3c.dom.Document e2bR3Xmldoc, int rootIndex, XPath xPath, String oldXSD, String newXSD, int index) throws XPathExpressionException {
		String UUID = null;
		try {
			for (XMLTagInfo xmlTagInfo : xmlHeaderTagInfoList) {
				if ("Reaction".equals(xmlTagInfo.getR3EntityName())) {
					String newXpath = getXpath((Objects.isNull(xmlTagInfo.getR3Xpath()) ||
							xmlTagInfo.getR3Xpath().equalsIgnoreCase("")) ? xmlTagInfo.getEmaR3Xpath() : xmlTagInfo.getR3Xpath(), rootIndex);
					String uuIdXpath = getXpathForUUID(newXpath, xmlTagInfo.getR3EntityName(), index);
					uuIdXpath = removeInvalidXpathAttributeExpr(uuIdXpath);
					Node nodeTemp = (Node) xPath.compile(uuIdXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
					if (null != nodeTemp) {
						if ("root".equals(nodeTemp.getNodeName())) {
							UUID = nodeTemp.getNodeValue();
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
			throw e;
		}
		return UUID;
	}

	private SafetyReport assignObjectToSafetyReportList(E2BXmlProcessHelper e2bXmlProcessHelper, String messageType, SafetyReport safetyReport, Set<Map.Entry<String, XMLTableInfo>> tableInfoEntrySet, Map<String, Object> objMap) {

		XMLTagLibraryMetaData xmlTagLibraryMetaData = XMLTagLibraryMetaDataHandler.getXMLR3TagLibraryMetaData(e2bXmlProcessHelper.getAgxPersistenceUnitName());

		for (Map.Entry<String, XMLTableInfo> entry : tableInfoEntrySet) {
			try {

				XMLTableInfo xmlTableInfoTemp = entry.getValue();

				String entityName = xmlTableInfoTemp.getEntityName();
				if ("XMLCaseInfo".equals(entityName) || "SafetyReport".equals(entityName) || "LotNumber".equals(entityName) || "DrugTherapy".equals(entityName) ||
						"DrugIndication".equals(entityName) || "ActiveSubstance".equals(entityName) || "DrugRecurrence".equals(entityName)
						|| "DrugCasualtyAssessment".equals(entityName) || "ParentPastDrugSubstance".equalsIgnoreCase(entityName)
						|| "PatientPastDrugSubstance".equalsIgnoreCase(entityName)) {
					continue;
				} else if ("DrugReactRelatedness".equals(entityName)) {

					//Need to be changed
					Map<String, Map<String, List<DrugReactRelatedness>>> aeDrugReact = (Map<String, Map<String, List<DrugReactRelatedness>>>) objMap.get(entityName);
					List<Drug> drugListObj = (List<Drug>) objMap.get("Drug");

					if (!aeDrugReact.isEmpty() && !objMap.isEmpty()) {

						for (Drug drug : drugListObj) {
							String drugUUID = drug.getDrugUUID();
							Map<String, List<DrugReactRelatedness>> reactMap = aeDrugReact.get(entityName);
							List<DrugReactRelatedness> drugReactRelatednessList = reactMap.get(drugUUID);
							drug.setDrugReactRelatednessCollection(drugReactRelatednessList);

						}
					}
				} else {

					XMLTableInfo xmlTableInfoParent = xmlTagLibraryMetaData.getXmlImportTabInfoMapByMessageType().get(messageType).get(xmlTableInfoTemp.getParentTableID());

					if (null != xmlTableInfoParent) {
						String parentEntityName = xmlTableInfoParent.getEntityName();
						String entityContext = xmlTableInfoTemp.getEntityContext();

						Object aeChildObject = objMap.get(entityName);
						if ("DrugCollection".equals(entityContext)) {
							int drugCount = ((ArrayList) aeChildObject).size();
							//Get FormRecordId
							Long formRecId = getCustomFormRecId(e2bXmlProcessHelper);
							String routeOfAdminCodeListId = getCodeListByFieldId("122028", formRecId, e2bXmlProcessHelper);
							String parentRouteOfAdminCodeListId = getCodeListByFieldId("122030", formRecId, e2bXmlProcessHelper);

							for (int i = 0; i < drugCount; i++) {
								int drugTherapyCount = ((Drug) ((ArrayList) aeChildObject).get(i)).getDrugTherapyCollection().size();
								for (int j = 0; j < drugTherapyCount; j++) {
									if (null != ((Drug) ((ArrayList) aeChildObject).get(i)).getDrugTherapyCollection().get(j).getRouteOfAdministratorTermID()) {
										String value = ((Drug) ((ArrayList) aeChildObject).get(i)).getDrugTherapyCollection().get(j).getRouteOfAdministratorTermID();
										String valueFromCodelist = getCodeFromCodeList(routeOfAdminCodeListId, value);
										if (valueFromCodelist != null && valueFromCodelist.trim().length() != 0) {
											((Drug) ((ArrayList) aeChildObject).get(i)).getDrugTherapyCollection().get(j).setDrugAdministrationRoute(valueFromCodelist);
										} else {
											String deCode = getDecodedValueFromCode(routeOfAdminCodeListId, value);
											if (null != deCode && deCode.trim().length() != 0) {
												((Drug) ((ArrayList) aeChildObject).get(i)).getDrugTherapyCollection().get(j).setDrugAdministrationRoute(value);
											} else {
												((Drug) ((ArrayList) aeChildObject).get(i)).getDrugTherapyCollection().get(j).setDrugAdministrationRouteSF(value);
											}
										}
									}
									if (null != ((Drug) ((ArrayList) aeChildObject).get(i)).getDrugTherapyCollection().get(j).getParentRouteOfAdministratorTermID()) {
										String value = ((Drug) ((ArrayList) aeChildObject).get(i)).getDrugTherapyCollection().get(j).getParentRouteOfAdministratorTermID();
										String valueFromCodelist = getCodeFromCodeList(parentRouteOfAdminCodeListId, value);
										if (valueFromCodelist != null && valueFromCodelist.trim().length() != 0) {
											((Drug) ((ArrayList) aeChildObject).get(i)).getDrugTherapyCollection().get(j).setDrugParadministration(valueFromCodelist);
										} else {
											String deCode = getDecodedValueFromCode(parentRouteOfAdminCodeListId, value);
											if (null != deCode && deCode.trim().length() != 0) {
												((Drug) ((ArrayList) aeChildObject).get(i)).getDrugTherapyCollection().get(j).setDrugParadministration(value);
											} else {
												((Drug) ((ArrayList) aeChildObject).get(i)).getDrugTherapyCollection().get(j).setDrugParadministrationSF(value);
											}
										}
									}
								}
							}
						}
						Object aeParentObject = objMap.get(parentEntityName);

						if (null != aeChildObject || null != aeParentObject) {
							//Class<?> aeChildClass = Class.forName(xmlTableInfoTemp.getEntityPkgName() + entityName);
							Class<?> aeParentClass = Class.forName(xmlTableInfoParent.getEntityPkgName() + parentEntityName);

							Field destField = aeParentClass.getDeclaredField(entityContext.substring(0, 1).toLowerCase() + entityContext.substring(1));
							Method destMethod = aeParentClass.getMethod("set" + entityContext, destField.getType());
							destMethod.invoke(aeParentObject, aeChildObject);
						}
					}

				}
			} catch (Exception e) {
				e.printStackTrace();
				agLogger.error(e.getMessage(), e);
			}
		}


		try {
			Object object = objMap.get("SafetyReport");
			safetyReport = (SafetyReport) object;
		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
		}

		return safetyReport;
	}

	private XMLCaseInfo assignObjectToPartent(XMLCaseInfo xmlCaseInfo, List safetyReportList,
											  Map<String, Object> objMap) {

		Object e2bObject = objMap.get("E2BMessageInfo");
		xmlCaseInfo.setE2bMessageInfo((E2BMessageInfo) e2bObject);
		xmlCaseInfo.setSafetyReportsCollection(safetyReportList);

		return xmlCaseInfo;
	}

	private Object setNodeValueForNonRepetable(List<E2BCaseValidations> validationsList, int rootIndex, org.w3c.dom.Document e2bR3Xmldoc,
											   E2BXmlProcessHelper e2bXmlProcessHelper, String messageType, XPath xPath, XMLTableInfo xmlTableInfo,
											   String entityName, Object safetyReport, List<Object> caseSupportDocumentsList, String oldXSD, String newXSD,
											   Boolean e2BValidatorFlag, Map<String, Integer> lineNoMapByTagId)
			throws NoSuchMethodException, InvocationTargetException {
		//List<E2BCaseValidations> validationsList = new ArrayList<E2BCaseValidations>();
		Class<?> aeChildClass = null;
		Object aeChildObject = null;
		XMLTagInfo xmlTagInfo;
		String codeListId = null;
		String nodeValueFromCodelist = null;
		Long formRecId = null;
		try {
			//Get FormRecordId
			formRecId = getCustomFormRecId(e2bXmlProcessHelper);

			aeChildClass = Class.forName(xmlTableInfo.getEntityPkgName() + xmlTableInfo.getEntityName());
			// create class instance
			aeChildObject = aeChildClass.newInstance();
			AgxUserBean agxUser = e2bXmlProcessHelper.getAgxUser();

			if (aeChildObject instanceof SafetyReport) {
				safetyReport = aeChildObject;
			}
			Map<String, XMLTagInfo> tagInfoMap = XMLTagLibraryMetaDataHandler.getXMLR3TagLibraryMetaData(e2bXmlProcessHelper.getAgxPersistenceUnitName())
					.getXmlImportTagInfoMapByMessageType().get(messageType).get(entityName);
			Set<Map.Entry<String, XMLTagInfo>> tagMetaDataEntrySet = tagInfoMap.entrySet();
			String r3Xpath;

			Map<String, String> sourceDocMap = new TreeMap<String, String>();
			//List<InboundSupportDocument> inboundSupportDocumentsList = new ArrayList<InboundSupportDocument>();
			int senderDocCount = 0;

			for (Map.Entry<String, XMLTagInfo> tagMetaDataEntry : tagMetaDataEntrySet) {
				xmlTagInfo = tagMetaDataEntry.getValue();
				r3Xpath = (Objects.isNull(xmlTagInfo.getR3Xpath()) ||
						xmlTagInfo.getR3Xpath().equalsIgnoreCase("")) ? xmlTagInfo.getEmaR3Xpath() : xmlTagInfo.getR3Xpath();

				if (null == r3Xpath) {
					continue;
				}
				if (null != xmlTagInfo.getFieldId()) {
					codeListId = getCodeListByFieldId(xmlTagInfo.getFieldId(), formRecId, e2bXmlProcessHelper);
				}
				String entityField = xmlTagInfo.getEntityField();

				if (xmlTagInfo.isR3NodeRepeatable()) {

					try {
						//Node repeatable
						if ("AttachedDocumentCount".equals(entityField)) {
							r3Xpath = getXpath(r3Xpath, rootIndex);

							r3Xpath = removeInvalidXpathAttributeExpr(r3Xpath);
							NodeList docNodeList = (NodeList) xPath.compile(r3Xpath).evaluate(e2bR3Xmldoc, XPathConstants.NODESET);
							if (null != docNodeList) {
								senderDocCount = docNodeList.getLength();
							}
							continue;
						} else if ("SafetyReport".equals(xmlTagInfo.getR3EntityName())) {
							for (int i = 1; i <= senderDocCount; i++) {
								r3Xpath = getChildXpath(r3Xpath, rootIndex, i, "\\[r]");

								r3Xpath = removeInvalidXpathAttributeExpr(r3Xpath);
								Node docChildNode = (Node) xPath.compile(r3Xpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
								if (null != docChildNode) {
									if(r3Xpath.endsWith("()")){
										setLineNumberMap("TEXT", xmlTagInfo, docChildNode, lineNoMapByTagId);
									}else if(r3Xpath.endsWith("]")){
										setLineNumberMap("NODE", xmlTagInfo, docChildNode, lineNoMapByTagId);
									}else{
										setLineNumberMap("ATTRIBUTE", xmlTagInfo, docChildNode, lineNoMapByTagId);
									}
									String nodeValueTemp = docChildNode.getNodeValue();
									if ("DocumentList".equals(entityField)) {
										//set code to object
										Field destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1));
										Method destMethod = aeChildClass.getMethod("set" + entityField, destField.getType());

										// identify the field type in entity class
										Class<?> childElementTypeClass = Class.forName(destField.getType().getCanonicalName());
										Object convertedChildElementValue = convertToSpecificType(childElementTypeClass,
												nodeValueTemp, aeChildObject, xmlTagInfo, aeChildClass);
										if (null != convertedChildElementValue
												&& convertedChildElementValue.toString().length() > 0) {
											destMethod.invoke(aeChildObject, convertedChildElementValue);
										}


									} else if ("AttachedDocumentIdsMap".equals(entityField)) {
										if (null != docChildNode) {
											//r3Xpath = getWellConstructedXPathExpr(r3Xpath, oldXSD, newXSD);
											Node compressionNode = getCompressionValue(e2bR3Xmldoc, xPath, r3Xpath, "@compression");
											Node mediaTypeNode = getMediaType(e2bR3Xmldoc, xPath, r3Xpath, "@mediaType");
											Node representationNode = getRepresentation(e2bR3Xmldoc, xPath, r3Xpath, "@representation");
											if (null != representationNode) {
												generateAttachmentDocument(docChildNode, compressionNode, mediaTypeNode, representationNode, i, agxUser, caseSupportDocumentsList, entityName, e2bXmlProcessHelper);
											}

										}

									}
								}
							}
						} else {
							r3Xpath = getXpath(r3Xpath, rootIndex);

							r3Xpath = removeInvalidXpathAttributeExpr(r3Xpath);

							Node repetableElementNode = (Node) xPath.compile(r3Xpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
							if (null != repetableElementNode) {
								if(r3Xpath.endsWith("()")){
									setLineNumberMap("TEXT", xmlTagInfo, repetableElementNode, lineNoMapByTagId);
								}else if(r3Xpath.endsWith("]")){
									setLineNumberMap("NODE", xmlTagInfo, repetableElementNode, lineNoMapByTagId);
								}else{
									setLineNumberMap("ATTRIBUTE", xmlTagInfo, repetableElementNode, lineNoMapByTagId);
								}
								String nodeValueRepetable = repetableElementNode.getNodeValue();
								Field destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1));
								Method destMethod = aeChildClass.getMethod("set" + entityField, destField.getType());

								// identify the field type in entity class
								Class<?> childElementTypeClass = Class.forName(destField.getType().getCanonicalName());
								Object convertedChildElementValue = convertToSpecificType(childElementTypeClass,
										nodeValueRepetable, aeChildObject, xmlTagInfo, aeChildClass);
								if (null != convertedChildElementValue
										&& convertedChildElementValue.toString().length() > 0) {
									destMethod.invoke(aeChildObject, convertedChildElementValue);
								}

							}
						}
					} catch (Exception e) {
						agLogger.error(e.getMessage(), e);
					}
				} else {
					try {
						Node childNode = null;
						String currentR3Xpath = getXpath(r3Xpath, rootIndex);
						currentR3Xpath = removeInvalidXpathAttributeExpr(currentR3Xpath);
						String currentR3XpathForNonRepatble = getXpathForNonRepatables(currentR3Xpath, rootIndex);
						childNode = (Node) xPath.compile(currentR3Xpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);

						if (null == childNode) {
							if (null != xmlTagInfo.getR3NullFlavor()) {
								String nullFlavorXpath = getNullFlavorXpath(currentR3Xpath);
								Node nullFlavourNode = (Node) xPath.compile(nullFlavorXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
								if (null != nullFlavourNode) {
									childNode = nullFlavourNode;
									entityField = xmlTagInfo.getR3NullFlavorEntityField();
								}
							}
						}

						if (null != childNode) {
							String nodeValue = childNode.getNodeValue();
							if(r3Xpath.endsWith("()")){
								setLineNumberMap("TEXT", xmlTagInfo, childNode, lineNoMapByTagId);
							}else if(r3Xpath.endsWith("]")){
								setLineNumberMap("NODE", xmlTagInfo, childNode, lineNoMapByTagId);
							}else{
								setLineNumberMap("ATTRIBUTE", xmlTagInfo, childNode, lineNoMapByTagId);
							}
							if ("C.3.4.6".equals(xmlTagInfo.getTagID()) || ("C.3.4.7".equals(xmlTagInfo.getTagID())) || "C.3.4.8".equals(xmlTagInfo.getTagID())) {
								if ("C.3.4.8".equals(xmlTagInfo.getTagID())) {
									nodeValue = nodeValue.substring(7);
								} else {
									nodeValue = nodeValue.substring(4);
								}
							}
							//Validate the data in xml
							validateR3Data(validationsList, xmlTagInfo, entityField, nodeValue, childNode);

							//Trimming the Value
							if (!"BL".equalsIgnoreCase(xmlTagInfo.getE2bDataType())) {
								int allowedlength = findLength(xmlTagInfo.getE2bFieldLength(), xmlTagInfo, nodeValue);
								if (nodeValue.length() > allowedlength) {
									nodeValue = nodeValue.substring(0, xmlTagInfo.getE2bFieldLength() - 1);
									childNode.setNodeValue(nodeValue);
								}
							}
							//Trim For
							Boolean result = false;
							nodeValue = getTrimmedValueIfItIsDateField(xmlTagInfo, nodeValue);
							if (null != xmlTagInfo.getFieldId()) {
								codeListId = getCodeListByFieldId(xmlTagInfo.getFieldId(), formRecId, e2bXmlProcessHelper);
							}
							if (null != xmlTagInfo.getAllowedValues()) {
								String allowedValue[] = xmlTagInfo.getAllowedValues().split(",");
								List<String> allowedValuesList = Arrays.asList(allowedValue);
								result = allowedValuesList.contains(nodeValue);
							}
							if (null != codeListId && !"0".equals(codeListId) && !"null".equals(codeListId)) {
								if (!result) {
									nodeValueFromCodelist = getCodeFromCodeList(codeListId, nodeValue);
									if (null != nodeValueFromCodelist && nodeValueFromCodelist.length() != 0) {
										nodeValue = nodeValueFromCodelist;
										//nodeValue = getCodeFromCodeList(codeListId, nodeValue);
									}
								}
							}
							Field destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1));
							Method destMethod = aeChildClass.getMethod("set" + entityField, destField.getType());
							//For Free Text
							if (null != codeListId && !"0".equals(codeListId) && "".equals(nodeValueFromCodelist) && "True".equalsIgnoreCase(String.valueOf(xmlTagInfo.getFreeText()))) {
								destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1) + "SF");
								destMethod = aeChildClass.getMethod("set" + entityField + "SF", destField.getType());
							}
							// identify the field type in entity class
							Class<?> childElementTypeClass = Class.forName(destField.getType().getCanonicalName());
							Object convertedChildElementValue = convertToSpecificType(childElementTypeClass,
									nodeValue, aeChildObject, xmlTagInfo, aeChildClass);
							if (null != convertedChildElementValue
									&& convertedChildElementValue.toString().length() > 0) {
								destMethod.invoke(aeChildObject, convertedChildElementValue);
							}
						}
					} catch (Exception e) {
						agLogger.error(e.getMessage(), e);
					}
				}
			}
			if (aeChildObject instanceof E2BMessageInfo) {
				// safetyReport = aeChildObject;
				Method collectionMethodset = aeChildObject.getClass().getDeclaredMethod("setValidationsLists", List.class);
				collectionMethodset.invoke(aeChildObject, validationsList);
			}
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SecurityException | IllegalArgumentException e) {
			agLogger.error(e.getMessage(), e);
		}

		return aeChildObject;
	}

	private String getTrimmedValueIfItIsDateField(XMLTagInfo tagInfo, String elementValue) {
		String methodName = "getTrimmedValueIfItIsDateField";
		try {
			if (null != tagInfo && "7".equals(tagInfo.getFieldType())) {
				if (null != elementValue) {
					elementValue = elementValue.trim();
				}
			}
		} catch (Exception e) {
			agLogger.error("Errors Occurred while checking if the tag value is of date type or not to trim the data..for value["
					+ elementValue + "]", e);
		}
		return elementValue;
	}

	/**
	 * @param validationsList
	 * @param xmlTagInfo
	 * @param entityField
	 * @param nodeValue
	 * @param childNode
	 */
	private void validateR3Data(List<E2BCaseValidations> validationsList, XMLTagInfo xmlTagInfo, String entityField, String nodeValue, Node childNode) {

		String expectedDataType = xmlTagInfo.getE2bDataType();
		Integer e2bdataLength = xmlTagInfo.getE2bFieldLength();
		//Checking Validation for Null flavor
		if ("nullFlavor".equalsIgnoreCase(String.valueOf(childNode.getNodeName()))) {
			int count = 0;
			String allowedValue[] = xmlTagInfo.getAllowedValues().split(",");
			List<String> allowedValuesList = Arrays.asList(allowedValue);
			Boolean result = allowedValuesList.contains(nodeValue);
			if (!result) {
				validationsList.add(getNewE2BCaseValidation("e2b_validation_element_value_required_for_nullflavor",
						entityField + AgxConstants.DATA_FIELDS_SEPERATOR + xmlTagInfo.getContextNodeName(),
						entityField, xmlTagInfo.getContextNodeName(), nodeValue, xmlTagInfo.getTagID(), AgxConstants.VALIDATION_SEVERITY_ERROR));
			}
		}
		//Checking for Boolean Data Type
		if (expectedDataType != null && expectedDataType.equals("BL")) {
			if (nodeValue == null) {
				//ToDo:
			} else if (nodeValue != null && !"nullFlavor".equalsIgnoreCase(String.valueOf(childNode.getNodeName()))) {
				if (!"true".equalsIgnoreCase(nodeValue) && !"false".equalsIgnoreCase(nodeValue)) {
					//nodeValue = String.valueOf(null);
					validationsList.add(getNewE2BCaseValidation("e2b_validation_element_value_required_boolean_type",
							entityField + AgxConstants.DATA_FIELDS_SEPERATOR + xmlTagInfo.getContextNodeName(),
							entityField, xmlTagInfo.getContextNodeName(), nodeValue, xmlTagInfo.getTagID(), AgxConstants.VALIDATION_SEVERITY_ERROR));
				}
			}
		}//checking For date DataType
		else {
			if (expectedDataType != null && expectedDataType.equalsIgnoreCase("Date") && !"nullFlavor".equalsIgnoreCase(String.valueOf(childNode.getNodeName()))) {
				Integer dateLength = nodeValue.length();
				try {
					//if (4 == dateLength || 6 == dateLength || 8 == dateLength || 10 == dateLength || 12 == dateLength || (15>dateLength&&14<dateLength) || 17 == dateLength || 19 == dateLength || 23 == dateLength) {
					if (4 == dateLength) {
						SimpleDateFormat mydateFormat = new SimpleDateFormat("yyyy");
						Date parsedDate = mydateFormat.parse(nodeValue);
						nodeValue = String.valueOf(parsedDate);
					} else if (6 == dateLength) {
						SimpleDateFormat mydateFormat = new SimpleDateFormat("yyyyMM");
						Date parsedDate = mydateFormat.parse(nodeValue);
						nodeValue = String.valueOf(parsedDate);
					} else if (8 == dateLength) {
						SimpleDateFormat mydateFormat = new SimpleDateFormat("yyyyMMdd");
						Date parsedDate = mydateFormat.parse(nodeValue);
						nodeValue = String.valueOf(parsedDate);
					} else if (10 == dateLength) {
						SimpleDateFormat mydateFormat = new SimpleDateFormat("yyyyMMddHH");
						Date parsedDate = mydateFormat.parse(nodeValue);
						nodeValue = String.valueOf(parsedDate);
					} else if (12 == dateLength) {
						SimpleDateFormat mydateFormat = new SimpleDateFormat("yyyyMMddHHmm");
						Date parsedDate = mydateFormat.parse(nodeValue);
						nodeValue = String.valueOf(parsedDate);
					} else if (14 == dateLength) {
						SimpleDateFormat mydateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
						Date parsedDate = mydateFormat.parse(nodeValue);
						nodeValue = String.valueOf(parsedDate);
					} else if (15 == dateLength) {
						SimpleDateFormat mydateFormat = new SimpleDateFormat("yyyyMMddHHZ");
						Date parsedDate = mydateFormat.parse(nodeValue);
						nodeValue = String.valueOf(parsedDate);
					} else if (17 == dateLength) {
						SimpleDateFormat mydateFormat = new SimpleDateFormat("yyyyMMddHHmmssX");
						Date parsedDate = mydateFormat.parse(nodeValue);
						nodeValue = String.valueOf(parsedDate);
					} else if (18 == dateLength) {
						SimpleDateFormat mydateFormat = new SimpleDateFormat("yyyyMMddHHmmss.SSSS");
						Date parsedDate = mydateFormat.parse(nodeValue);
						nodeValue = String.valueOf(parsedDate);
					} else if (19 == dateLength) {
						SimpleDateFormat mydateFormat = new SimpleDateFormat("yyyyMMddHHmmss.uuuu");
						Date parsedDate = null;
						try {
							parsedDate = mydateFormat.parse(nodeValue);
						} catch (ParseException pe) {
							mydateFormat = new SimpleDateFormat("yyyyMMddHHmmssXX");
							parsedDate = mydateFormat.parse(nodeValue);
						}
						nodeValue = String.valueOf(parsedDate);
					} else {
						SimpleDateFormat mydateFormat = new SimpleDateFormat("yyyyMMddHHmmss.SSSSZ");
						Date parsedDate = mydateFormat.parse(nodeValue);
						nodeValue = String.valueOf(parsedDate);
					}
					//}
				} catch (Exception e) {
					validationsList.add(getNewE2BCaseValidation("e2b_validation_element_value_required_for_date",
							entityField + AgxConstants.DATA_FIELDS_SEPERATOR + xmlTagInfo.getContextNodeName(),
							entityField, xmlTagInfo.getContextNodeName(), nodeValue, xmlTagInfo.getTagID(), AgxConstants.VALIDATION_SEVERITY_ERROR));
				}
			}
		}
		if (expectedDataType != null && !"Date".equalsIgnoreCase(expectedDataType) && !"BL".equalsIgnoreCase(expectedDataType) && nodeValue != null && nodeValue.length() > e2bdataLength) {
			validationsList.add(getNewE2BCaseValidation("e2b_validation_element_maximum_allowed_char_length",
					entityField + AgxConstants.DATA_FIELDS_SEPERATOR + e2bdataLength + AgxConstants.DATA_FIELDS_SEPERATOR + nodeValue.length() + AgxConstants.DATA_FIELDS_SEPERATOR + xmlTagInfo.getContextNodeName(),
					entityField, xmlTagInfo.getContextNodeName(), nodeValue, xmlTagInfo.getTagID(), AgxConstants.VALIDATION_SEVERITY_ERROR));
		} else {
			//String expectedDataType = xmlTagInfo.getE2bDataType();
			// check only for alpha bets
			if (expectedDataType != null && "A".equalsIgnoreCase(expectedDataType)) {
				// checking if value contains data other than letter in
				// any
				// language
				if (nodeValue != null && !nodeValue.equals("")) {
					if (!xmlTagInfo.getTagID().equals("E.i.1.1b")) {
						if (!nodeValue.matches("[^\\P{L}]+")) {
							agLogger.info("********** Only letters are allowed for element [" + entityField
									+ "] under header element [" + xmlTagInfo.getContextNodeName() + "].");
							validationsList.add(getNewE2BCaseValidation("e2b_validation_element_only_letters_are_allowed",
									entityField + AgxConstants.DATA_FIELDS_SEPERATOR + xmlTagInfo.getContextNodeName(), entityField,
									xmlTagInfo.getContextNodeName(), nodeValue, xmlTagInfo.getTagID(), AgxConstants.VALIDATION_SEVERITY_ERROR));
						}
					}
				}
			}
			// check for only numerics
			else if (expectedDataType != null && "N".equalsIgnoreCase(expectedDataType)) {
				try {
					Long.parseLong(nodeValue);
				} catch (Exception ec) {
					agLogger.info("*********** Data Convertion to Long is failed for element ["
							+ entityField + "] and Value [" + nodeValue
							+ "] Under header element [" + xmlTagInfo.getContextNodeName() + "]");
					agLogger.info("********** Trying to Convert the value ["
							+ nodeValue + "] to Double type..");

					try {
						Double.parseDouble(nodeValue);
					} catch (Exception e) {
						agLogger.info("*********** Only Numeric values are allowed for element ["
								+ entityField + "] under header element [" + xmlTagInfo.getContextNodeName()
								+ "].");
						validationsList.add(
								getNewE2BCaseValidation("e2b_validation_element_only_numeric_values_are_allowed",
										entityField + AgxConstants.DATA_FIELDS_SEPERATOR + xmlTagInfo.getContextNodeName(),
										entityField, xmlTagInfo.getContextNodeName(), nodeValue, xmlTagInfo.getTagID(), AgxConstants.VALIDATION_SEVERITY_ERROR));
					}
				}
			}
		}

	}

	private List<Object> setNodeValueForRepeatable(List<E2BCaseValidations> validationsList, int caseIndex, org.w3c.dom.Document e2bR3Xmldoc,
												   E2BXmlProcessHelper e2bXmlProcessHelper, String messageType, XPath xPath, XMLTableInfo xmlTableInfo,
												   Integer headerCountForCurrentEntitiy, String entityName, List<String> drugUIDList, List<String> reactUIDList,
												   GenericCrudService genericCrudService, List<Object> inboundSupportDocumentsList, List<XMLTagInfo> xmlHeaderTagInfoList,
												   String oldXSD, String newXSD, Boolean e2BValidatorFlag, Map<String, Integer> lineNoMapByTagId) {


		List<Object> aeChildClassList = new ArrayList<Object>();
		Long formRecId = null;

		try {
			//Get FormRecordId
			formRecId = getCustomFormRecId(e2bXmlProcessHelper);
			Map<String, XMLTagInfo> tagInfoMap = XMLTagLibraryMetaDataHandler.getXMLR3TagLibraryMetaData(e2bXmlProcessHelper.getAgxPersistenceUnitName())
					.getXmlImportTagInfoMapByMessageType().get(messageType).get(entityName);
			Set<Map.Entry<String, XMLTagInfo>> tagMetaDataEntrySet = tagInfoMap.entrySet();
			String r3Xpath;
			XMLTagInfo xmlTagInfo;

			for (int count = 1; count <= headerCountForCurrentEntitiy; count++) {
				Class<?> aeChildClass = Class.forName(xmlTableInfo.getEntityPkgName() + xmlTableInfo.getEntityName());
				// create class instance
				Object aeChildObject = aeChildClass.newInstance();

				// Created drugChild map for drug child objects
				//Map<String,List<Object>> childOfDrugMap = new LinkedHashMap<String,List<Object>>();
				Map<String, Map<Integer, Object>> childOfDrugMap = new LinkedHashMap<String, Map<Integer, Object>>();
				Map<String, Integer> childOfDrugCountMap = new LinkedHashMap<String, Integer>();


				if (aeChildObject instanceof XMLCaseInfo) {
					aeChildObject = (XMLCaseInfo) aeChildObject;
					continue;
				}
				for (Map.Entry<String, XMLTagInfo> tagMetaDataEntry : tagMetaDataEntrySet) {
					xmlTagInfo = tagMetaDataEntry.getValue();

					try {
						if ("1".equals(xmlTagInfo.getR3Header())) {
							continue;
						}
						r3Xpath = (Objects.isNull(xmlTagInfo.getR3Xpath()) ||
								xmlTagInfo.getR3Xpath().equalsIgnoreCase("")) ? xmlTagInfo.getEmaR3Xpath() : xmlTagInfo.getR3Xpath();
						String entityField = xmlTagInfo.getEntityField();

						String splitChar = "\\[r]";
						String childXpath = null;
						if ("Drug".equals(entityName)) {
							splitChar = "\\[k]";
							//childXpath  = getChildXpath(r3Xpath,caseIndex, count,splitChar);
							setAeObjectRepetableNodeChildFieldsForDrug(validationsList, caseIndex, e2bR3Xmldoc, xPath, r3Xpath, xmlTagInfo, xmlTableInfo,
									count, aeChildClass, aeChildObject, entityField, splitChar, childOfDrugMap, childOfDrugCountMap, oldXSD, newXSD, e2bXmlProcessHelper,
									xmlHeaderTagInfoList, formRecId, lineNoMapByTagId);
						} else if ("Reaction".equals(entityName)) {
							splitChar = "\\[i]";
							//childXpath  = getChildXpath(r3Xpath,caseIndex, count,splitChar);
							//String r3XpathTemp = getXpath(r3Xpath,caseIndex,"");
							setAeObjectRepetableNodeChildFieldsForNonRepetables(validationsList, caseIndex, e2bR3Xmldoc, xPath, r3Xpath, xmlTagInfo,
									count, aeChildClass, aeChildObject, entityField, splitChar, e2bXmlProcessHelper, inboundSupportDocumentsList, oldXSD, newXSD, lineNoMapByTagId);
						} else if ("Test".equals(entityName)) {
							List<String> xPathList = genericCrudService.findAllByNamedQuery("XMLTagInfo.findAllXpathList", xmlTagInfo.getTagID());
							for (String xPathForTest : xPathList) {
								xmlTagInfo.setR3Xpath(xPathForTest);
								r3Xpath = xPathForTest;
								String xPathResult = setAeObjectRepetableNodeChildFieldsForNonRepetables(validationsList, caseIndex, e2bR3Xmldoc, xPath, r3Xpath, xmlTagInfo,
										count, aeChildClass, aeChildObject, entityField, splitChar, e2bXmlProcessHelper, inboundSupportDocumentsList, oldXSD, newXSD, lineNoMapByTagId);
								if (null != xPathResult) {
									break;
								}
							}

						} else {
							setAeObjectRepetableNodeChildFieldsForNonRepetables(validationsList, caseIndex, e2bR3Xmldoc, xPath, r3Xpath, xmlTagInfo,
									count, aeChildClass, aeChildObject, entityField, splitChar, e2bXmlProcessHelper, inboundSupportDocumentsList, oldXSD, newXSD, lineNoMapByTagId);
						}

					} catch (Exception e) {
						agLogger.error(e.getMessage(), e);
					}

					if (null != xmlTagInfo.getJavaScripts() && !"".equals(xmlTagInfo.getJavaScripts())) {
						executeJavaScripts(aeChildObject, null, xmlTagInfo);
					}

				}

				if ("Drug".equals(entityName)) {
					Method setUUID = aeChildClass.getMethod("setDrugUUID", String.class);
					Drug tempDrug = (Drug) aeChildObject;
					if (null != tempDrug) {
						String drugUUID = getUUIDForDrugs(xmlHeaderTagInfoList, e2bR3Xmldoc, caseIndex, xPath, oldXSD, newXSD, count);
						setUUID.invoke(aeChildObject, drugUUID);
						drugUIDList.add(drugUUID);
					}


					Set<Map.Entry<String, Map<Integer, Object>>> entrySetChildDrugForList = childOfDrugMap.entrySet();
					for (Map.Entry<String, Map<Integer, Object>> drugChildEntry : entrySetChildDrugForList) {
						//Issue fix for tag G.k.10.r.1
						String childEntityName = AgxConstants.DRUG_ADDITIONAL_INFO.equals(drugChildEntry.getKey()) ? AgxConstants.DRUG_ADDITION_INFO : drugChildEntry.getKey();
						Map<Integer, Object> valueChildMap = drugChildEntry.getValue();
						List<Object> drugChildObjList = new ArrayList<Object>(valueChildMap.values());
						Method childOfDrugMethod = aeChildClass.getMethod("set" + childEntityName + "Collection", List.class);
						childOfDrugMethod.invoke(aeChildObject, drugChildObjList);
					}

				}
				if ("Reaction".equals(entityName)) {
					Method setUUID = aeChildClass.getMethod("setReactionUUID", String.class);
					Reaction tempDrug = (Reaction) aeChildObject;
					if (null != tempDrug) {
						String reactUUID = getUUIDForReactions(xmlHeaderTagInfoList, e2bR3Xmldoc, caseIndex, xPath, oldXSD, newXSD, count);
						setUUID.invoke(aeChildObject, reactUUID);
						reactUIDList.add(reactUUID);
					}
				}

				if ("PatientPastDrugTherapy".equalsIgnoreCase(entityName) || "ParentPastDrugTherapy".equalsIgnoreCase(entityName)) {
					List<Object> ObjectList = new ArrayList<Object>();
					String tableId = "";
					if ("PatientPastDrugTherapy".equalsIgnoreCase(entityName)) {
						tableId = "708";
					} else if ("ParentPastDrugTherapy".equalsIgnoreCase(entityName)) {
						tableId = "709";
					}
					XMLTableInfo childXmlTableInfo = XMLTagLibraryMetaDataHandler.getXMLTagLibraryMetaData(e2bXmlProcessHelper.getAgxPersistenceUnitName()).
							getXmlImportTabInfoMapByMessageType().get(messageType).get(tableId);
					setNodeValueForPastDrugSubstance(caseIndex, e2bR3Xmldoc, e2bXmlProcessHelper, messageType, xPath, childXmlTableInfo,
							oldXSD, newXSD, aeChildObject, ObjectList, lineNoMapByTagId);


					if ("PatientPastDrugTherapy".equalsIgnoreCase(entityName)) {
						PatientPastDrugTherapy tempPatientPastDrugTherapy = (PatientPastDrugTherapy) aeChildObject;
						List<PatientPastDrugSubstance> tempPatientPastDrugSubstanceList = (List<PatientPastDrugSubstance>) (Object) ObjectList;
						if(null!= tempPatientPastDrugTherapy) {
						tempPatientPastDrugTherapy.setPatientPastDrugSubstanceCollection(tempPatientPastDrugSubstanceList);
						}
					} else if ("ParentPastDrugTherapy".equalsIgnoreCase(entityName)) {
						ParentPastDrugTherapy tempParentpastdrugtherapy = (ParentPastDrugTherapy) aeChildObject;
						List<ParentPastDrugSubstance> tempPatientPastDrugSubstanceList = (List<ParentPastDrugSubstance>) (Object) ObjectList;
						if(null!= tempParentpastdrugtherapy) {
						tempParentpastdrugtherapy.setParentPastDrugSubstanceCollection(tempPatientPastDrugSubstanceList);
						}
					}
					//tempPatientPastDrugTherapy.setPatientPastDrugSubstanceCollection(ObjectList);


				}
				aeChildClassList.add(aeChildObject);
			}

		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
		}

		return aeChildClassList;
	}

	//To build Drug Object and its child
	private void setAeObjectRepetableNodeChildFieldsForDrug(List<E2BCaseValidations> validationsList, int caseIndex, org.w3c.dom.Document e2bR3Xmldoc,
															XPath xPath, String r3Xpath, XMLTagInfo xmlTagInfo, XMLTableInfo xmlTableInfo, int count, Class<?> aeChildClass, Object aeChildObject,
															String entityField, String splitChar, Map<String, Map<Integer, Object>> childOfDrugMap, Map<String, Integer> childOfDrugCountMap,
															String oldXSD, String newXSD, E2BXmlProcessHelper e2bXmlProcessHelper, List<XMLTagInfo> xmlHeaderTagInfoList,
															Long formRecId, Map<String, Integer> lineNoMapByTagId) throws XPathExpressionException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException, ClassNotFoundException {

		String emaXpath = "";
		r3Xpath = getXpath(r3Xpath, caseIndex);
		if (null != xmlTagInfo.getEmaR3Xpath()) {
			emaXpath = getXpath(xmlTagInfo.getEmaR3Xpath(), caseIndex);
		}
		Field destField;
		Method destMethod;
		String childXpath = getChildXpath(r3Xpath, caseIndex, count, splitChar);
		String codeListId = null;
		if (xmlTagInfo.getMappedToChildEntity()) {
			if (xmlTagInfo.isR3NodeRepeatable()) {
				childXpath = removeInvalidXpathAttributeExpr(childXpath);
				NodeList drugChildNodeList = (NodeList) xPath.compile(childXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODESET);
				String[] fieldArray = entityField.split("#");
				String childEntityName = fieldArray[0];
				if (null != drugChildNodeList) {
					childOfDrugCountMap.put(childEntityName, drugChildNodeList.getLength());
				}
			} else {
					createChildObjectsOfDrug(validationsList, e2bR3Xmldoc, xPath, xmlTagInfo, xmlTableInfo, r3Xpath, childOfDrugMap,
							childOfDrugCountMap, oldXSD, newXSD, e2bXmlProcessHelper, formRecId, count, emaXpath, lineNoMapByTagId);
			}
		} else {
			if ("G.k.1".equalsIgnoreCase(xmlTagInfo.getTagID())) {
				String drugUUID = getUUIDForDrugs(xmlHeaderTagInfoList, e2bR3Xmldoc, caseIndex, xPath, oldXSD, newXSD, count);
				childXpath = childXpath.replaceAll("UUID of k-th drug", drugUUID);
			}
			childXpath = removeInvalidXpathAttributeExpr(childXpath);
			Node childNode = (Node) xPath.compile(childXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
			if (null == childNode) {
				if (null != xmlTagInfo.getR3NullFlavor()) {
					String nullFlavorXpath = getNullFlavorXpath(childXpath);
					Node nullFlavourNode = (Node) xPath.compile(nullFlavorXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
					if (null != nullFlavourNode) {
						childNode = nullFlavourNode;
						entityField = xmlTagInfo.getR3NullFlavorEntityField();
					}
				}
			}
			if (null != childNode) {
				String nodeValue = childNode.getNodeValue();
				if(r3Xpath.endsWith("()")){
					setLineNumberMap("TEXT", xmlTagInfo, childNode, lineNoMapByTagId);
				}else if(r3Xpath.endsWith("]")){
					setLineNumberMap("NODE", xmlTagInfo, childNode, lineNoMapByTagId);
				}else{
					setLineNumberMap("ATTRIBUTE", xmlTagInfo, childNode, lineNoMapByTagId);
				}
				Boolean result = false;
				if (null != xmlTagInfo.getFieldId()) {
					codeListId = getCodeListByFieldId(xmlTagInfo.getFieldId(), formRecId, e2bXmlProcessHelper);
				}
				if (null != xmlTagInfo.getAllowedValues()) {
					String allowedValue[] = xmlTagInfo.getAllowedValues().split(",");
					List<String> allowedValuesList = Arrays.asList(allowedValue);
					result = allowedValuesList.contains(childNode.getNodeValue());
				}
				//Issue fix for G.k.10.r.1
				String valueFromCodelist = "";
				if (null != codeListId && !"0".equals(codeListId) && !"null".equals(codeListId) && !result) {
						valueFromCodelist = getCodeFromCodeList(codeListId, childNode.getNodeValue());
				}
				if (valueFromCodelist!=null && valueFromCodelist.trim().length() != 0) {
					nodeValue = valueFromCodelist;
				}
				// R3 Data Validation
				validateR3Data(validationsList, xmlTagInfo, entityField, nodeValue, childNode);

				destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1));
				destMethod = aeChildClass.getMethod("set" + entityField, destField.getType());

				if (null != codeListId && !"0".equals(codeListId) && !"".equals(valueFromCodelist) && "True".equalsIgnoreCase(String.valueOf(xmlTagInfo.getFreeText()))) {
					nodeValue = valueFromCodelist;
					destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1) + "SF");
					destMethod = aeChildClass.getMethod("set" + entityField + "SF", destField.getType());
				}
				// identify the field type in entity class
				Class<?> childElementTypeClass = Class.forName(destField.getType().getCanonicalName());
				Object convertedChildElementValue = convertToSpecificType(childElementTypeClass,
						nodeValue, aeChildObject, xmlTagInfo, aeChildClass);
				if (null != convertedChildElementValue
						&& convertedChildElementValue.toString().length() > 0) {
					destMethod.invoke(aeChildObject, convertedChildElementValue);
				}
				if (null != xmlTagInfo.getJavaScripts() && !"".equals(xmlTagInfo.getJavaScripts()) && null != nodeValue) {
					executeJavaScripts(aeChildObject, nodeValue, xmlTagInfo);
				}
			}

		}
	}

	private void createChildObjectsOfDrug(List<E2BCaseValidations> validationsList, org.w3c.dom.Document e2bR3Xmldoc, XPath xPath,
										  XMLTagInfo xmlTagInfo, XMLTableInfo xmlTableInfo,
										  String childXpath, Map<String, Map<Integer, Object>> childOfDrugMap,
										  Map<String, Integer> childOfDrugCountMap, String oldXSD, String newXSD, E2BXmlProcessHelper e2bXmlProcessHelper,
										  Long formRecId, int count, String emaXpath, Map<String, Integer> lineNoMapByTagId) {

		String entityField = xmlTagInfo.getEntityField();
		String codeListId = null;
		Field destField;
		Method destMethod;
		String[] fieldArray = entityField.split("#");
		String childEntityName = fieldArray[0];
		entityField = fieldArray[1];
		Map<Integer, Object> aeDrugChildMap = new LinkedHashMap<Integer, Object>();
		Class<?> aeDrugChildClass = null;
		Object aeDrugChildObject = null;

		Integer childDrugObjCount = 1;
		if (null != childOfDrugCountMap) {
			childDrugObjCount = childOfDrugCountMap.get(childEntityName);
			if (null == childDrugObjCount) {
				childDrugObjCount = 1;
			}
		}

		for (int childCount = 1; childCount <= childDrugObjCount; childCount++) {
			try {
				if (!childOfDrugMap.containsKey(childEntityName)) {
					aeDrugChildClass = Class.forName(xmlTableInfo.getEntityPkgName() + childEntityName);
					aeDrugChildObject = aeDrugChildClass.newInstance();
					aeDrugChildMap.put(childCount, aeDrugChildObject);
					childOfDrugMap.put(childEntityName, aeDrugChildMap);

				} else if (childOfDrugMap.get(childEntityName).containsKey(childCount)) {
					aeDrugChildClass = Class.forName(xmlTableInfo.getEntityPkgName() + childEntityName);
					aeDrugChildObject = childOfDrugMap.get(childEntityName).get(childCount);
				} else {
					aeDrugChildClass = Class.forName(xmlTableInfo.getEntityPkgName() + childEntityName);
					aeDrugChildObject = aeDrugChildClass.newInstance();
					aeDrugChildMap.put(childCount, aeDrugChildObject);
				}


				String drugChildXpath = getChildXpath(childXpath, childCount, count, "\\[k]");
				drugChildXpath = removeInvalidXpathAttributeExpr(drugChildXpath);
				Node childOfDrugNode = (Node) xPath.compile(drugChildXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
				if (null == childOfDrugNode && null != xmlTagInfo.getEmaR3Xpath()) {
					drugChildXpath = getChildXpath(emaXpath, childCount, count, "\\[k]");
					drugChildXpath = removeInvalidXpathAttributeExpr(drugChildXpath);
					childOfDrugNode = (Node) xPath.compile(drugChildXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
				}
				if (null != childOfDrugNode && "G.k.4.r.3".equals(xmlTagInfo.getTagID())) {
					xmlTagInfo.getDrugTherapyValues().put(xmlTagInfo.getTagID(), childOfDrugNode.getNodeValue());
				}
				if (null != childOfDrugNode) {
					String nodeValue = childOfDrugNode.getNodeValue();
					if(drugChildXpath.endsWith("()")){
						setLineNumberMap("TEXT", xmlTagInfo, childOfDrugNode, lineNoMapByTagId);
					}else if(drugChildXpath.endsWith("]")){
						setLineNumberMap("NODE", xmlTagInfo, childOfDrugNode, lineNoMapByTagId);
					}else{
						setLineNumberMap("ATTRIBUTE", xmlTagInfo, childOfDrugNode, lineNoMapByTagId);
					}
					Boolean result = false;
					if (null != xmlTagInfo.getFieldId()) {
						codeListId = getCodeListByFieldId(xmlTagInfo.getFieldId(), formRecId, e2bXmlProcessHelper);
					}

					if (null != xmlTagInfo.getAllowedValues()) {
						String allowedValue[] = xmlTagInfo.getAllowedValues().split(",");
						List<String> allowedValuesList = Arrays.asList(allowedValue);
						result = allowedValuesList.contains(childOfDrugNode.getNodeValue());
					}
					String valueFromCodelist = null;
					if (null != codeListId && !"0".equals(codeListId) && !"null".equals(codeListId)) {
						if (!result) {
							valueFromCodelist = getCodeFromCodeList(codeListId, childOfDrugNode.getNodeValue());
							if (valueFromCodelist != null && valueFromCodelist.trim().length() != 0) {
								nodeValue = valueFromCodelist;
							}
						}
					}

					//R3 Data Validation
					validateR3Data(validationsList, xmlTagInfo, entityField, nodeValue, childOfDrugNode);
					ApplicationContext ctx = AppContext.getAppContext();
					FormDesignMBean formDesignMBean = (FormDesignMBean) ctx.getBean("formDesignMBean");
					CustomFormField customFormField = formDesignMBean.getCustomFormField(e2bXmlProcessHelper.getAgxPersistenceUnitName(), "I", formRecId, xmlTagInfo.getFieldId());
					//Issue Fix for G.k.4.r.9.1
					if (null != codeListId && !"0".equals(codeListId) && customFormField.getSmartField() && valueFromCodelist != null && valueFromCodelist.trim().length() == 0) {
						destField = aeDrugChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1) + "SF");
						destMethod = aeDrugChildClass.getMethod("set" + entityField + "SF", destField.getType());
					} else {
						destField = aeDrugChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1));
						destMethod = aeDrugChildClass.getMethod("set" + entityField, destField.getType());
					}


					// identify the field type in entity class
					Class<?> childElementTypeClass = Class.forName(destField.getType().getCanonicalName());
					Object convertedChildElementValue = convertToSpecificType(childElementTypeClass,
							nodeValue, aeDrugChildObject, xmlTagInfo, aeDrugChildClass);
					if (null != convertedChildElementValue
							&& convertedChildElementValue.toString().length() > 0) {
						destMethod.invoke(aeDrugChildObject, convertedChildElementValue);
					}
				}

			} catch (XPathExpressionException | ClassNotFoundException | InstantiationException | IllegalAccessException | NoSuchFieldException | SecurityException | NoSuchMethodException | IllegalArgumentException | InvocationTargetException e) {
				agLogger.error(e.getMessage(), e);
			}
		}

	}

	private String setAeObjectRepetableNodeChildFieldsForNonRepetables(List<E2BCaseValidations> validationsList, int caseIndex, org.w3c.dom.Document e2bR3Xmldoc, XPath xPath,
																	   String r3Xpath, XMLTagInfo xmlTagInfo, int count, Class<?> aeChildClass, Object aeChildObject,
																	   String entityField, String splitChar,
																	   E2BXmlProcessHelper e2bXmlProcessHelper, List<Object> inboundSupportDocumentsList, String oldXSD,
																	   String newXSD, Map<String, Integer> lineNoMapByTagId) throws XPathExpressionException, NoSuchFieldException,
			NoSuchMethodException, ClassNotFoundException, IllegalAccessException, InvocationTargetException {

		String childXpath;
		String nodeValueForXpathList = null;
		Node childNode = null;
		String codeListId = null;
		Long formRecId = null;
		String nodeValueFromCodelist = null;

		//Getting FormRecordId
		formRecId = getCustomFormRecId(e2bXmlProcessHelper);

		//GettingAgxUser
		AgxUserBean agxUser = e2bXmlProcessHelper.getAgxUser();

		if (!"Test".equals(xmlTagInfo.getR3EntityName()) && !"PrimarySource".equals(xmlTagInfo.getR3EntityName())) {
			// r3Xpath = getXpath(r3Xpath, count);
			r3Xpath = getChildXpath(r3Xpath, caseIndex, count, "\\[r]");
		}

		//Added to create Attached Document for E2B R3 XML Import
		String docName = "";
		if ("Literature".equals(xmlTagInfo.getR3EntityName()) && "IncludedDocuments".equals(entityField)) {
			childXpath = getXpath(r3Xpath, count);
			childXpath = removeInvalidXpathAttributeExpr(childXpath);
			childNode = (Node) xPath.compile(childXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
			Node compressionNode = getCompressionValue(e2bR3Xmldoc, xPath, childXpath, "@compression");
			Node mediaTypeNode = getMediaType(e2bR3Xmldoc, xPath, childXpath, "@mediaType");
			Node representationNode = getRepresentation(e2bR3Xmldoc, xPath, childXpath, "@representation");
			if (null != representationNode) {
				generateAttachmentDocument(childNode, compressionNode, mediaTypeNode, representationNode, count,
						agxUser, inboundSupportDocumentsList, xmlTagInfo.getR3EntityName(), e2bXmlProcessHelper);
				if(childXpath.endsWith("()")){
					setLineNumberMap("ATTRIBUTE", xmlTagInfo, representationNode, lineNoMapByTagId);
				}else if(childXpath.endsWith("]")){
					setLineNumberMap("NODE", xmlTagInfo, representationNode, lineNoMapByTagId);
				}else{
					setLineNumberMap("TEXT", xmlTagInfo, representationNode, lineNoMapByTagId);
				}
			}
		} else {
			childXpath = getChildXpath(r3Xpath, caseIndex, count, splitChar);
			childXpath = removeInvalidXpathAttributeExpr(childXpath);
			childNode = (Node) xPath.compile(childXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
			if (null == childNode && null != xmlTagInfo.getEmaR3Xpath()) {
				String emaXPath = xmlTagInfo.getEmaR3Xpath();
				childXpath = getChildXpath(emaXPath, caseIndex, count, splitChar);
				childXpath = removeInvalidXpathAttributeExpr(childXpath);
				childNode = (Node) xPath.compile(childXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
				if(childXpath.endsWith("()")){
					setLineNumberMap("TEXT", xmlTagInfo, childNode, lineNoMapByTagId);
				}else if(childXpath.endsWith("]")){
					setLineNumberMap("NODE", xmlTagInfo, childNode, lineNoMapByTagId);
				}else{
					setLineNumberMap("ATTRIBUTE", xmlTagInfo, childNode, lineNoMapByTagId);
				}
			}
			if(null != childNode){
				if(childXpath.endsWith("()")){
					setLineNumberMap("TEXT", xmlTagInfo, childNode, lineNoMapByTagId);
				}else if(childXpath.endsWith("]")){
					setLineNumberMap("NODE", xmlTagInfo, childNode, lineNoMapByTagId);
				}else{
					setLineNumberMap("ATTRIBUTE", xmlTagInfo, childNode, lineNoMapByTagId);
				}
			}
		}


		if (null == childNode) {
			if (null != xmlTagInfo.getR3NullFlavor()) {
				String nullFlavorXpath = getNullFlavorXpath(childXpath);
				Node nullFlavourNode = (Node) xPath.compile(nullFlavorXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
				if (null != nullFlavourNode) {
					childNode = nullFlavourNode;
					entityField = xmlTagInfo.getR3NullFlavorEntityField();
				}
			}
		}

		if (xmlTagInfo.getTagID().equals("D.9.2.r.2") && null == childNode) {
			if (aeChildObject instanceof DeathCause) {
				DeathCause deathCause = (DeathCause) aeChildObject;
				executeJavaScripts(aeChildObject, deathCause.getPatDeathReportMeddraCode(), xmlTagInfo);
			}
		}

		if (null != childNode) {
			String nodeValue = childNode.getNodeValue();

			//R3 Data Validation
			validateR3Data(validationsList, xmlTagInfo, entityField, nodeValue, childNode);

			nodeValueForXpathList = nodeValue;
			if (!"BL".equalsIgnoreCase(xmlTagInfo.getE2bDataType())) {
				Boolean result = false;
				if (null != xmlTagInfo.getFieldId()) {
					codeListId = getCodeListByFieldId(xmlTagInfo.getFieldId(), formRecId, e2bXmlProcessHelper);
				}
				if (null != xmlTagInfo.getAllowedValues()) {
					String allowedValue[] = xmlTagInfo.getAllowedValues().split(",");
					List<String> allowedValuesList = Arrays.asList(allowedValue);
					result = allowedValuesList.contains(childNode.getNodeValue());
				}
				if (null != codeListId && !"0".equals(codeListId) && !"null".equals(codeListId)) {
					if (!result) {
						nodeValueFromCodelist = getCodeFromCodeList(codeListId, childNode.getNodeValue());
						if (null != nodeValueFromCodelist && nodeValueFromCodelist.length() != 0) {
							nodeValue = nodeValueFromCodelist;
						}
					}
				}
				if ("F.r.3.2".equals(xmlTagInfo.getTagID())) {
					if (xmlTagInfo.getR3Xpath().contains("high/@nullFlavor='PINF'")) {
						if (xmlTagInfo.getR3Xpath().contains("inclusive='false']")) {
							nodeValue = "> " + nodeValue;
						} else if (xmlTagInfo.getR3Xpath().contains("inclusive='true']")) {
							nodeValue = ">= " + nodeValue;
						}
					} else if (xmlTagInfo.getR3Xpath().contains("low/@nullFlavor='NINF'")) {
						if (xmlTagInfo.getR3Xpath().contains("inclusive='false']")) {
							nodeValue = "< " + nodeValue;
						} else if (xmlTagInfo.getR3Xpath().contains("inclusive='true']")) {
							nodeValue = "<= " + nodeValue;
						}
					}
				}
			}

			if ("C.2.r.2.7".equals(xmlTagInfo.getTagID())) {
				nodeValue = nodeValue.substring(4);
			} else if ("Literature".equals(xmlTagInfo.getR3EntityName()) && "IncludedDocuments".equals(entityField)) {
				nodeValue = docName;
			}

			Field destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1));
			Method destMethod = aeChildClass.getMethod("set" + entityField, destField.getType());
			// identify the field type in entity class
			//For Free Text
			if (null != codeListId && !"0".equals(codeListId) && "".equals(nodeValueFromCodelist) && "True".equalsIgnoreCase(String.valueOf(xmlTagInfo.getFreeText()))) {
				destField = aeChildClass.getDeclaredField(entityField.substring(0, 1).toLowerCase() + entityField.substring(1) + "SF");
				destMethod = aeChildClass.getMethod("set" + entityField + "SF", destField.getType());
			}

			Class<?> childElementTypeClass = Class.forName(destField.getType().getCanonicalName());
			Object convertedChildElementValue = convertToSpecificType(childElementTypeClass,
					nodeValue, aeChildObject, xmlTagInfo, aeChildClass);
			if (null != convertedChildElementValue
					&& convertedChildElementValue.toString().length() > 0) {
				destMethod.invoke(aeChildObject, convertedChildElementValue);
				if (null != xmlTagInfo.getJavaScripts() && !"".equals(xmlTagInfo.getJavaScripts()) && null != nodeValue) {
					executeJavaScripts(aeChildObject, nodeValue, xmlTagInfo);
				}
			}
    /*            if (null != xmlTagInfo.getJavaScripts() && !"".equals(xmlTagInfo.getJavaScripts()) && null != nodeValue) {
                    if (xmlTagInfo.getTagID().equals("D.9.2.r.1a")) {
                        executeJavaScripts(aeChildObject, nodeValue, xmlTagInfo);
                    }
                }*/
		}
		return nodeValueForXpathList;
	}

	private void executeJavaScripts(Object aeChildObject, String nodeValue, XMLTagInfo xmlTagInfo) {
		try {
			String UTIL = "UTIL";
			ScriptSession sc = ScriptSession.createInstance();
			ScriptingFacadeUtil util = ScriptingFacadeUtil.getInstance();
			sc.put("genericCrudService", genericCrudService);
			HashMap<String, Object> hashMap = new HashMap<>();
			hashMap.put("aeObject", aeChildObject);
			hashMap.put("MeddraCode", nodeValue);
			sc.put(UTIL, util);
			sc.put("HASHMAP", hashMap);
			sc.execute(xmlTagInfo.getJavaScripts(), true);
		} catch (Exception e) {
			//do nothing
		}
	}

	private void generateAttachmentDocument(Node childNode, Node compressionNode, Node mediaTypeNode,
											Node representationNode, int count, AgxUserBean agxUser, List<Object> supportDocumentsList, String entityNameForDoc, E2BXmlProcessHelper e2bXmlProcessHelper) {
		String message = childNode.getNodeValue();
		String mediaType = null;
		String documentIdfromDMS = "";
		//ResourceBundle resourceBundle = ResourceBundle.getBundle("E2BR3DetailedForm_en");
		ResourceBundle resourceBundle = ResourceBundle.getBundle("E2BR3_import_en");
		String stringVal = resourceBundle.getString("B64");
		byte[] messageBytes = message.getBytes(StandardCharsets.UTF_8);
		byte[] deCodedBytes = Base64.decodeBase64(messageBytes);
		try {
			String mediaTypeValue = mediaTypeNode.getNodeValue();
			mediaType = resourceBundle.getString(mediaTypeValue);
			long time = new Date().getTime();
			String attachmentDocFileName = "r3_attachedDoc_" + mediaType + "_" + count + "_" + time + "." + mediaType;
			int docLength = deCodedBytes.length;
			if (null != compressionNode) {
				String compressionNodeName = compressionNode.getNodeName();
				String compressionNodeValue = compressionNode.getNodeValue();
				String compressionAlg = resourceBundle.getString(compressionNodeName);
				if (compressionAlg.equals(compressionNodeValue)) {
					deCodedBytes = CompressionUtils.decompress(deCodedBytes, message);
					docLength = deCodedBytes.length;
				}
			}
			if ("NavaAer".equals(e2bXmlProcessHelper.getParentObjectType())) {/*
				//For Nava Licensed
				NavaSupportDocument navaSupportDocument = new NavaSupportDocument();
				navaSupportDocument.setDocName(attachmentDocFileName);
				navaSupportDocument.setDocId(documentIdfromDMS);
				navaSupportDocument.setDocSize((long) docLength);
				if ("Literature".equals(entityNameForDoc)) {
					navaSupportDocument.setCategoryCode("11");
				} else {
					navaSupportDocument.setCategoryCode("10");
				}
				navaSupportDocument.setData(deCodedBytes);
				supportDocumentsList.add(navaSupportDocument);
			*/} else if ("InboundMessage".equals(e2bXmlProcessHelper.getParentObjectType())) {
				InboundSupportDocument inboundSupportDocument = new InboundSupportDocument();
				inboundSupportDocument.setDocName(attachmentDocFileName);
				inboundSupportDocument.setDocId(documentIdfromDMS);
				inboundSupportDocument.setDocSize((long) docLength);
				if ("Literature".equals(entityNameForDoc)) {
					inboundSupportDocument.setCategoryCode("11");
				} else {
					inboundSupportDocument.setCategoryCode("10");
				}
				inboundSupportDocument.setData(deCodedBytes);
				supportDocumentsList.add(inboundSupportDocument);
			}
		} catch (IOException | DataFormatException e) {
			agLogger.error(e.getMessage(), e);
		}
	}

	private String getLiteratureXpath(String childXpath, String replacePath) {
		return childXpath.replace("text()", replacePath);
	}

	private Node getRepresentation(org.w3c.dom.Document e2bR3Xmldoc, XPath xPath, String childXpath, String replacePath) throws XPathExpressionException {
		String repXpath = getLiteratureXpath(childXpath, replacePath);
		Node repNode = (Node) xPath.compile(repXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
		return repNode;
	}

        /*private Node getDrugFieldWithReactionUUIDRelated(int caseIndex, org.w3c.dom.Document e2bR3Xmldoc, XPath xPath,
                String r3Xpath, int count, Map<String, String> uuidForReactionMap) {

            Set<Entry<String, String>> entrySetReaction = uuidForReactionMap.entrySet();
            Node drugReactionNode = null;
            for (Entry<String, String> reactionUUIDEntry : entrySetReaction) {
                String reactionUUID = reactionUUIDEntry.getValue();
                String splitCh = "\\[k]";
                String drugReactionRelatedXpath = getXpathForDrugReactRelatedness(reactionUUID, "", r3Xpath, caseIndex, count, splitCh);
                try{
                    drugReactionNode = (Node) xPath.compile(drugReactionRelatedXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
                    if(null != drugReactionNode){
                        break;
                    }
                }catch (Exception e) {
                    agLogger.error(e.getMessage(), e);
                }
            }
            return drugReactionNode;
        }*/

	private Node getMediaType(org.w3c.dom.Document e2bR3Xmldoc, XPath xPath, String childXpath, String replacePath) throws XPathExpressionException {
		String repXpath = getLiteratureXpath(childXpath, replacePath);
		Node repNode = (Node) xPath.compile(repXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
		return repNode;
	}

	private Node getCompressionValue(org.w3c.dom.Document e2bR3Xmldoc, XPath xPath, String childXpath, String replacePath) throws XPathExpressionException {
		String compXpath = getLiteratureXpath(childXpath, replacePath);
		Node compNode = (Node) xPath.compile(compXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);
		return compNode;
	}

	private String getXpath(String r3Xpath, int index) {

		String splitExpression[] = r3Xpath.split("\\[r]");
		if (splitExpression.length > 1) {
			if (splitExpression.length == 2) {
				String s1 = splitExpression[0];
				String s2 = splitExpression[1];
				r3Xpath = s1 + "[" + index + "]" + s2;
			} else if (splitExpression.length == 3) {
				String s1 = splitExpression[0];
				String s2 = splitExpression[1];
				String s3 = splitExpression[2];
				r3Xpath = s1 + "[" + index + "]" + s2 + "[r]" + s3;
			} else if (splitExpression.length == 4) {
				String s1 = splitExpression[0];
				String s2 = splitExpression[1];
				String s3 = splitExpression[2];
				String s4 = splitExpression[3];
				r3Xpath = s1 + "[" + index + "]" + s2 + "[r]" + s3 + "[r]" + s4;
			}


		}
		return r3Xpath;
	}

	private String getXpathForNonRepatables(String r3Xpath, int index) {

		String splitExpression[] = r3Xpath.split("\\[i]");
		if (splitExpression.length > 1) {
			if (splitExpression.length == 2) {
				String s1 = splitExpression[0];
				String s2 = splitExpression[1];
				r3Xpath = s1 + "[" + index + "]" + s2;
			} else if (splitExpression.length == 3) {
				String s1 = splitExpression[0];
				String s2 = splitExpression[1];
				String s3 = splitExpression[2];
				r3Xpath = s1 + "[" + index + "]" + s2 + "[i]" + s3;
			} else if (splitExpression.length == 4) {
				String s1 = splitExpression[0];
				String s2 = splitExpression[1];
				String s3 = splitExpression[2];
				String s4 = splitExpression[3];
				r3Xpath = s1 + "[" + index + "]" + s2 + "[i]" + s3 + "[i]" + s4;
			}


		}
		return r3Xpath;
	}

	private String getChildXpath(String r3Xpath, int caseIndex, int index, String splitCh) {

		if ("\\[r]".equals(splitCh)) {

			String msgExpr = "\\[r]";
			//String splitExpression[] = r3Xpath.split("\\[r]");

			String splitExpressionMsg[] = r3Xpath.split(msgExpr);
			if (splitExpressionMsg.length == 2) {
				String s1 = splitExpressionMsg[0];
				String s2 = splitExpressionMsg[1];
				r3Xpath = s1 + "[" + caseIndex + "]" + s2;
			} else if (splitExpressionMsg.length == 3) {
				String s1 = splitExpressionMsg[0];
				String s2 = splitExpressionMsg[1];
				String s3 = splitExpressionMsg[2];
				r3Xpath = s1 + "[" + caseIndex + "]" + s2 + "[" + index + "]" + s3;
			}

		} else if ("\\[a]".equals(splitCh)) {
			String msgExpr = "\\[a]";

			String splitExpressionMsg[] = r3Xpath.split(msgExpr);
			if (splitExpressionMsg.length == 2) {
				String s1 = splitExpressionMsg[0];
				String s2 = splitExpressionMsg[1];
				r3Xpath = s1 + "[" + index + "]" + s2;
			}
		} else {
			String messageXpath = getXpath(r3Xpath, caseIndex);
			String splitExpression[] = messageXpath.split(splitCh);
			if (splitExpression.length > 1) {
				if (splitExpression.length == 2) {
					String s1 = splitExpression[0];
					String s2 = splitExpression[1];
					r3Xpath = s1 + "[" + index + "]" + s2;
				} else if (splitExpression.length == 3) {
					String s1 = splitExpression[0];
					String s2 = splitExpression[1];
					String s3 = splitExpression[2];
					r3Xpath = s1 + "[" + index + "]" + s2 + "[r]" + s3;
				}
                /*	else if(splitExpression.length == 4){
                        String s1 =splitExpression[0];
                        String s2 =splitExpression[1];
                        String s3 =splitExpression[2];
                        String s4 =splitExpression[3];
                        r3Xpath = s1+"["+index+"]"+s2+"["+index+"]"+s3+"[r]"+s4;
                    }*/

			}
		}

		return r3Xpath;
	}

	/**
	 * convertToSpecificType is used to convert the element(tag) value to its
	 * corresponding field type
	 *
	 * @param typeClass
	 * @param childElementValue
	 * @param aeEntityObject
	 * @param childTagInfo
	 * @param aeclass
	 * @return
	 * @throws SecurityException
	 * @throws NoSuchMethodException
	 * @throws NoSuchFieldException
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	private final Object convertToSpecificType(Class<?> typeClass, Object childElementValue, Object aeEntityObject,
											   XMLTagInfo childTagInfo, Class<?> aeclass) throws SecurityException, NoSuchMethodException,
			NoSuchFieldException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
		Object returnValue = childElementValue;
		try {
			if (null != childElementValue && childElementValue.toString().length() > 0) {
				String typeClassName = typeClass.getName();
				String value = childElementValue.toString();
				NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.ENGLISH);
				if (typeClassName.equalsIgnoreCase(Integer.class.getName())) {
					returnValue = numberFormat.parse(value).intValue();
				} else if (typeClassName.equalsIgnoreCase(Byte.class.getName())) {
					returnValue = numberFormat.parse(value).byteValue();
				} else if (typeClassName.equalsIgnoreCase(Short.class.getName())) {
					returnValue = numberFormat.parse(value).shortValue();
				} else if (typeClassName.equalsIgnoreCase(Long.class.getName())) {
					returnValue = numberFormat.parse(value).longValue();
				} else if (typeClassName.equalsIgnoreCase(Float.class.getName())) {
					returnValue = numberFormat.parse(value).floatValue();
				} else if (typeClassName.equalsIgnoreCase(Double.class.getName())) {
					returnValue = numberFormat.parse(value).doubleValue();
				} else if (typeClassName.equalsIgnoreCase(BigDecimal.class.getName())) {
					returnValue = new BigDecimal(value);
				} else if (typeClassName.equalsIgnoreCase(String.class.getName())) {
					if ("True".equalsIgnoreCase(value)) {
						return returnValue = "1";
					} else if ("False".equalsIgnoreCase(value)) {
						return returnValue = "2";
					} else {
						return returnValue = value;
					}
				} else if (typeClassName.equalsIgnoreCase(Date.class.getName())) {
					String dateFmtField = childTagInfo.getDateFmtField();
					Method dateFormatMethod = aeclass.getDeclaredMethod("get" + dateFmtField);
					//Long dateFormatValue = (Long) dateFormatMethod.invoke(aeEntityObject);
					Long dateFormatValue;
					// get agx specific code
					// dateFormatValue =
					// getAGXAppDateFormatCode(dateFormatValue);
					//if (null == dateFormatValue) {
					if (value.length() > 8) {
						if (value.contains("+")) {
							dateFormatValue = E2BXmlProcessor.E2BDateFormats.CCYYMMDDHHMMSSZ.getFormatCode();
						} else {
							dateFormatValue = E2BXmlProcessor.E2BDateFormats.CCYYMMDDHHMMSS.getFormatCode();
						}
					} else if (value.length() <= 8 && value.length() > 6) {
						dateFormatValue = E2BXmlProcessor.E2BDateFormats.CCYYMMDD.getFormatCode();
					} else if (value.length() > 4 && value.length() <= 6) {
						dateFormatValue = E2BXmlProcessor.E2BDateFormats.CCYYMM.getFormatCode();
					} else {
						dateFormatValue = E2BXmlProcessor.E2BDateFormats.CCYY.getFormatCode();
					}
					returnValue = getPrecissionDate(dateFormatValue, value);
					//dateFormatValue = 102L;
					// set AGX format code to format code field
					dateFormatMethod = aeclass.getDeclaredMethod("set" + dateFmtField, Long.class);
					dateFormatMethod.invoke(aeEntityObject, dateFormatValue);
				}
			}
		} catch (Exception e) {
			returnValue = null;
			agLogger.error(e.getMessage(), e);
		}
		return returnValue;
	}// end of convertToSpecificType

	/**
	 * getPrecissionDate is used to format the date
	 *
	 * @param format
	 * @param fieldDate
	 * @return
	 */
	public final Date getPrecissionDate(Long format, String fieldDate) {
		Date formattedDate = null;
		java.text.DateFormat yyyymmdd = new SimpleDateFormat("yyyyMMdd");
		java.text.DateFormat yyyymm = new SimpleDateFormat("yyyyMM");
		java.text.DateFormat yyyy = new SimpleDateFormat("yyyy");
		java.text.DateFormat yyyyMMddHHmmss = new SimpleDateFormat("yyyyMMddHHmmss");
		java.text.DateFormat yyyyMMddHHmmssz = new SimpleDateFormat("yyyyMMddHHmmssz");
		try {
			if (null != format && (null != fieldDate && !"".equals(fieldDate))) {
				if (E2BXmlProcessor.E2BDateFormats.CCYY.equals(E2BXmlProcessor.E2BDateFormats.getType(format))) {
					formattedDate = (Date) yyyy.parse(fieldDate);
				} else if (E2BXmlProcessor.E2BDateFormats.CCYYMM.equals(E2BXmlProcessor.E2BDateFormats.getType(format))) {
					formattedDate = yyyymm.parse(fieldDate);
				} else if (E2BXmlProcessor.E2BDateFormats.CCYYMMDD.equals(E2BXmlProcessor.E2BDateFormats.getType(format))) {
					formattedDate = yyyymmdd.parse(fieldDate);
				} else if (E2BXmlProcessor.E2BDateFormats.CCYYMMDDHHMMSS.equals(E2BXmlProcessor.E2BDateFormats.getType(format))) {
					formattedDate = yyyyMMddHHmmss.parse(fieldDate);
				} else if (E2BXmlProcessor.E2BDateFormats.CCYYMMDDHHMMSSZ.equals(E2BXmlProcessor.E2BDateFormats.getType(format))) {
					formattedDate = yyyyMMddHHmmssz.parse(fieldDate);
				}
			}
		} catch (Exception e) {
			agLogger.error(e.getMessage(), e);
		}
		return formattedDate;
	}// end of getPrecissionDate

	private String getCodeFromCodeList(String codeListId, String decodedStr) {
		String codedString = codeListService.getCodeFromR3Code(codeListId, decodedStr.toUpperCase(), "en");
		if ("mo".equals(decodedStr)) {
			decodedStr = "M";
		}
		if (null == codedString || "".equals(codedString) && !"null".equals(codeListId)) {
			try {
                String dbId = DbContextUtil.getDbInstance().getDbId();
                if(dbId==null){
                     throw new Exception("DB ID is NULL");   
                     }
				List<CodeList> codeList = codeListService.getCodeListWithR3Code(dbId,Long.parseLong(codeListId), "en", null);
				for (CodeList code : codeList) {
					if (null != code.getR3Code() && decodedStr.equalsIgnoreCase(code.getR3Code().toLowerCase())) {
						codedString = code.getCode();
						return codedString;
					} else /*if (decodedvalues.length > 1)*/ {
						if (decodedStr.toLowerCase().equalsIgnoreCase(code.getDecode().toLowerCase())) {
							codedString = code.getCode();
							return codedString;
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return codedString;
	}

	public String getDecodedValueFromCode(String codeListId, String code) {
		//return codeListService.getCodeFromDecode(codeListId, code, "en");
		return codeListService.getCLDecode(Long.valueOf(codeListId), code, "en");
	}

	private String getCodeListByFieldId(String fieldId, Long formRecordID, E2BXmlProcessHelper e2bXmlProcessHelper) {
		ApplicationContext ctx = AppContext.getAppContext();
		FormDesignMBean formDesignMBean = (FormDesignMBean) ctx.getBean("formDesignMBean");
		CustomFormField customFormField = formDesignMBean.getCustomFormField(e2bXmlProcessHelper.getAgxPersistenceUnitName(), "I", formRecordID, fieldId);
		if (customFormField != null) {
			return String.valueOf(customFormField.getCodeListId());
		} else {
			return null;
		}

	}

	public String findScript() throws Exception {
		return genericCrudService
				.findSingleObjectByNativeQuery("select SCRIPT from AG_DYNAMIC_SERVICE_DETAILS where MODULE_NAME='EVWEB'", null);

	}

	private String getCodeFromEmaR3Code(String codeListId, String codedNodeValue) {
		return codeListService.getCodeFromR3Code(codeListId, codedNodeValue, "en");
	}

	private void setNodeValueForPastDrugSubstance(int caseIndex, Document e2bR3Xmldoc, E2BXmlProcessHelper e2bXmlProcessHelper, String messageType, XPath xPath,
												  XMLTableInfo xmlTableInfo, String oldXSD, String newXSD, Object aeChildObject, List<Object> objectList,
												  Map<String, Integer> lineNoMapByTagId) throws ClassNotFoundException, IllegalAccessException, InstantiationException {

		Map<String, XMLTagInfo> tagInfoMap = XMLTagLibraryMetaDataHandler.getXMLR3TagLibraryMetaData(e2bXmlProcessHelper.getAgxPersistenceUnitName())
				.getXmlImportTagInfoMapByMessageType().get(messageType).get(xmlTableInfo.getEntityName());
		Set<Map.Entry<String, XMLTagInfo>> entrySet = tagInfoMap.entrySet();
		String headerKey = null;
		for (Map.Entry<String, XMLTagInfo> entry : entrySet) {
			if ("1".equals(entry.getValue().getR3Header())) {
				headerKey = entry.getKey();
				break;
			}
		}

		XMLTagInfo xmlTagInfoHeader = tagInfoMap.get(headerKey);
		String metaDataXpath = (Objects.isNull(xmlTagInfoHeader.getR3Xpath()) ||
				xmlTagInfoHeader.getR3Xpath().equalsIgnoreCase("")) ? xmlTagInfoHeader.getEmaR3Xpath() : xmlTagInfoHeader.getR3Xpath();

		Class<?> aeSubChildClass = Class.forName(xmlTableInfo.getEntityPkgName() + xmlTableInfo.getEntityName());
		Object aeSubChildObject = null;

		String validXpath = getXpath(metaDataXpath, caseIndex);
		NodeList nodeList = checkForR3NodeList(e2bR3Xmldoc, xPath, validXpath, oldXSD, newXSD);
		if(null!= nodeList) {
		for (int i = 1; i <= nodeList.getLength(); i++) {
			aeSubChildObject = aeSubChildClass.newInstance();
			for (Map.Entry<String, XMLTagInfo> entry : entrySet) {
				try {
					XMLTagInfo xmlTagInfo = entry.getValue();
					if ("1".equalsIgnoreCase(xmlTagInfo.getR3Header())) {
						continue;
					}
					String e2bXpath = (Objects.isNull(xmlTagInfo.getR3Xpath()) ||
							xmlTagInfo.getR3Xpath().equalsIgnoreCase("")) ? xmlTagInfo.getEmaR3Xpath() : xmlTagInfo.getR3Xpath();
					e2bXpath = getChildXpath(e2bXpath, caseIndex, i, "\\[r]");
					e2bXpath = removeInvalidXpathAttributeExpr(e2bXpath);
					Node subListNode = (Node) xPath.compile(e2bXpath).evaluate(e2bR3Xmldoc, XPathConstants.NODE);

					if (null != subListNode) {
						String nodeValue = subListNode.getNodeValue();
						if(e2bXpath.endsWith("()")){
							setLineNumberMap("ATTRIBUTE", xmlTagInfo, subListNode, lineNoMapByTagId);
						}else if(e2bXpath.endsWith("]")){
							setLineNumberMap("NODE", xmlTagInfo, subListNode, lineNoMapByTagId);
						}else{
							setLineNumberMap("TEXT", xmlTagInfo, subListNode, lineNoMapByTagId);
						}
						String codeListId = null;
						if (null != xmlTagInfo.getFieldId()) {
							Long formRecId = getCustomFormRecId(e2bXmlProcessHelper);
							codeListId = getCodeListByFieldId(xmlTagInfo.getFieldId(), formRecId, e2bXmlProcessHelper);
						}
						Boolean result = false;
						if (null != xmlTagInfo.getAllowedValues()) {
							String allowedValue[] = xmlTagInfo.getAllowedValues().split(",");
							List<String> allowedValuesList = Arrays.asList(allowedValue);
							result = allowedValuesList.contains(subListNode.getNodeValue());
						}
						if (null != codeListId && !"0".equals(codeListId) && !"null".equals(codeListId)) {
							if (!result) {
								nodeValue = getCodeFromCodeList(codeListId, subListNode.getNodeValue());
							}
						}

						Field destField = aeSubChildClass.getDeclaredField(xmlTagInfo.getEntityField().substring(0, 1).toLowerCase() + xmlTagInfo.getEntityField().substring(1));
						Method destMethod = aeSubChildClass.getMethod("set" + xmlTagInfo.getEntityField(), destField.getType());

						Class<?> childElementTypeClass = Class.forName(destField.getType().getCanonicalName());
						Object convertedChildElementValue = convertToSpecificType(childElementTypeClass,
								nodeValue, aeSubChildObject, xmlTagInfo, aeSubChildClass);
						if (null != convertedChildElementValue
								&& convertedChildElementValue.toString().length() > 0) {
							destMethod.invoke(aeSubChildObject, convertedChildElementValue);
						}
					}

				} catch (XPathExpressionException | NoSuchFieldException | NoSuchMethodException | InvocationTargetException e) {
					e.printStackTrace();
					agLogger.error("Error occurred while parsing Tag ID : " + entry.getValue().getTagID());
					agLogger.error(e.getMessage(), e);
				}
			}
			if (null != aeSubChildObject) {
				objectList.add(aeSubChildObject);
			}
		}
		}

	}

	private static String getWellConstructedXPathExpr(String xpath_expression, String oldXSD, String newXSD) {
		xpath_expression = xpath_expression.replaceAll("/(?!@)", "/DEFAULT:")
				.replaceAll("\\[(?![@[0-9]])", "[DEFAULT:")
				.replace("DEFAULT:text()", "text()")
				.replace("DEFAULT:starts-with", "starts-with");
		// if (xpath_expression.contains("id[@root='2.16.840.1.113883.3.989.2.1.3.2']")) {
		//}
		if (null != newXSD) {
			xpath_expression = xpath_expression.replaceAll(oldXSD, newXSD);
		}
		return xpath_expression;

	}


	private static String  removeInvalidXpathAttributeExpr(String xpath_expression) {

		if(xpath_expression.contains("xmlns:xsi")){
			//return xpath_expression;
		}
		if(xpath_expression.contains("xsi:schemaLocation")){
			String[] strArray = xpath_expression.split("\\[@xsi:schemaLocation");
			if(null != strArray && strArray.length > 1){
				String splitStr =  strArray[1];
				String[] resStr = splitStr.split(".xsd'\\]");
				if(null != resStr && resStr.length > 1) {
					xpath_expression = strArray[0] + resStr[1];
				}
			}
		}
		if(xpath_expression.contains("xsi:type")){
			String[] strArray = xpath_expression.split("\\[@xsi:type");
			if(null != strArray && strArray.length > 1){
				String splitStr =  strArray[1];
				String[] resStr = splitStr.split("'\\]",2);
				if(null != resStr && resStr.length > 1){
					xpath_expression = strArray[0]+resStr[1];
				}
			}
		}

		return xpath_expression;

	}


}
