package com.arisglobal.validation.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_DF_JAVA_REP")
public class DateFormatJavaRepresentation extends AbstractEntity  {
	
	@ManyToOne
	@JoinColumn(name = "FK_DF_ID")
	private DateFormat dateFormat;	

	@Column(name="FORMAT")
	private String format;
	
	@Column(name="PRECEDENCE")
	private Integer precedence;

	public DateFormat getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(DateFormat dateFormat) {
		this.dateFormat = dateFormat;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public Integer getPrecedence() {
		return precedence;
	}

	public void setPrecedence(Integer precedence) {
		this.precedence = precedence;
	}	
}
