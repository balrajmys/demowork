package com.arisglobal.validation.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_DATE_FORMAT")
public class DateFormat extends AbstractEntity {
	
	@Column(name="NAME")
	private String name;
	
	@Column(name="PRECEDENCE")
	private Integer precedence;
	
	@OneToMany(mappedBy="dateFormat", cascade=CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	private List<DateFormatJavaRepresentation> javaRepresentations;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPrecedence() {
		return precedence;
	}

	public void setPrecedence(Integer precedence) {
		this.precedence = precedence;
	}

	public List<DateFormatJavaRepresentation> getJavaRepresentations() {
		return javaRepresentations;
	}

	public void setJavaRepresentations(List<DateFormatJavaRepresentation> javaRepresentations) {
		this.javaRepresentations = javaRepresentations;
	}	
}
