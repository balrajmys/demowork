package com.arisglobal.validation.validator.impl;

import java.util.Date;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.RepeatableElement;
import com.arisglobal.validation.entities.XmlRule;
import com.arisglobal.validation.utils.DateFormatHelper;
import com.arisglobal.validation.validator.IValidator;

public class LengthValidator implements IValidator {

	//Process value length validation
	@Override
	public boolean validate(Document doc, Node currentNode, XmlRule rule, String value, boolean valueIsEmpty, DateFormatHelper dateFormatHelper,
			List<DateFormat> dateFormatList, Date dateNow, Node repeatableNode, RepeatableElement repeatableElement) throws Exception {
		boolean result = true;
		boolean nodeExistsCheck = rule.getNodeExistsCheck() != null ? rule.getNodeExistsCheck() : false;
		if (!nodeExistsCheck) {
			int fieldLength = rule.getLength();	
	    	if (fieldLength > 0 && value != null && value.length() > fieldLength) {
	    		result = false;
	    	}
		}		
    	return result;
	}
}
