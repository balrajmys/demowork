package com.arisglobal.validation.entities;

public class ValidationError {
	
	private int lineNumber;	
	private String errorMessage;	
	private int errorLevel;
	
	public ValidationError(int lineNumber, String errorMessage, int errorLevel) {
		super();
		this.lineNumber = lineNumber;
		this.errorMessage = errorMessage;
		this.errorLevel = errorLevel;
	}
	public int getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public int getErrorLevel() {
		return errorLevel;
	}
	public void setErrorLevel(int errorLevel) {
		this.errorLevel = errorLevel;
	}
}
