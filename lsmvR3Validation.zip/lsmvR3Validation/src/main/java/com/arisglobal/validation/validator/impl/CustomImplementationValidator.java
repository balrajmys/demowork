package com.arisglobal.validation.validator.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.arisglobal.validation.entities.CustomHandler;
import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.HandlerParameter;
import com.arisglobal.validation.entities.RepeatableElement;
import com.arisglobal.validation.entities.XmlRule;
import com.arisglobal.validation.handler.ICustomHandler;
import com.arisglobal.validation.utils.DateFormatHelper;
import com.arisglobal.validation.validator.IValidator;

public class CustomImplementationValidator implements IValidator {

	@Override
	public boolean validate(Document doc, Node currentNode, XmlRule rule, String value, boolean valueIsEmpty,
			DateFormatHelper dateFormatHelper, List<DateFormat> dateFormatList, Date dateNow, Node repeatableNode,
			RepeatableElement repeatableElement) throws Exception {
		//TODO: Implement loading all custom handlers on application startup
		ICustomHandler customHandler  = (ICustomHandler)  Class.forName(rule.getCustomHandler().getHandlerClass()).newInstance();
		return customHandler.performValidation(currentNode, buildHandlerParametersMap(rule.getCustomHandler()));		
	}	

	private Map<String, String> buildHandlerParametersMap(CustomHandler customHandler) {
		Map<String, String> resultMap = new HashMap<>();
		if (CollectionUtils.isNotEmpty(customHandler.getHandlerParameters())) {
			for (HandlerParameter handlerParameter : customHandler.getHandlerParameters()) {
				resultMap.put(handlerParameter.getParameterName(), handlerParameter.getParameterValue());
			}
		}
		return resultMap;
	}
}
