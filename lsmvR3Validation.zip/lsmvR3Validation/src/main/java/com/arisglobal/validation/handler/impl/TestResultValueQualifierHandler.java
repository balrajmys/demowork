package com.arisglobal.validation.handler.impl;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.arisglobal.validation.handler.ICustomHandler;

public class TestResultValueQualifierHandler implements ICustomHandler {
	
	private final static String VALUE_NODE ="value";
	
	private final static String VALUE_ATTRIBUTE ="value";
	private final static String UNIT_ATTRIBUTE ="unit";	
	private final static String NULL_FLAVOR_ATTRIBUTE ="nullFlavor";
	private final static String INCLUSIVE_ATTRIBUTE ="inclusive";
	
	private final static String CENTER_NODE ="center";
	private final static String LOW_NODE ="low";
	private final static String HIGH_NODE ="high";
	
	private final static String VALUE_TYPE_ATTRIBUTE = "@type";
	private final static String TYPE_ED = "ED";
	private final static String TYPE_IVL_PQ = "IVL_PQ";
	
	private final static String NULL_FLAVOR_PINF = "PINF";
	private final static String NULL_FLAVOR_NINF = "NINF";

	@Override
	public boolean performValidation(Node currentNode, Map<String, String> parameters) throws Exception {
		boolean validationResult = false;		
		
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		
		Node valueNode = (Node) xpath.evaluate(VALUE_NODE, currentNode, XPathConstants.NODE);
		
		
		NamedNodeMap valueAttributes = valueNode.getAttributes();		
		if (valueAttributes.getLength() == 1) {
			String valueType = (String) xpath.evaluate(VALUE_TYPE_ATTRIBUTE, valueNode, XPathConstants.STRING);
			NodeList valueChildNodes = valueNode.getChildNodes();			
			if (StringUtils.isNotEmpty(valueType)) {
				//F.r.3.4 validation				
				if (valueType.equals(TYPE_ED)) {	
					return performFR34Validation(valueChildNodes);					
				//F.r.3.2 and F.r.3.3 validations
				} else if (valueType.equals(TYPE_IVL_PQ)) {	
					List<Element> valueChildElements = new LinkedList<>();
					for (int i = 0 ; i < valueChildNodes.getLength(); i++) {
						Node childNode =  valueChildNodes.item(i);
						if (childNode.getNodeType() == Node.TEXT_NODE) {
							//Text node are not allowed here so validation should fails
							if (StringUtils.isNotEmpty(childNode.getTextContent().trim())) {
								return false;
							}
						} else if (childNode.getNodeType() == Node.ELEMENT_NODE) {
							valueChildElements.add((Element) childNode);
						}
					}
					if (valueChildElements != null && valueChildElements.size() >= 1 && valueChildElements.size() <= 2) {
						//center value check
						if (valueChildElements.size() == 1) {
							return performFR32CenterValueValidation(valueChildElements);						
						// low and high value check
						} else if (valueChildElements.size() == 2) {
							return performFR32LowAndHighValueValidation(valueChildElements);							
						}
					} 					
				} 			
			} 
		}		
		return validationResult;
	}

	private boolean performFR32LowAndHighValueValidation(List<Element> valueChildElements) {
		Node lowNode = null, highNode = null;
		//Check and sets low and high element nodes
		for (int i =0; i< 2; i++) {
			Node itemNode = valueChildElements.get(i);
			if(itemNode.getNodeType() == Node.ELEMENT_NODE) {
				if(itemNode.getNodeName().equals(LOW_NODE)) {
					lowNode = itemNode;
				} else if (itemNode.getNodeName().equals(HIGH_NODE)){
					highNode = itemNode;
				}
			}
		}
		if (lowNode != null && highNode != null) {
			NamedNodeMap lowAttributes = lowNode.getAttributes();
			NamedNodeMap highAttributes = highNode.getAttributes();
			String value = null, unit = null, inclusive = null, nullFlavorLow = null,  nullFlavorHigh = null;
			Node nullFlavorNode = null, valueAttrNode = null, inclusiveNode = null, unitNode = null;	
			//assign attribute values for Low and High nodes
			if (lowAttributes.getLength() == 1 && highAttributes.getLength() == 3) {
				nullFlavorNode = lowAttributes.getNamedItem(NULL_FLAVOR_ATTRIBUTE);
				valueAttrNode = highAttributes.getNamedItem(VALUE_ATTRIBUTE);
				inclusiveNode = highAttributes.getNamedItem(INCLUSIVE_ATTRIBUTE);
				unitNode = highAttributes.getNamedItem(UNIT_ATTRIBUTE);
				if (nullFlavorNode != null) {
					nullFlavorLow = nullFlavorNode.getTextContent();
				}									
			} else if (lowAttributes.getLength() == 3 && highAttributes.getLength() == 1) {
				nullFlavorNode = highAttributes.getNamedItem(NULL_FLAVOR_ATTRIBUTE);
				valueAttrNode = lowAttributes.getNamedItem(VALUE_ATTRIBUTE);
				inclusiveNode = lowAttributes.getNamedItem(INCLUSIVE_ATTRIBUTE);
				unitNode = lowAttributes.getNamedItem(UNIT_ATTRIBUTE);	
				if (nullFlavorNode != null) {
					nullFlavorHigh = nullFlavorNode.getTextContent();
				}
			}								
			if (valueAttrNode != null) {
				value = valueAttrNode.getTextContent();
			}
			if (inclusiveNode != null) {
				inclusive = inclusiveNode.getTextContent();
			}
			if (unitNode != null) {
				unit = unitNode.getTextContent();
			}
			//checking values
			if ( null!= value && null!= unit && StringUtils.isNotEmpty(value) && StringUtils.isNotEmpty(inclusive) && StringUtils.isNotEmpty(unit) &&
				 value.length() <= 50 && unit.length() <= 50 &&
				 (StringUtils.isEmpty(nullFlavorLow) && NULL_FLAVOR_PINF.equals(nullFlavorHigh) || 
				 StringUtils.isEmpty(nullFlavorHigh) && NULL_FLAVOR_NINF.equals(nullFlavorLow))) {
				Boolean inclusiveBoolean = null;
				Float valueFloat = null;
				try {
					inclusiveBoolean = Boolean.parseBoolean(inclusive);
					valueFloat = Float.parseFloat(value);
				} catch (RuntimeException ex) { }	
				if (inclusiveBoolean != null && valueFloat != null) {
					return true;
				}
			}
		}
		return false;
	}

	private boolean performFR34Validation(NodeList valueChildNodes) {
		if (valueChildNodes != null && valueChildNodes.getLength() == 1) {
			Node textNode = valueChildNodes.item(0);
			if (textNode.getNodeType() == Node.TEXT_NODE && StringUtils.isNotEmpty(textNode.getTextContent()) && textNode.getTextContent().length() <= 2000)
				return true;						
		} 
		return false;
	}
	
	private boolean performFR32CenterValueValidation(List<Element> valueChildElements) {
		Node ceneterNode = valueChildElements.get(0);
		if (ceneterNode.getNodeType() == Node.ELEMENT_NODE && ceneterNode.getNodeName().equals(CENTER_NODE)) {
			NamedNodeMap cenetrNodeAttributes = ceneterNode.getAttributes();
			if (cenetrNodeAttributes!= null && cenetrNodeAttributes.getLength() == 2) {
				Node valueAttribute = cenetrNodeAttributes.getNamedItem(VALUE_ATTRIBUTE);
				Node unitAttribute = cenetrNodeAttributes.getNamedItem(UNIT_ATTRIBUTE);
				if (	valueAttribute != null && unitAttribute != null &&
						StringUtils.isNotEmpty(valueAttribute.getTextContent()) &&
						StringUtils.isNotEmpty(unitAttribute.getTextContent()) && 
						valueAttribute.getTextContent().length() <= 50 && 
						unitAttribute.getTextContent().length() <= 50) {
					Float valueFloat = null;
					try {											
						valueFloat = Float.parseFloat(valueAttribute.getTextContent());
					} catch (RuntimeException ex) { }	
					if (valueFloat != null) {
						return true;
					}										
				}
			}
		}
		return false;
	}
}
