package com.arisglobal.validation.validator.impl;

import java.util.Date;
import java.util.List;

import javax.xml.xpath.XPathConstants;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.arisglobal.validation.entities.DateFormat;
import com.arisglobal.validation.entities.RepeatableElement;
import com.arisglobal.validation.entities.XmlRule;
import com.arisglobal.validation.utils.DateFormatHelper;
import com.arisglobal.validation.validator.IValidator;

public class OIDValidator implements IValidator {
	//OID validation
	@Override
	public boolean validate(Document doc, Node currentNode, XmlRule rule, String value, boolean valueIsEmpty,
			DateFormatHelper dateFormatHelper, List<DateFormat> dateFormatList, Date dateNow, Node repeatableNode,
			RepeatableElement repeatableElement) throws Exception {		
		boolean result = true;
		boolean attributeBasedRule = rule.getAttribute() != null;			
		String prefix = attributeBasedRule ? "" : rule.getNode().getNodeIdentifier(); 
		boolean nodeExistsCheck = rule.getNodeExistsCheck() != null ? rule.getNodeExistsCheck() : false;
		if(!nodeExistsCheck) {
			if (StringUtils.isNotEmpty(rule.getOID())) {
				boolean oidCheck = false; 
				String rootXPath = attributeBasedRule ? prefix + XPATH_ATTRIBUTE_SYMBOL + ROOT_ATTRIBUTE : XPATH_NODE_SEPARATOR + XPATH_ATTRIBUTE_SYMBOL + ROOT_ATTRIBUTE;		            					            		
				String oIDValue = (String) xpath.evaluate(rootXPath, currentNode, XPathConstants.STRING);
				if (StringUtils.isNotEmpty(oIDValue) && oIDValue.equals(rule.getOID())) {
					oidCheck = true;
				} else {
					String codeSystemXPath = attributeBasedRule ? prefix + XPATH_ATTRIBUTE_SYMBOL + CODE_SYSTEM_ATTRIBUTE : XPATH_NODE_SEPARATOR + XPATH_ATTRIBUTE_SYMBOL + CODE_SYSTEM_ATTRIBUTE;		            					            						            				            		
					String oIDValue2 = (String) xpath.evaluate(codeSystemXPath, currentNode, XPathConstants.STRING);
					if (StringUtils.isNotEmpty(oIDValue2) && oIDValue2.equals(rule.getOID())) {
						oidCheck = true;
					}
				}
				if (!oidCheck) result = false;
			}
		}		
		return result;
	}
}
