package com.arisglobal.validation.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_XML_ATTR")
public class XmlAttribute extends AbstractEntity {
	
	@Column(name="NAME")
	private String name;
	
	@ManyToOne
	@JoinColumn(name = "FK_N_ID")
	private XmlNode node;	
	
	@Column(name="ATTRIBUTE_IDENTIFIER")
	private String attributeIdentifier;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public XmlNode getNode() {
		return node;
	}

	public void setNode(XmlNode node) {
		this.node = node;
	}

	public String getAttributeIdentifier() {
		return attributeIdentifier;
	}

	public void setAttributeIdentifier(String attributeIdentifier) {
		this.attributeIdentifier = attributeIdentifier;
	}
	
}
