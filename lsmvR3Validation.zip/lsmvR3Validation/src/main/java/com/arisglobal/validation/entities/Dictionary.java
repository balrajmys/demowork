package com.arisglobal.validation.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_DICTIONARY")
public class Dictionary extends AbstractEntity{
	
	@Column(name = "DICTIONARY_NAME")
	private String name;	
	
	@OneToMany(mappedBy="dictionary", cascade=CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	private List<DictionaryValue> dictionaryValues;

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<DictionaryValue> getDictionaryValues() {
		return dictionaryValues;
	}

	public void setDictionaryValues(List<DictionaryValue> dictionaryValues) {
		this.dictionaryValues = dictionaryValues;
	}	
}
