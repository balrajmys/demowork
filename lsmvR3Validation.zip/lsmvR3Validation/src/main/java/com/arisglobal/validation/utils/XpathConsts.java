package com.arisglobal.validation.utils;

public interface XpathConsts {
	public static final String XPATH_NODE_SEPARATOR = "/";
	public static final String XPATH_NODE_VALUE = "text()";
	public static final String XPATH_ATTRIBUTE_SYMBOL = "@";
	public static final String NULL_FLAVOR_ATTRIBUTE = "nullFlavor";
	public static final String ROOT_ATTRIBUTE = "root";
	public static final String CODE_SYSTEM_ATTRIBUTE = "codeSystem";
}
