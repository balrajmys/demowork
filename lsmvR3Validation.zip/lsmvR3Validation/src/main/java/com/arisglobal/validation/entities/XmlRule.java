package com.arisglobal.validation.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.arisglobal.qnccore.entity.AbstractEntity;

@Entity
@Table(name="AGX_R3_VALIDATION_RULE")
public class XmlRule extends AbstractEntity{
	
	@Column(name="NAME")
	private String name;
	
	@Column(name="ERROR_TEXT")
	private String errorText;
	
	@ManyToOne
	@JoinColumn(name = "FK_EL_ID")
	private ErrorLevel errorLevel;

	@ManyToOne
	@JoinColumn(name = "FK_N_ID")
	private XmlNode node;
	
	@ManyToOne
	@JoinColumn(name = "FK_A_ID")
	private XmlAttribute attribute;
	
	@Column(name="COMPLEX_RULE_EXPRESSION")
	private String complexRuleExpression;
	
	@ManyToOne
	@JoinColumn(name = "FK_NFB_ID")
	private NullFlavorBehavior nullFlavorBehavior;
	
	@Column(name="REQUIRED")
	private Boolean required;
	
	@Column(name="NODE_EXISTS_CHECK")
	private Boolean nodeExistsCheck;
	
	@Column(name="LENGTH")
	private Integer length;
	
	@Column (name = "OID")
	private String oID;
	
	@ManyToOne
	@JoinColumn(name = "FK_H_ID")
	private CustomHandler customHandler;
	
	@ManyToOne
	@JoinColumn(name = "FK_DFMT_ID")
	private DateFormatMatcherType dfMatcherType;
	
	@ManyToOne
	@JoinColumn(name = "FK_DF_ID")
	private DateFormat dateFormat;
	
	@ManyToOne
	@JoinColumn(name = "FK_RE_ID")
	private RegExp regExp;
	
	@Column(name="CUSTOM_REGEXP")
	private String customRegExp;
	
	@ManyToOne
	@JoinColumn(name = "FK_MO_ID")
	private MatchOperator matchOperator;
	
	@ManyToOne
	@JoinColumn(name = "FK_MT_ID")
	private MatchType matchType;
	
	@ManyToOne
	@JoinColumn(name = "FK_D_ID")
	private Dictionary dictionary;		

	@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name="AGX_R3_VALIDATION_RULE_M_NA", joinColumns= @JoinColumn(name="FK_R_ID", referencedColumnName="RECORD_ID"), inverseJoinColumns=@JoinColumn(name="FK_N_ID", referencedColumnName="RECORD_ID"))
	private List<XmlNode> matchingNodes;
	
	@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name="AGX_R3_VALIDATION_RULE_M_NA", joinColumns= @JoinColumn(name="FK_R_ID", referencedColumnName="RECORD_ID"), inverseJoinColumns=@JoinColumn(name="FK_A_ID", referencedColumnName="RECORD_ID"))
	private List<XmlAttribute> matchingAttributes;
	
	@OneToMany(mappedBy="rule", cascade=CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)	
	private List<XmlSubRule> subRules;
	
	@OneToMany(mappedBy="rule", cascade=CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)	
	private List<CustomValue> customValues;
	
	@ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name="AGX_R3_VALIDATION_RULE_NF", joinColumns= @JoinColumn(name="FK_R_ID", referencedColumnName="RECORD_ID"), inverseJoinColumns=@JoinColumn(name="FK_NF_ID", referencedColumnName="RECORD_ID"))
	private List<NullFlavor> nulllFlavors;

	public String getName() {
		return name;
	}

	public String getOID() {
		return oID;
	}

	public void setOID(String oID) {
		this.oID = oID;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getErrorText() {
		return errorText;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

	public ErrorLevel getErrorLevel() {
		return errorLevel;
	}

	public void setErrorLevel(ErrorLevel errorLevel) {
		this.errorLevel = errorLevel;
	}

	public XmlNode getNode() {
		return node;
	}

	public void setNode(XmlNode node) {
		this.node = node;
	}

	public XmlAttribute getAttribute() {
		return attribute;
	}

	public void setAttribute(XmlAttribute attribute) {
		this.attribute = attribute;
	}

	public String getComplexRuleExpression() {
		return complexRuleExpression;
	}

	public void setComplexRuleExpression(String complexRuleExpression) {
		this.complexRuleExpression = complexRuleExpression;
	}

	public NullFlavorBehavior getNullFlavorBehavior() {
		return nullFlavorBehavior;
	}

	public void setNullFlavorBehavior(NullFlavorBehavior nullFlavorBehavior) {
		this.nullFlavorBehavior = nullFlavorBehavior;
	}

	public Boolean getRequired() {
		return required;
	}

	public void setRequired(Boolean required) {
		this.required = required;
	}	

	public Boolean getNodeExistsCheck() {
		return nodeExistsCheck;
	}

	public void setNodeExistsCheck(Boolean nodeExistsCheck) {
		this.nodeExistsCheck = nodeExistsCheck;
	}

	public Integer getLength() {
		return length;
	}

	public void setLength(Integer length) {
		this.length = length;
	}

	public DateFormatMatcherType getDfMatcherType() {
		return dfMatcherType;
	}

	public void setDfMatcherType(DateFormatMatcherType dfMatcherType) {
		this.dfMatcherType = dfMatcherType;
	}

	public DateFormat getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(DateFormat dateFormat) {
		this.dateFormat = dateFormat;
	}

	public RegExp getRegExp() {
		return regExp;
	}

	public void setRegExp(RegExp regExp) {
		this.regExp = regExp;
	}

	public String getCustomRegExp() {
		return customRegExp;
	}

	public void setCustomRegExp(String customRegExp) {
		this.customRegExp = customRegExp;
	}

	public MatchOperator getMatchOperator() {
		return matchOperator;
	}

	public void setMatchOperator(MatchOperator matchOperator) {
		this.matchOperator = matchOperator;
	}

	public MatchType getMatchType() {
		return matchType;
	}

	public void setMatchType(MatchType matchType) {
		this.matchType = matchType;
	}

	public Dictionary getDictionary() {
		return dictionary;
	}

	public void setDictionary(Dictionary dictionary) {
		this.dictionary = dictionary;
	}	

	public List<XmlNode> getMatchingNodes() {
		return matchingNodes;
	}

	public void setMatchingNodes(List<XmlNode> matchingNodes) {
		this.matchingNodes = matchingNodes;
	}

	public List<XmlAttribute> getMatchingAttributes() {
		return matchingAttributes;
	}

	public void setMatchingAttributes(List<XmlAttribute> matchingAttributes) {
		this.matchingAttributes = matchingAttributes;
	}

	public List<XmlSubRule> getSubRules() {
		return subRules;
	}

	public void setSubRules(List<XmlSubRule> subRules) {
		this.subRules = subRules;
	}

	public List<CustomValue> getCustomValues() {
		return customValues;
	}

	public void setCustomValues(List<CustomValue> customValues) {
		this.customValues = customValues;
	}

	public List<NullFlavor> getNulllFlavors() {
		return nulllFlavors;
	}

	public void setNulllFlavors(List<NullFlavor> nulllFlavors) {
		this.nulllFlavors = nulllFlavors;
	}	

	public CustomHandler getCustomHandler() {
		return customHandler;
	}

	public void setCustomHandler(CustomHandler customHandler) {
		this.customHandler = customHandler;
	}	
	
}
